return caseSensitive;if(identity)
counter.createNextValue(con);
return defaultValue;this.name = name;identity        = (flag & 1) > 0;
caseSensitive   = (flag & 2) > 0;
nullable        = (flag & 4) > 0;switch(dataType){
case SQLTokenizer.DECIMAL:
case SQLTokenizer.NUMERIC:
return scale;
default:
return Expression.getScale(dataType);
}return defaultDefinition;return name;return SSResultSetMetaData.getDisplaySize( dataType, precision, scale);return nullable;this.defaultValue 		= defaultValue;
this.defaultDefinition	= defaultDefinition;return dataType;return identity;try{
return (Column)clone();
}catch(Exception e){return null;}return SSResultSetMetaData.getDataTypePrecision( dataType, precision );if(identity){
counter = new Identity(raFile, filePos);
defaultValue = new ExpressionValue( counter, SQLTokenizer.BIGINT );
}
return 8;if(precision<0) throw SmallSQLException.create(Language.COL_INVALID_SIZE, new Object[] { new Integer(precision), name});
this.precision = precision;this.identity = identity;this.nullable = nullable;return (identity        ? 1 : 0) |
(caseSensitive   ? 2 : 0) |
(nullable        ? 4 : 0);this.dataType = dataType;if(SSResultSetMetaData.isNumberDataType(dataType))
return getPrecision();
else return getDisplaySize();if(identity){
counter.setNextValue(obj);
}this.scale = scale;return expr.getDisplaySize();return expr.getDataType();return expr.isAutoIncrement();return expr.getAlias();return expr.getPrecision();return expr.getScale();return expr.isCaseSensitive();return expr.isNullable();Columns copy = new Columns();
Column[] cols = copy.data = (Column[]) data.clone();
for(int i=0; i<size; i++){
cols[i] = cols[i].copy();
}
copy.size = size;
return copy;if(column == null){
throw new NullPointerException("Column is null.");
}
if(size >= data.length){
resize(size << 1);
}
data[size++] = column;return size;Column[] dataNew = new Column[newSize];
System.arraycopy(data, 0, dataNew, 0, size);
data = dataNew;if (idx >= size)
throw new IndexOutOfBoundsException("Column index: "+idx+", Size: "+size);
return data[idx];for(int i = 0; i < size; i++){
Column column = data[i];
if(name.equalsIgnoreCase(column.getName())){
return column;
}
}
return null;return -1;rs = null;
updateCount = -1;
return false;if(idx < 1 || idx > params.size())
throw SmallSQLException.create(Language.PARAM_IDX_OUT_RANGE, new Object[] { new Integer(idx), new Integer(params.size())});
return ((ExpressionValue)params.get(idx-1));getParam(idx).set( value, dataType );
if(log.isLogging()){
log.println("param"+idx+'='+value+"; type="+dataType);
}if(rs == null)
throw SmallSQLException.create(Language.RSET_NOT_PRODUCED);
return rs;for(int p=0; p<params.size(); p++){
((ExpressionValue)params.get(p)).clear();
}return rs;return updateCount;params.add( param );getParam(idx).set( value, dataType, length );
if(log.isLogging()){
log.println("param"+idx+'='+value+"; type="+dataType+"; length="+length);
}int savepoint = con.getSavepoint();
try{
executeImpl( con, st );
}catch(Throwable e){
con.rollback(savepoint);
throw SmallSQLException.createFromException(e);
}finally{
if(con.getAutoCommit()) con.commit();
}columnExpressions.add( column );for(int p=0; p<params.size(); p++){
if(((ExpressionValue)params.get(p)).isEmpty())
throw SmallSQLException.create(Language.PARAM_EMPTY, new Integer(p+1));
}if( con.isReadOnly() ){
throw SmallSQLException.create(Language.DB_READONLY);
}
File dir = new File( name );
dir.mkdirs();
if(!new File(dir, Utils.MASTER_FILENAME).createNewFile()){
throw SmallSQLException.create(Language.DB_EXISTENT, name);
}con.getDatabase(false).createView(con, name, sql);columns.add( column );compile(con);
TableViewResult result = TableViewResult.getTableViewResult(from);
updateCount = 0;
from.execute();
while(next()){
result.deleteRow();
updateCount++;
}switch(type){
case SQLTokenizer.DATABASE:
if(name.startsWith("file:"))
name = name.substring(5);
File dir = new File( name );
if(!dir.isDirectory() ||
!new File( dir, Utils.MASTER_FILENAME ).exists())
throw SmallSQLException.create(Language.DB_NONEXISTENT, name);
File files[] = dir.listFiles();
if(files != null)
for(int i=0; i<files.length; i++){
files[i].delete();
}
dir.delete();
break;
case SQLTokenizer.TABLE:
Database.dropTable( con, catalog, name );
break;
case SQLTokenizer.VIEW:
Database.dropView( con, catalog, name );
break;
case SQLTokenizer.INDEX:
case SQLTokenizer.PROCEDURE:
throw new java.lang.UnsupportedOperationException();
default:
throw new Error();
}TableView tableView = con.getDatabase(false).getTableView( con, name);
if(!(tableView instanceof Table))
throw SmallSQLException.create(Language.VIEW_INSERT);
table = (Table)tableView;
tableTimestamp = table.getTimestamp();
cmdSel.compile(con);
int count = table.columns.size();
matrix = new int[count];
if(noColumns){
columnExpressions.clear();
for(int i=0; i<count; i++){
matrix[i] = i;
}
if(count != cmdSel.columnExpressions.size())
throw SmallSQLException.create(Language.COL_VAL_UNMATCH);
}else{
for(int i=0; i<count; i++) matrix[i] = -1;
for(int c=0; c<columnExpressions.size(); c++){
Expression sqlCol = columnExpressions.get(c);
String sqlColName = sqlCol.getName();
int idx = table.findColumnIdx( sqlColName );
if(idx >= 0){
matrix[idx] = c;
}else{
throw SmallSQLException.create(Language.COL_MISSING, sqlColName);
}
}
if(columnExpressions.size() != cmdSel.columnExpressions.size())
throw SmallSQLException.create(Language.COL_VAL_UNMATCH);
}if(columnExpressions.indexOf(column) >= 0){
throw SmallSQLException.create(Language.COL_DUPLICATE, column);
}
super.addColumnExpression(column);this.cmdSel = cmdSel;this.cmdSel = new CommandSelect(log, values );if(table == null || tableTimestamp != table.getTimestamp()) compile( con );
final IndexDescriptions indexes = table.indexes;
updateCount = 0;
cmdSel.from.execute();
cmdSel.beforeFirst();
Strings keyColumnNames = null;
ArrayList keys = null;
boolean needGeneratedKeys = st.needGeneratedKeys();
int generatedKeysType = 0;
while(cmdSel.next()){
if(needGeneratedKeys){
keyColumnNames = new Strings();
keys = new ArrayList();
if(st.getGeneratedKeyNames() != null)
generatedKeysType = 1;
if(st.getGeneratedKeyIndexes() != null)
generatedKeysType = 2;
}
StoreImpl store = table.getStoreInsert( con );
for(int c=0; c<matrix.length; c++){
Column column = table.columns.get(c);
int idx = matrix[c];
Expression valueExpress;
if(idx >= 0){
valueExpress = cmdSel.columnExpressions.get(idx);
}else{
valueExpress = column.getDefaultValue(con);
if(needGeneratedKeys && generatedKeysType == 0 && valueExpress != Expression.NULL){
keyColumnNames.add(column.getName());
keys.add(valueExpress.getObject());
}
}
if(needGeneratedKeys && generatedKeysType == 1){
String[] keyNames = st.getGeneratedKeyNames();
for(int i=0; i<keyNames.length; i++){
if(column.getName().equalsIgnoreCase(keyNames[i])){
keyColumnNames.add(column.getName());
keys.add(valueExpress.getObject());
break;
}
}
}
if(needGeneratedKeys && generatedKeysType == 2){
int[] keyIndexes = st.getGeneratedKeyIndexes();
for(int i=0; i<keyIndexes.length; i++){
if(c+1 == keyIndexes[i]){
keyColumnNames.add(column.getName());
keys.add(valueExpress.getObject());
break;
}
}
}
store.writeExpression( valueExpress, column );
for(int i=0; i<indexes.size(); i++){
indexes.get(i).writeExpression( c, valueExpress );
}
}
store.writeFinsh( con );
for(int i=0; i<indexes.size(); i++){
indexes.get(i).writeFinish( con );
}
updateCount++;
if(needGeneratedKeys){
Object[][] data = new Object[1][keys.size()];
keys.toArray(data[0]);
st.setGeneratedKeys(new SSResultSet( st, Utils.createMemoryCommandSelect( con, keyColumnNames.toArray(), data)));
}
}return maxRows;this.from = join;return from.first();for(int k=0; k<table.columns.size(); k++){
ExpressionName expr = new ExpressionName( table.columns.get(k).getName() );
expr.setFrom( fromEntry, k, table );
columnExpressions.add( position++, expr );
}
return position;return from.isAfterLast();this.where = where;Expression[] expParams = expr.getParams();
isAggregateFunction = isAggregateFunction || expr.getType() >= Expression.GROUP_BEGIN;
if(expParams != null){
for(int k=0; k<expParams.length; k++){
Expression param = expParams[k];
int paramType = param.getType();
isAggregateFunction = isAggregateFunction || paramType >= Expression.GROUP_BEGIN;
if(paramType == Expression.NAME)
compileLinkExpressionName( (ExpressionName)param );
else compileLinkExpressionParams( param );
}
}
expr.optimize();this.tables = from;if(tables.size() > 1)
throw SmallSQLException.create(Language.JOIN_INSERT);
if(tables.size() == 0)
throw SmallSQLException.create(Language.INSERT_WO_FROM);
int savepoint = con.getSavepoint();
try{
TableViewResult result = TableViewResult.getTableViewResult( tables.get(0) );
TableView table = result.getTableView();
Columns tabColumns = table.columns;
int count = tabColumns.size();
Expression[] updateValues = new Expression[count];
if(newRowSources != null){
for(int i=0; i<columnExpressions.size(); i++){
Expression src = newRowSources[i];
if(src != null && (!(src instanceof ExpressionValue) || !((ExpressionValue)src).isEmpty())){
Expression rsColumn = columnExpressions.get(i);
if(!rsColumn.isDefinitelyWritable())
throw SmallSQLException.create(Language.COL_READONLY, new Integer(i));
ExpressionName exp = (ExpressionName)rsColumn;
if(table == exp.getTable()){
updateValues[exp.getColumnIndex()] = src;
continue;
}
}
updateValues[i] = null;
}
}
result.insertRow(updateValues);
}catch(Throwable e){
con.rollback(savepoint);
throw SmallSQLException.createFromException(e);
}finally{
if(con.getAutoCommit()) con.commit();
}if(expr.getType() == Expression.NAME)
compileLinkExpressionName( (ExpressionName)expr);
else compileLinkExpressionParams( expr );return from.isLast();return from.previous();this.orderBy = order;if(maxRows >= 0){
if(maxRows == 0){
from.beforeFirst();
return false;
}
return from.absolute(maxRows);
}
return from.last();Expressions columns = columnExpressions;
for(int i=0; i<columns.size(); i++){
if(columnName.equalsIgnoreCase(columns.get(i).getAlias()))
return i;
}
throw SmallSQLException.create(Language.COL_MISSING, columnName);int savepoint = con.getSavepoint();
try{
for(int t=0; t<tables.size(); t++){
TableViewResult result = TableViewResult.getTableViewResult( tables.get(t) );
TableView table = result.getTableView();
Columns tableColumns = table.columns;
int count = tableColumns.size();
Expression[] updateValues = new Expression[count];
boolean isUpdateNeeded = false;
for(int i=0; i<columnExpressions.size(); i++){
Expression src = newRowSources[i];
if(src != null && (!(src instanceof ExpressionValue) || !((ExpressionValue)src).isEmpty())){
Expression col = columnExpressions.get(i);
if(!col.isDefinitelyWritable())
throw SmallSQLException.create(Language.COL_READONLY, new Integer(i));
ExpressionName exp = (ExpressionName)col;
if(table == exp.getTable()){
updateValues[exp.getColumnIndex()] = src;
isUpdateNeeded = true;
continue;
}
}
}
if(isUpdateNeeded){
result.updateRow(updateValues);
}
}
}catch(Throwable e){
con.rollback(savepoint);
throw SmallSQLException.createFromException(e);
}finally{
if(con.getAutoCommit()) con.commit();
}return from.absolute(row);from.afterLast();return from.isFirst();if(maxRows >= 0 && from.getRow() >= maxRows){
from.afterLast();
return false;
}
return from.next();return from.relative(rows);int row = from.getRow();
if(maxRows >= 0 && row > maxRows) return 0;
return row;return groupBy != null || having != null || isAggregateFunction;this.groupBy = group;String tableAlias = expr.getTableAlias();
if(tableAlias != null){
int t = 0;
for(; t < tables.size(); t++){
DataSource fromEntry = tables.get(t);
if(tableAlias.equalsIgnoreCase(fromEntry.getAlias())){
TableView table = fromEntry.getTableView();
int colIdx = table.findColumnIdx(expr.getName());
if(colIdx >= 0){
expr.setFrom(fromEntry, colIdx, table);
break;
}else
throw SmallSQLException.create(Language.COL_INVALID_NAME, new Object[]{expr.getName()});
}
}
if(t == tables.size())
throw SmallSQLException.create(Language.COL_WRONG_PREFIX, tableAlias);
}else{
boolean isSetFrom = false;
for(int t = 0; t < tables.size(); t++){
DataSource fromEntry = tables.get(t);
TableView table = fromEntry.getTableView();
int colIdx = table.findColumnIdx(expr.getName());
if(colIdx >= 0){
if(isSetFrom){
throw SmallSQLException.create(Language.COL_AMBIGUOUS, expr.getName());
}
isSetFrom = true;
expr.setFrom(fromEntry, colIdx, table);
}
}
if(!isSetFrom){
throw SmallSQLException.create(Language.COL_INVALID_NAME, expr.getName());
}
}
compileLinkExpressionParams(expr);maxRows = max;return from.isBeforeFirst();this.isDistinct = distinct;int savepoint = con.getSavepoint();
try{
if(tables.size() > 1)
throw SmallSQLException.create(Language.JOIN_DELETE);
if(tables.size() == 0)
throw SmallSQLException.create(Language.DELETE_WO_FROM);
TableViewResult.getTableViewResult( tables.get(0) ).deleteRow();
}catch(Throwable e){
con.rollback(savepoint);
throw SmallSQLException.createFromException(e);
}finally{
if(con.getAutoCommit()) con.commit();
}if(singleJoin.condition != null) compileLinkExpressionParams( singleJoin.condition );
if(singleJoin.left instanceof Join){
compileJoin( (Join)singleJoin.left );
}
if(singleJoin.right instanceof Join){
compileJoin( (Join)singleJoin.right );
}compile(con);
if((st.rsType == ResultSet.TYPE_SCROLL_INSENSITIVE || st.rsType == ResultSet.TYPE_SCROLL_SENSITIVE) &&
!from.isScrollable()){
from = new Scrollable(from);
}
from.execute();
rs =  new SSResultSet( st, this );this.having = having;from.beforeFirst();boolean needCompile = false;
if(tables != null){
for(int i=0; i<tables.size(); i++){
DataSource fromEntry = tables.get(i);
needCompile |= fromEntry.init( con );
}
}
if(from == null){
from = new NoFromResult();
tables = new DataSources();
needCompile = true;
}
if(!needCompile) return false;
for(int i=0; i<columnExpressions.size(); i++){
Expression col = columnExpressions.get(i);
if(col.getAlias() == null){
col.setAlias("col" + (i+1));
}
if(col.getType() != Expression.NAME){
compileLinkExpressionParams(col);
continue;
}
ExpressionName expr = (ExpressionName)col;
if("*".equals( expr.getName() )){
String tableAlias = expr.getTableAlias();
if(tableAlias != null){
int t=0;
for(; t<tables.size(); t++){
DataSource fromEntry = tables.get(t);
if(tableAlias.equalsIgnoreCase( fromEntry.getAlias() )){
TableView table = fromEntry.getTableView();
columnExpressions.remove(i);
i = compileAdd_All_Table_Columns( fromEntry, table, i ) - 1;
break;
}
}
if(t==tables.size()) throw SmallSQLException.create(Language.COL_WRONG_PREFIX, new Object[] {tableAlias});
}else{
columnExpressions.remove(i);
for(int t=0; t<tables.size(); t++){
DataSource fromEntry = tables.get(t);
TableView table = fromEntry.getTableView();
i = compileAdd_All_Table_Columns( fromEntry, table, i );
}
i--;
}
}else{
compileLinkExpressionName( expr );
}
}
if(where != null) compileLinkExpression( where );
if(having != null) compileLinkExpression( having );
if(orderBy != null) {
for(int i=0; i<orderBy.size(); i++){
compileLinkExpression( orderBy.get(i));
}
}
if(groupBy != null){
for(int i=0; i<groupBy.size(); i++){
compileLinkExpression( groupBy.get(i) );
}
}
if(from instanceof Join){
compileJoin( (Join)from );
}
if(where != null){
from = new Where( from, where );
}
if(isGroupResult()) {
from = new GroupResult( this, from, groupBy, having, orderBy);
if(having != null){
from = new Where( from, having );
}
}
if(isDistinct){
from = new Distinct( from, columnExpressions );
}
if(orderBy != null){
from = new SortedResult( from, orderBy );
}
return true;switch(type){
case SQLTokenizer.LEVEL:
con.isolationLevel = isolationLevel;
break;
case SQLTokenizer.USE:
con.setCatalog(name);
break;
default:
throw new Error();
}addColumn(columns, column);Database database = catalog == null ?
con.getDatabase(false) :
Database.getDatabase( catalog, con, false );
switch(tableCommandType){
case SQLTokenizer.CREATE:
database.createTable( con, name, columns, indexes, foreignKeys );
break;
case SQLTokenizer.ADD:
con = new SSConnection(con);
Table oldTable = (Table)database.getTableView( con, name);
TableStorePage tableLock = oldTable.requestLock( con, SQLTokenizer.ALTER, -1);
String newName = "#" + System.currentTimeMillis() + this.hashCode();
try{
Columns oldColumns = oldTable.columns;
Columns newColumns = oldColumns.copy();
for(int i = 0; i < columns.size(); i++){
addColumn(newColumns, columns.get(i));
}
Table newTable = database.createTable( con, newName, newColumns, oldTable.indexes, indexes, foreignKeys );
StringBuffer buffer = new StringBuffer(256);
buffer.append("INSERT INTO ").append( newName ).append( '(' );
for(int c=0; c<oldColumns.size(); c++){
if(c != 0){
buffer.append( ',' );
}
buffer.append( oldColumns.get(c).getName() );
}
buffer.append( ")  SELECT * FROM " ).append( name );
con.createStatement().execute( buffer.toString() );
database.replaceTable( oldTable, newTable );
}catch(Exception ex){
try {
database.dropTable(con, newName);
} catch (Exception ex1) {}
try{
indexes.drop(database);
} catch (Exception ex1) {}
throw ex;
}finally{
tableLock.freeLock();
}
break;
default:
throw new Error();
}foreignKeys.add(key);if(cols.get(column.getName()) != null){
throw SmallSQLException.create(Language.COL_DUPLICATE, column.getName());
}
cols.add(column);indexes.add(indexDescription);columnExpressions.add(dest);
sources.add(source);int count = columnExpressions.size();
columnExpressions.addAll(sources);
compile(con);
columnExpressions.setSize(count);
newRowSources = sources.toArray();
updateCount = 0;
from.execute();
for(int i=0; i<columnExpressions.size(); i++){
ExpressionName expr = (ExpressionName)columnExpressions.get(i);
DataSource ds = expr.getDataSource();
TableResult tableResult = (TableResult)ds;
tableResult.lock = SQLTokenizer.UPDATE;
}
while(true){
synchronized(con.getMonitor()){
if(!next()){
return;
}
updateRow(con, newRowSources);
}
updateCount++;
}raFile = null;
return -1;FileChannel currentRaFile = raFile;
if(raFile == null){
return;
}
raFile = null;
try{
currentRaFile.close();
}catch(Throwable ex){
}
con.rollbackFile(currentRaFile);
if(!file.delete()){
file.deleteOnExit();
throw SmallSQLException.create(Language.FILE_CANT_DELETE, file.getPath());
}
String name = file.getName();
name = name.substring(0, name.lastIndexOf('.'));
database.removeTableView(name);return false;return null;for(int i=0; i<columns.size(); i++){
ExpressionName expr = (ExpressionName)columns.get(i);
if(this != expr.getDataSource()){
return false;
}
}
return true;if(size >= data.length ){
DataSource[] dataNew = new DataSource[size << 1];
System.arraycopy(data, 0, dataNew, 0, size);
data = dataNew;
}
data[size++] = table;if (idx >= size)
throw new IndexOutOfBoundsException("Index: "+idx+", Size: "+size);
return data[idx];return size;List rows = new ArrayList();
Strings tables = getTables(tablePattern);
for(int i=0; i<tables.size(); i++){
String tableName = tables.get(i);
try{
TableView tab = getTableView( con, tableName);
Columns cols = tab.columns;
for(int c=0; c<cols.size(); c++){
Column col = cols.get(c);
Object[] row = new Object[18];
row[0] = getName();
row[2] = tableName;
row[3] = col.getName();
row[4] = Utils.getShort( SQLTokenizer.getSQLDataType( col.getDataType() ));
row[5] = SQLTokenizer.getKeyWord( col.getDataType() );
row[6] = Utils.getInteger(col.getColumnSize());
row[8] = Utils.getInteger(col.getScale());
row[9] = Utils.getInteger(10);
row[10]= Utils.getInteger(col.isNullable() ? DatabaseMetaData.columnNullable : DatabaseMetaData.columnNoNulls);
row[12]= col.getDefaultDefinition();
row[15]= row[6];
row[16]= Utils.getInteger(i);
row[17]= col.isNullable() ? "YES" : "NO";
rows.add(row);
}
}catch(Exception e){
}
}
Object[][] result = new Object[rows.size()][];
rows.toArray(result);
return result;if(name == null){
return null;
}
if(name.startsWith("file:")){
name = name.substring(5);
}
File file;
try{
file = new File(name).getCanonicalFile();
}catch(Throwable th){
throw SmallSQLException.createFromException( th );
}
String dbKey = file.getName() + ";readonly=" + con.isReadOnly();
synchronized(databases){
Database db = (Database)databases.get(dbKey);
if(db == null){
if(create && !file.isDirectory()){
CommandCreateDatabase command = new CommandCreateDatabase(con.log, name);
command.execute(con, null);
}
db = new Database( name, file, con.isReadOnly() );
databases.put(dbKey, db);
}
db.connections.put(con, null);
return db;
}return readonly;getDatabase( con, catalog).dropView(tableName);return name;for(int i=0; i<foreignKeys.size(); i++){
ForeignKey foreignKey = foreignKeys.get(i);
TableView pkTable = getTableView(con, foreignKey.pkTable);
if(!(pkTable instanceof Table)){
throw SmallSQLException.create(Language.FK_NOT_TABLE, foreignKey.pkTable);
}
}synchronized(tableViews){
tableViews.remove( oldTable.name );
tableViews.remove( newTable.name );
oldTable.close();
newTable.close();
File oldFile = oldTable.getFile(this);
File newFile = newTable.getFile(this);
File tmpFile = new File(Utils.createTableViewFileName( this, "#" + System.currentTimeMillis() + this.hashCode() ));
if( !oldFile.renameTo(tmpFile) ){
throw SmallSQLException.create(Language.TABLE_CANT_RENAME, oldTable.name);
}
if( !newFile.renameTo(oldFile) ){
tmpFile.renameTo(oldFile);
throw SmallSQLException.create(Language.TABLE_CANT_RENAME, oldTable.name);
}
tmpFile.delete();
}Strings list = new Strings();
File dirs[] = directory.listFiles();
if(dirs != null)
if(tablePattern == null) tablePattern = "%";
tablePattern += Utils.TABLE_VIEW_EXTENTION;
for(int i=0; i<dirs.length; i++){
String name = dirs[i].getName();
if(Utils.like(name, tablePattern)){
list.add(name.substring( 0, name.length()-Utils.TABLE_VIEW_EXTENTION.length() ));
}
}
return list;checkForeignKeys( con, foreignKeys );
Table table = new Table( this, con, name, columns, indexes, foreignKeys);
synchronized(tableViews){
tableViews.put( name, table);
}synchronized(tableViews){
Iterator iterator = tableViews.values().iterator();
while(iterator.hasNext()){
TableView tableView = (TableView)iterator.next();
tableView.close();
iterator.remove();
}
}
master.close();synchronized(tableViews){
Object view = tableViews.remove( viewName );
if(view != null && !(view instanceof View))
throw SmallSQLException.create(Language.VIEWDROP_NOT_VIEW, viewName);
View.drop( this, viewName );
}return getDatabase( con, catalog).getTableView( con, tableName);List catalogs = new ArrayList();
File baseDir = (database != null) ?
database.directory.getParentFile() :
new File(".");
File dirs[] = baseDir.listFiles();
if(dirs != null)
for(int i=0; i<dirs.length; i++){
if(dirs[i].isDirectory()){
if(new File(dirs[i], Utils.MASTER_FILENAME).exists()){
Object[] catalog = new Object[1];
catalog[0] = dirs[i].getPath();
catalogs.add(catalog);
}
}
}
Object[][] result = new Object[catalogs.size()][];
catalogs.toArray(result);
return result;getDatabase( con, catalog).dropTable( con, tableName);checkForeignKeys( con, foreignKeys );
Table table = new Table( this, con, tableName, columns, oldIndexes, newIndexes, foreignKeys);
synchronized(tableViews){
tableViews.put( tableName, table);
}
return table;synchronized(tableViews){
Table table = (Table)tableViews.get( tableName );
if(table != null){
tableViews.remove( tableName );
table.drop(con);
}else{
Table.drop( this, tableName );
}
}List rows = new ArrayList();
Strings tables = getTables(table);
for(int t=0; t<tables.size(); t++){
String tableName = tables.get(t);
TableView tab = getTableView( con, tableName);
if(!(tab instanceof Table)) continue;
IndexDescriptions indexes = ((Table)tab).indexes;
for(int i=0; i<indexes.size(); i++){
IndexDescription index = indexes.get(i);
if(index.isUnique()){
Strings columns = index.getColumns();
for(int c=0; c<columns.size(); c++){
String columnName = columns.get(c);
Column column = tab.findColumn(columnName);
Object[] row = new Object[8];
row[0] = Utils.getShort(DatabaseMetaData.bestRowSession);
row[1] = columnName;
final int dataType = column.getDataType();
row[2] = Utils.getInteger(dataType);
row[3] = SQLTokenizer.getKeyWord(dataType);
row[4] = Utils.getInteger(column.getPrecision());
row[6] = Utils.getShort(column.getScale());
row[7] = Utils.getShort(DatabaseMetaData.bestRowNotPseudo);
rows.add(row);
}
}
}
}
Object[][] result = new Object[rows.size()][];
rows.toArray(result);
return result;synchronized(tableViews){
tableViews.remove( tableViewName );
}List rows = new ArrayList();
Strings tables = getTables(table);
for(int t=0; t<tables.size(); t++){
String tableName = tables.get(t);
TableView tab = getTableView( con, tableName);
if(!(tab instanceof Table)) continue;
IndexDescriptions indexes = ((Table)tab).indexes;
for(int i=0; i<indexes.size(); i++){
IndexDescription index = indexes.get(i);
if(index.isPrimary()){
Strings columns = index.getColumns();
for(int c=0; c<columns.size(); c++){
Object[] row = new Object[6];
row[0] = getName();
row[2] = tableName;
row[3] = columns.get(c);
row[4] = Utils.getShort(c+1);
row[5] = index.getName();
rows.add(row);
}
}
}
}
Object[][] result = new Object[rows.size()][];
rows.toArray(result);
return result;synchronized(tableViews){
TableView tableView = tableViews.get(tableName);
if(tableView == null){
tableView = TableView.load(con, this, tableName);
tableViews.put( tableName, tableView);
}
return tableView;
}new View( this, con, viewName, sql);List rows = new ArrayList();
Strings tables = getTables(table);
Short type = Utils.getShort( DatabaseMetaData.tableIndexOther );
for(int t=0; t<tables.size(); t++){
String tableName = tables.get(t);
TableView tab = getTableView( con, tableName);
if(!(tab instanceof Table)) continue;
IndexDescriptions indexes = ((Table)tab).indexes;
for(int i=0; i<indexes.size(); i++){
IndexDescription index = indexes.get(i);
Strings columns = index.getColumns();
for(int c=0; c<columns.size(); c++){
Object[] row = new Object[13];
row[0] = getName();
row[2] = tableName;
row[3] = Boolean.valueOf(!index.isUnique());
row[5] = index.getName();
row[6] = type;
row[7] = Utils.getShort(c+1);
row[8] = columns.get(c);
rows.add(row);
}
}
}
Object[][] result = new Object[rows.size()][];
rows.toArray(result);
return result;synchronized(databases){
Iterator iterator = databases.values().iterator();
while(iterator.hasNext()){
Database database = (Database)iterator.next();
WeakHashMap connections = database.connections;
connections.remove(con);
if(connections.size() == 0){
try {
iterator.remove();
database.close();
} catch (Exception e) {
throw SmallSQLException.createFromException(e);
}
}
}
}return name == null ?
con.getDatabase(false) :
getDatabase( name, con, false );List rows = new ArrayList();
Strings tables = (pkTable != null) ? getTables(pkTable) : getTables(fkTable);
for(int t=0; t<tables.size(); t++){
String tableName = tables.get(t);
TableView tab = getTableView( con, tableName);
if(!(tab instanceof Table)) continue;
ForeignKeys references = ((Table)tab).references;
for(int i=0; i<references.size(); i++){
ForeignKey foreignKey = references.get(i);
IndexDescription pk = foreignKey.pk;
IndexDescription fk = foreignKey.fk;
if((pkTable == null || pkTable.equals(foreignKey.pkTable)) &&
(fkTable == null || fkTable.equals(foreignKey.fkTable))){
Strings columnsPk = pk.getColumns();
Strings columnsFk = fk.getColumns();
for(int c=0; c<columnsPk.size(); c++){
Object[] row = new Object[14];
row[0] = getName();
row[2] = foreignKey.pkTable;
row[3] = columnsPk.get(c);
row[4] = getName();
row[6] = foreignKey.fkTable;
row[7] = columnsFk.get(c);
row[8] = Utils.getShort(c+1);
row[9] = Utils.getShort(foreignKey.updateRule);
row[10]= Utils.getShort(foreignKey.deleteRule);
row[11]= fk.getName();
row[12]= pk.getName();
row[13]= Utils.getShort(DatabaseMetaData.importedKeyNotDeferrable);
rows.add(row);
}
}
}
}
Object[][] result = new Object[rows.size()][];
rows.toArray(result);
return result;return year % 4 == 0 && (year%100 != 0 || year%400 == 0);buf.setLength(buf.length() + digitCount);
if(value < 0) value = - value;
for(int i=1; i<=digitCount; i++){
buf.setCharAt( buf.length()-i, Utils.digits[ value % 10 ] );
value /= 10;
}if(style < 0)
return toString();
Details details = new Details(time);
StringBuffer buf = new StringBuffer();
switch(style){
case 0:
case 100:
buf.append( SHORT_MONTHS[ details.month ]);
buf.append(' ');
formatNumber( details.day, 2, buf);
buf.append(' ');
formatNumber( details.year, 4, buf);
buf.append(' ');
formatHour12( details.hour, buf );
buf.append(':');
formatNumber( details.minute, 2, buf);
buf.append( details.hour < 12 ? "AM" : "PM" );
return buf.toString();
case 1:
formatNumber( details.month+1, 2, buf);
buf.append('/');
formatNumber( details.day, 2, buf);
buf.append('/');
formatNumber( details.year % 100, 2, buf);
return buf.toString();
case 101:
formatNumber( details.month+1, 2, buf);
buf.append('/');
formatNumber( details.day, 2, buf);
buf.append('/');
formatNumber( details.year, 4, buf);
return buf.toString();
case 2:
formatNumber( details.year % 100, 2, buf);
buf.append('.');
formatNumber( details.month+1, 2, buf);
buf.append('.');
formatNumber( details.day, 2, buf);
return buf.toString();
case 102:
formatNumber( details.year, 4, buf);
buf.append('.');
formatNumber( details.month+1, 2, buf);
buf.append('.');
formatNumber( details.day, 2, buf);
return buf.toString();
case 3:
formatNumber( details.day, 2, buf);
buf.append('/');
formatNumber( details.month+1, 2, buf);
buf.append('/');
formatNumber( details.year % 100, 2, buf);
return buf.toString();
case 103:
formatNumber( details.day, 2, buf);
buf.append('/');
formatNumber( details.month+1, 2, buf);
buf.append('/');
formatNumber( details.year, 4, buf);
return buf.toString();
case 4:
formatNumber( details.day, 2, buf);
buf.append('.');
formatNumber( details.month+1, 2, buf);
buf.append('.');
formatNumber( details.year % 100, 2, buf);
return buf.toString();
case 104:
formatNumber( details.day, 2, buf);
buf.append('.');
formatNumber( details.month+1, 2, buf);
buf.append('.');
formatNumber( details.year, 4, buf);
return buf.toString();
case 5:
formatNumber( details.day, 2, buf);
buf.append('-');
formatNumber( details.month+1, 2, buf);
buf.append('-');
formatNumber( details.year % 100, 2, buf);
return buf.toString();
case 105:
formatNumber( details.day, 2, buf);
buf.append('-');
formatNumber( details.month+1, 2, buf);
buf.append('-');
formatNumber( details.year, 4, buf);
return buf.toString();
case 6:
formatNumber( details.day, 2, buf);
buf.append(' ');
buf.append( SHORT_MONTHS[ details.month ]);
buf.append(' ');
formatNumber( details.year % 100, 2, buf);
return buf.toString();
case 106:
formatNumber( details.day, 2, buf);
buf.append(' ');
buf.append( SHORT_MONTHS[ details.month ]);
buf.append(' ');
formatNumber( details.year, 4, buf);
return buf.toString();
case 7:
buf.append( SHORT_MONTHS[ details.month ]);
buf.append(' ');
formatNumber( details.day, 2, buf);
buf.append(',');
buf.append(' ');
formatNumber( details.year % 100, 2, buf);
return buf.toString();
case 107:
buf.append( SHORT_MONTHS[ details.month ]);
buf.append(' ');
formatNumber( details.day, 2, buf);
buf.append(',');
buf.append(' ');
formatNumber( details.year, 4, buf);
return buf.toString();
case 8:
case 108:
formatNumber( details.hour, 2, buf);
buf.append(':');
formatNumber( details.minute, 2, buf);
buf.append(':');
formatNumber( details.second, 2, buf);
return buf.toString();
case 9:
case 109:
buf.append( SHORT_MONTHS[ details.month ]);
buf.append(' ');
formatNumber( details.day, 2, buf);
buf.append(' ');
formatNumber( details.year, 4, buf);
buf.append(' ');
formatHour12( details.hour, buf );
buf.append(':');
formatNumber( details.minute, 2, buf);
buf.append(':');
formatNumber( details.second, 2, buf);
buf.append(':');
formatMillis( details.millis, buf);
buf.append( details.hour < 12 ? "AM" : "PM" );
return buf.toString();
case 10:
formatNumber( details.month+1, 2, buf);
buf.append('-');
formatNumber( details.day, 2, buf);
buf.append('-');
formatNumber( details.year % 100, 2, buf);
return buf.toString();
case 110:
formatNumber( details.month+1, 2, buf);
buf.append('-');
formatNumber( details.day, 2, buf);
buf.append('-');
formatNumber( details.year, 4, buf);
return buf.toString();
case 11:
formatNumber( details.year % 100, 2, buf);
buf.append('/');
formatNumber( details.month+1, 2, buf);
buf.append('/');
formatNumber( details.day, 2, buf);
return buf.toString();
case 111:
formatNumber( details.year, 4, buf);
buf.append('/');
formatNumber( details.month+1, 2, buf);
buf.append('/');
formatNumber( details.day, 2, buf);
return buf.toString();
case 12:
formatNumber( details.year % 100, 2, buf);
formatNumber( details.month+1, 2, buf);
formatNumber( details.day, 2, buf);
return buf.toString();
case 112:
formatNumber( details.year, 4, buf);
formatNumber( details.month+1, 2, buf);
formatNumber( details.day, 2, buf);
return buf.toString();
case 13:
case 113:
formatNumber( details.day, 2, buf);
buf.append(' ');
buf.append( SHORT_MONTHS[ details.month ]);
buf.append(' ');
formatNumber( details.year, 4, buf);
buf.append(' ');
formatNumber( details.hour, 2, buf );
buf.append(':');
formatNumber( details.minute, 2, buf);
buf.append(':');
formatNumber( details.second, 2, buf);
buf.append(':');
formatMillis( details.millis, buf);
return buf.toString();
case 14:
case 114:
formatNumber( details.hour, 2, buf);
buf.append(':');
formatNumber( details.minute, 2, buf);
buf.append(':');
formatNumber( details.second, 2, buf);
buf.append(':');
formatMillis( details.millis, buf );
return buf.toString();
case 20:
case 120:
formatNumber( details.year, 4, buf);
buf.append('-');
formatNumber( details.month+1, 2, buf);
buf.append('-');
formatNumber( details.day, 2, buf);
buf.append(' ');
formatNumber( details.hour, 2, buf);
buf.append(':');
formatNumber( details.minute, 2, buf);
buf.append(':');
formatNumber( details.second, 2, buf);
return buf.toString();
case 21:
case 121:
formatNumber( details.year, 4, buf);
buf.append('-');
formatNumber( details.month+1, 2, buf);
buf.append('-');
formatNumber( details.day, 2, buf);
buf.append(' ');
formatNumber( details.hour, 2, buf);
buf.append(':');
formatNumber( details.minute, 2, buf);
buf.append(':');
formatNumber( details.second, 2, buf);
buf.append('.');
formatMillis( details.millis, buf );
return buf.toString();
case 26:
case 126:
formatNumber( details.year, 4, buf);
buf.append('-');
formatNumber( details.month+1, 2, buf);
buf.append('-');
formatNumber( details.day, 2, buf);
buf.append('T');
formatNumber( details.hour, 2, buf);
buf.append(':');
formatNumber( details.minute, 2, buf);
buf.append(':');
formatNumber( details.second, 2, buf);
buf.append('.');
formatMillis( details.millis, buf );
return buf.toString();
case 130:
formatNumber( details.day, 2, buf);
buf.append(' ');
buf.append( SHORT_MONTHS[ details.month ]);
buf.append(' ');
formatNumber( details.year, 4, buf);
buf.append(' ');
formatHour12( details.hour, buf );
buf.append(':');
formatNumber( details.minute, 2, buf);
buf.append(':');
formatNumber( details.second, 2, buf);
buf.append(':');
formatMillis( details.millis, buf);
buf.append( details.hour < 12 ? "AM" : "PM" );
return buf.toString();
case 131:
formatNumber( details.day, 2, buf);
buf.append('/');
formatNumber( details.month+1, 2, buf);
buf.append('/');
formatNumber( details.year % 100, 2, buf);
buf.append(' ');
formatNumber( details.hour, 2, buf);
buf.append(':');
formatNumber( details.minute, 2, buf);
buf.append(':');
formatNumber( details.second, 2, buf);
buf.append(':');
formatMillis( details.millis, buf );
return buf.toString();
default:
return toString();
}Details details = new Details(time);
StringBuffer buf = new StringBuffer();
if(dataType != SQLTokenizer.TIME){
formatNumber( details.year,  4, buf );
buf.append('-');
formatNumber( details.month + 1, 2, buf );
buf.append('-');
formatNumber( details.day,   2, buf );
}
if(dataType != SQLTokenizer.DATE){
if(buf.length() > 0) buf.append(' ');
formatNumber( details.hour,  2, buf );
buf.append(':');
formatNumber( details.minute, 2, buf );
buf.append(':');
formatNumber( details.second, 2, buf );
}
switch(dataType){
case SQLTokenizer.TIMESTAMP:
case SQLTokenizer.SMALLDATETIME:
buf.append('.');
formatMillis( details.millis, buf );
}
return buf.toString();return addDateTimeOffset( datetime, TimeZone.getDefault());return removeDateTimeOffset( System.currentTimeMillis() );buf.append(Utils.digits[ (millis / 100) % 10 ]);
int value = millis % 100;
if(value != 0){
buf.append(Utils.digits[ value / 10 ]);
value %= 10;
if(value != 0)
buf.append(Utils.digits[ value ]);
}synchronized(cal){
cal.setTimeZone( TimeZone.getDefault() );
cal.setTimeInMillis( datetime );
return datetime + cal.get( Calendar.ZONE_OFFSET) + cal.get( Calendar.DST_OFFSET);
}return new Timestamp( DateTime.addDateTimeOffset(time) );return new Date( DateTime.addDateTimeOffset(time) );return new Time( DateTime.addDateTimeOffset(time) );long result = millis;
result += second * 1000;
result += minute * 60000;
result += hour * 3600000;
result += (day-1) * 86400000L;
if(month > 11){
year += month / 12;
month %= 12;
}
result += MONTH_DAYS[month] * 86400000L;
result += (year - 1970) * 31536000000L;
result += ((year/4) - (year/100) + (year/400) - 477) * 86400000L;
if(month<2 && year % 4 == 0 && (year%100 != 0 || year%400 == 0))
result -= 86400000L;
return result;return (int)((time / 86400000 + 3) % 7);int t = (int)(datetime % 86400000);
int d = (int)(datetime / 86400000);
if(t<0){
t += 86400000;
d--;
}
int millis = t % 1000;
t /= 1000;
synchronized(cal){
cal.setTimeZone( timezone );
cal.set( 1970, 0, d+1, 0, 0, t );
cal.set( Calendar.MILLISECOND, millis );
return cal.getTimeInMillis();
}return calcMillis(details.year, details.month, details.day, details.hour, details.minute, details.second, details.millis);if(date == null) return null;
return new DateTime( parse(date), dataType);return dataType;switch(dataType){
case SQLTokenizer.DATE:
return getDate( time );
case SQLTokenizer.TIME:
return getTime( time );
default:
return getTimestamp( time );
}long t = date.getTime();
return removeDateTimeOffset(t);hour %= 12;
if(hour == 0) hour = 12;
formatNumber( hour, 2, buf );if(!(obj instanceof DateTime)) return false;
DateTime value = (DateTime)obj;
return value.time == time && value.dataType == dataType;if(date == null) return null;
return new DateTime( parse(date), SQLTokenizer.TIME);if(date == null) return null;
return new DateTime( parse(date), SQLTokenizer.TIMESTAMP);if(date == null) return null;
return new DateTime( parse(date), SQLTokenizer.DATE);return time;if(date == null) return null;
int type;
if(date instanceof java.sql.Date)
type = SQLTokenizer.DATE;
else
if(date instanceof java.sql.Time)
type = SQLTokenizer.TIME;
else
type = SQLTokenizer.TIMESTAMP;
return new DateTime( parse(date), type);try{
final int length = datetime.length();
final int year;
final int month;
final int day;
final int hour;
final int minute;
final int second;
final int millis;
int idx1 = 0;
int idx2 = datetime.indexOf('-');
if(idx2 > 0){
year = Integer.parseInt(datetime.substring(idx1, idx2).trim());
idx1 = idx2+1;
idx2 = datetime.indexOf('-', idx1);
month = Integer.parseInt(datetime.substring(idx1, idx2).trim())-1;
idx1 = idx2+1;
idx2 = datetime.indexOf(' ', idx1);
if(idx2 < 0) idx2 = datetime.length();
day = Integer.parseInt(datetime.substring(idx1, idx2).trim());
}else{
year  = 1970;
month = 0;
day   = 1;
}
idx1 = idx2+1;
idx2 = datetime.indexOf(':', idx1);
if(idx2>0){
hour = Integer.parseInt(datetime.substring(idx1, idx2).trim());
idx1 = idx2+1;
idx2 = datetime.indexOf(':', idx1);
minute = Integer.parseInt(datetime.substring(idx1, idx2).trim());
idx1 = idx2+1;
idx2 = datetime.indexOf('.', idx1);
if(idx2 < 0) idx2 = datetime.length();
second = Integer.parseInt(datetime.substring(idx1, idx2).trim());
idx1 = idx2+1;
if(idx1 < length){
String strMillis = datetime.substring(idx1).trim();
switch(strMillis.length()){
case 1:
millis = Integer.parseInt(strMillis) * 100;
break;
case 2:
millis = Integer.parseInt(strMillis) * 10;
break;
case 3:
millis = Integer.parseInt(strMillis);
break;
default:
millis = Integer.parseInt(strMillis.substring(0,3));
}
}else
millis = 0;
}else{
hour   = 0;
minute = 0;
second = 0;
millis = 0;
}
if(idx1 == 0 && length > 0){
throw SmallSQLException.create(Language.DATETIME_INVALID);
}
if(month >= 12){
throw SmallSQLException.create(Language.MONTH_TOOLARGE, datetime );
}
if(day >= 32){
throw SmallSQLException.create(Language.DAYS_TOOLARGE, datetime );
}
if(day == 31){
switch(month){
case 1:
case 3:
case 5:
case 8:
case 10:
throw SmallSQLException.create(Language.DAYS_TOOLARGE, datetime );
}
}
if(month == 1){
if(day == 30){
throw SmallSQLException.create(Language.DAYS_TOOLARGE, datetime );
}
if(day == 29){
if(!isLeapYear(year)){
throw SmallSQLException.create(Language.DAYS_TOOLARGE, datetime );
}
}
}
if(hour >= 24){
throw SmallSQLException.create(Language.HOURS_TOOLARGE, datetime );
}
if(minute >= 60){
throw SmallSQLException.create(Language.MINUTES_TOOLARGE, datetime );
}
if(second >= 60){
throw SmallSQLException.create(Language.SECS_TOOLARGE, datetime );
}
if(millis >= 1000){
throw SmallSQLException.create(Language.MILLIS_TOOLARGE, datetime );
}
return calcMillis(year, month, day, hour, minute, second, millis);
}catch(SQLException ex){
throw ex;
}catch(Throwable ex){
throw SmallSQLException.createFromException(Language.DATETIME_INVALID, datetime, ex );
}return false;rowSource.execute();
index = new Index(true);rowSource.afterLast();
row = 0;return rowSource.rowDeleted();rowSource.beforeFirst();
row = 0;return rowSource.isExpressionsFromThisRowSource(columns);rowSource.setRowPosition(rowPosition);rowSource.noRow();
row = 0;return rowSource.getRowPosition();return rowSource.rowInserted();rowSource.nullRow();
row = 0;beforeFirst();
return next();return row;while(true){
boolean isNext = rowSource.next();
if(!isNext) return false;
Long oldRowOffset = (Long)index.findRows(distinctColumns, true, null);
long newRowOffset = rowSource.getRowPosition();
if(oldRowOffset == null){
index.addValues( newRowOffset, distinctColumns);
row++;
return true;
}else
if(oldRowOffset.longValue() == newRowOffset){
row++;
return true;
}
}if(params != null){
for(int p=0; p<params.length; p++){
params[p].optimize();
}
}return params;return alias;return getScale(getDataType());this.params = params;Object obj = getObject();
if(obj instanceof Mutable){
return ((Mutable)obj).getImmutableObject();
}
return obj;return true;return type;this.alias = alias;return name;return false;return false;return SSResultSetMetaData.getDisplaySize(getDataType(), getPrecision(), getScale());return SSResultSetMetaData.getDataTypePrecision( getDataType(), -1 );return null;params[idx] = param;this.alias = this.name = name;return false;if(!(expr instanceof Expression)) return false;
if( ((Expression)expr).type == type){
Expression[] p1 = ((Expression)expr).params;
Expression[] p2 = params;
if(p1 != null && p2 != null){
if(p1 == null) return false;
for(int i=0; i<p1.length; i++){
if(!p2[i].equals(p1[i])) return false;
}
}
String name1 = ((Expression)expr).name;
String name2 = name;
if(name1 == name2) return true;
if(name1 == null) return false;
if(name1.equalsIgnoreCase(name2)) return true;
}
return false;switch(dataType){
case SQLTokenizer.MONEY:
case SQLTokenizer.SMALLMONEY:
return 4;
case SQLTokenizer.TIMESTAMP:
return 9;
case SQLTokenizer.NUMERIC:
case SQLTokenizer.DECIMAL:
return 38;
default: return 0;
}return super.clone();switch(value){
case SQLTokenizer.PLUS:         return ADD;
case SQLTokenizer.MINUS:        return SUB;
case SQLTokenizer.ASTERISK:     return MUL;
case SQLTokenizer.SLACH:        return DIV;
case SQLTokenizer.PERCENT:      return MOD;
case SQLTokenizer.EQUALS:       return EQUALS;
case SQLTokenizer.GREATER:      return GREATER;
case SQLTokenizer.GREATER_EQU:  return GRE_EQU;
case SQLTokenizer.LESSER:       return LESSER;
case SQLTokenizer.LESSER_EQU:   return LES_EQU;
case SQLTokenizer.UNEQUALS:     return UNEQUALS;
case SQLTokenizer.BETWEEN:      return BETWEEN;
case SQLTokenizer.LIKE:         return LIKE;
case SQLTokenizer.IN:           return IN;
case SQLTokenizer.IS:           return ISNULL;
case SQLTokenizer.OR:           return OR;
case SQLTokenizer.AND:          return AND;
case SQLTokenizer.NOT:          return NOT;
case SQLTokenizer.BIT_OR:       return BIT_OR;
case SQLTokenizer.BIT_AND:      return BIT_AND;
case SQLTokenizer.BIT_XOR:      return BIT_XOR;
case SQLTokenizer.TILDE:        return BIT_NOT;
default:                        return 0;
}switch(operation){
case OR:
case AND:
case NOT:
case LIKE:
case ISNULL:
case ISNOTNULL:
case IN:
return false;
case NEGATIVE:
case BIT_NOT:
return                  left.isNull();
default:       return left.isNull() || right.isNull();
}switch(operation){
case ADD:       return left.getInt() + right.getInt();
case SUB:       return left.getInt() - right.getInt();
case MUL:       return left.getInt() * right.getInt();
case DIV:       return left.getInt() / right.getInt();
case NEGATIVE:  return               - left.getInt();
case MOD:		return left.getInt() % right.getInt();
case BIT_NOT:   return               ~ left.getInt();
}
throw createUnspportedConversion( SQLTokenizer.INT);Object[] params = {
SQLTokenizer.getKeyWord(getDataType(left, right)),
getKeywordFromOperation(operation)
};
return SmallSQLException.create(Language.UNSUPPORTED_DATATYPE_OPER, params);if(expr == null || other == null){
return expr;
}
switch(expr.getDataType()){
case SQLTokenizer.CHAR:
case SQLTokenizer.NCHAR:
case SQLTokenizer.BINARY:
switch(other.getDataType()){
case SQLTokenizer.VARCHAR:
case SQLTokenizer.NVARCHAR:
case SQLTokenizer.CLOB:
case SQLTokenizer.NCLOB:
case SQLTokenizer.LONGNVARCHAR:
case SQLTokenizer.LONGVARCHAR:
case SQLTokenizer.VARBINARY:
ExpressionFunctionRTrim trim = new ExpressionFunctionRTrim();
trim.setParams(new Expression[]{expr});
return trim;
case SQLTokenizer.CHAR:
case SQLTokenizer.NCHAR:
case SQLTokenizer.BINARY:
if(other.getPrecision() > expr.getPrecision()){
return new ExpressionFunctionConvert(new ColumnExpression(other), expr, null );
}
break;
}
break;
}
return expr;int token = 0;
for(int i=1; i<1000; i++){
if(getOperationFromToken(i) == operation){
token = i;
break;
}
}
if(operation == NEGATIVE)  token = SQLTokenizer.MINUS;
if(operation == ISNOTNULL) token =  SQLTokenizer.IS;
String keyword = SQLTokenizer.getKeyWord(token);
if(keyword == null) keyword = "" + (char)token;
return keyword;switch(operation){
case ADD: return left.getMoney() + right.getMoney();
case SUB: return left.getMoney() - right.getMoney();
case MUL: return left.getMoney() * right.getMoney() / 10000;
case DIV: return left.getMoney() * 10000 / right.getMoney();
case NEGATIVE: return 			 - left.getMoney();
}
throw createUnspportedConversion( SQLTokenizer.MONEY );switch(operation){
case ADD: return lVal + rVal;
case SUB: return lVal - rVal;
case MUL: return lVal * rVal;
case DIV: return lVal / rVal;
case NEGATIVE: return - rVal;
case MOD:		return lVal % rVal;
}
throw createUnspportedConversion( SQLTokenizer.DOUBLE);if(isNull()) return null;
return getObject().toString();int dataTypeIdx = Utils.indexOf( paramDataType, DatatypeRange);
if(dataTypeIdx >= NVARCHAR_IDX)
return SQLTokenizer.DOUBLE;
if(dataTypeIdx >= INT_IDX)
return SQLTokenizer.INT;
if(dataTypeIdx >= BIGINT_IDX)
return SQLTokenizer.BIGINT;
if(dataTypeIdx >= MONEY_IDX)
return SQLTokenizer.MONEY;
if(dataTypeIdx >= DECIMAL_IDX)
return SQLTokenizer.DECIMAL;
return SQLTokenizer.DOUBLE;if(isNull()) return null;
int dataType = getDataType();
switch(dataType){
case SQLTokenizer.BIT:
case SQLTokenizer.BOOLEAN:
return getBoolean() ? Boolean.TRUE : Boolean.FALSE;
case SQLTokenizer.BINARY:
case SQLTokenizer.VARBINARY:
return getBytes();
case SQLTokenizer.TINYINT:
case SQLTokenizer.SMALLINT:
case SQLTokenizer.INT:
return new Integer( getInt() );
case SQLTokenizer.BIGINT:
return new Long( getLong() );
case SQLTokenizer.REAL:
return new Float( getFloat() );
case SQLTokenizer.FLOAT:
case SQLTokenizer.DOUBLE:
return new Double( getDouble() );
case SQLTokenizer.MONEY:
case SQLTokenizer.SMALLMONEY:
return Money.createFromUnscaledValue( getMoney() );
case SQLTokenizer.NUMERIC:
case SQLTokenizer.DECIMAL:
return getNumeric();
case SQLTokenizer.CHAR:
case SQLTokenizer.NCHAR:
case SQLTokenizer.VARCHAR:
case SQLTokenizer.NVARCHAR:
case SQLTokenizer.LONGNVARCHAR:
case SQLTokenizer.LONGVARCHAR:
return getString( left.getString(), right.getString() );
case SQLTokenizer.JAVA_OBJECT:
Object lObj = left.getObject();
Object rObj = right.getObject();
if(lObj instanceof Number && rObj instanceof Number)
return new Double( getDoubleImpl( ((Number)lObj).doubleValue(), ((Number)rObj).doubleValue() ) );
else
return getString( lObj.toString(), rObj.toString() );
case SQLTokenizer.LONGVARBINARY:
return getBytes();
case SQLTokenizer.DATE:
case SQLTokenizer.TIME:
case SQLTokenizer.TIMESTAMP:
case SQLTokenizer.SMALLDATETIME:
return new DateTime( getLong(), dataType );
case SQLTokenizer.UNIQUEIDENTIFIER:
return getBytes();
default: throw createUnspportedDataType();
}if(left.isNull()) return false;
try{
for(int i=0; i<inList.length; i++){
right = inList[i];
if(getBoolean()) return true;
}
}finally{
right = null;
}
return false;if(isNull()) return 0;
int dataType = getDataType();
switch(dataType){
case SQLTokenizer.BIT:
case SQLTokenizer.BOOLEAN:
return getBoolean() ? 1 : 0;
case SQLTokenizer.TINYINT:
case SQLTokenizer.SMALLINT:
case SQLTokenizer.INT:
return getIntImpl();
case SQLTokenizer.BIGINT:
return getLongImpl();
case SQLTokenizer.REAL:
return getFloatImpl();
case SQLTokenizer.FLOAT:
case SQLTokenizer.DOUBLE:
case SQLTokenizer.MONEY:
case SQLTokenizer.SMALLMONEY:
case SQLTokenizer.NUMERIC:
case SQLTokenizer.DECIMAL:
return (float)getDoubleImpl();
}
throw createUnspportedConversion( SQLTokenizer.DOUBLE);if(isNull()) return 0;
switch(operation){
case ADD: return left.getLong() + right.getLong();
case SUB: return left.getLong() - right.getLong();
case MUL: return left.getLong() * right.getLong();
case DIV: return left.getLong() / right.getLong();
case NEGATIVE:  return          - left.getLong();
case MOD:		return left.getLong() % right.getLong();
case BIT_NOT:   return          ~ right.getInt();
}
throw createUnspportedConversion( SQLTokenizer.LONG);if(isNull()) return 0;
int dataType = getDataType();
switch(dataType){
case SQLTokenizer.BIT:
case SQLTokenizer.BOOLEAN:
return getBoolean() ? 1 : 0;
case SQLTokenizer.TINYINT:
case SQLTokenizer.SMALLINT:
case SQLTokenizer.INT:
return getIntImpl();
case SQLTokenizer.BIGINT:
return getLongImpl();
case SQLTokenizer.REAL:
return getFloatImpl();
case SQLTokenizer.FLOAT:
case SQLTokenizer.DOUBLE:
case SQLTokenizer.MONEY:
case SQLTokenizer.SMALLMONEY:
case SQLTokenizer.NUMERIC:
case SQLTokenizer.DECIMAL:
return getDoubleImpl();
}
throw createUnspportedConversion( SQLTokenizer.DOUBLE);if(isNull()) return 0;
int dataType = getDataType();
switch(dataType){
case SQLTokenizer.BIT:
case SQLTokenizer.BOOLEAN:
return getBoolean() ? 1 : 0;
case SQLTokenizer.TINYINT:
case SQLTokenizer.SMALLINT:
case SQLTokenizer.INT:
return getIntImpl();
case SQLTokenizer.BIGINT:
return (int)getLongImpl();
case SQLTokenizer.REAL:
return (int)getFloatImpl();
case SQLTokenizer.FLOAT:
case SQLTokenizer.DOUBLE:
case SQLTokenizer.MONEY:
case SQLTokenizer.SMALLMONEY:
case SQLTokenizer.NUMERIC:
case SQLTokenizer.DECIMAL:
return (int)getDoubleImpl();
}
throw createUnspportedConversion( SQLTokenizer.INT);super.optimize();
Expression[] params = getParams();
if(params.length == 1){
return;
}
setParamAt( convertExpressionIfNeeded( params[0], params[1] ), 0 );
for(int p=1; p<params.length; p++){
setParamAt( convertExpressionIfNeeded( params[p], left ), p );
}switch(operation){
case OR:    return left.getBoolean() || right.getBoolean();
case AND:   return left.getBoolean() && right.getBoolean();
case NOT:   return                      !left.getBoolean();
case LIKE:  return Utils.like( left.getString(), right.getString());
case ISNULL:return 						left.isNull();
case ISNOTNULL:	return 					!left.isNull();
case IN:	if(right == null)
return isInList();
break;
}
final boolean leftIsNull = left.isNull();
int dataType;
if(operation == NEGATIVE || operation == BIT_NOT){
if(leftIsNull) return false;
dataType = left.getDataType();
}else{
final boolean rightIsNull = right.isNull();
if(operation == EQUALS_NULL && leftIsNull && rightIsNull) return true;
if(leftIsNull || rightIsNull) return false;
dataType = getDataType(left, right);
}
switch(dataType){
case SQLTokenizer.BOOLEAN:
switch(operation){
case IN:
case EQUALS_NULL:
case EQUALS:    return left.getBoolean() == right.getBoolean();
case UNEQUALS:  return left.getBoolean() != right.getBoolean();
}
case SQLTokenizer.TINYINT:
case SQLTokenizer.SMALLINT:
case SQLTokenizer.INT:
case SQLTokenizer.BIT:
switch(operation){
case IN:
case EQUALS_NULL:
case EQUALS:    return left.getInt() == right.getInt();
case GREATER:   return left.getInt() >  right.getInt();
case GRE_EQU:   return left.getInt() >= right.getInt();
case LESSER:    return left.getInt() <  right.getInt();
case LES_EQU:   return left.getInt() <= right.getInt();
case UNEQUALS:  return left.getInt() != right.getInt();
case BETWEEN:
int _left = left.getInt();
return _left >= right.getInt() && right2.getInt() >= _left;
default:
return getInt() != 0;
}
case SQLTokenizer.BIGINT:
case SQLTokenizer.TIMESTAMP:
case SQLTokenizer.TIME:
case SQLTokenizer.DATE:
case SQLTokenizer.SMALLDATETIME:
switch(operation){
case IN:
case EQUALS_NULL:
case EQUALS:    return left.getLong() == right.getLong();
case GREATER:   return left.getLong() >  right.getLong();
case GRE_EQU:   return left.getLong() >= right.getLong();
case LESSER:    return left.getLong() <  right.getLong();
case LES_EQU:   return left.getLong() <= right.getLong();
case UNEQUALS:  return left.getLong() != right.getLong();
case BETWEEN:
long _left = left.getLong();
return _left >= right.getLong() && right2.getLong() >= _left;
default:
return getLong() != 0;
}
case SQLTokenizer.REAL:
switch(operation){
case IN:
case EQUALS_NULL:
case EQUALS:    return left.getFloat() == right.getFloat();
case GREATER:   return left.getFloat() >  right.getFloat();
case GRE_EQU:   return left.getFloat() >= right.getFloat();
case LESSER:    return left.getFloat() <  right.getFloat();
case LES_EQU:   return left.getFloat() <= right.getFloat();
case UNEQUALS:  return left.getFloat() != right.getFloat();
case BETWEEN:
float _left = left.getFloat();
return _left >= right.getFloat() && right2.getFloat() >= _left;
default:
return getFloat() != 0;
}
case SQLTokenizer.FLOAT:
case SQLTokenizer.DOUBLE:
switch(operation){
case IN:
case EQUALS_NULL:
case EQUALS:    return left.getDouble() == right.getDouble();
case GREATER:   return left.getDouble() >  right.getDouble();
case GRE_EQU:   return left.getDouble() >= right.getDouble();
case LESSER:    return left.getDouble() <  right.getDouble();
case LES_EQU:   return left.getDouble() <= right.getDouble();
case UNEQUALS:  return left.getDouble() != right.getDouble();
case BETWEEN:
double _left = left.getDouble();
return _left >= right.getDouble() && right2.getDouble() >= _left;
default:
return getDouble() != 0;
}
case SQLTokenizer.MONEY:
case SQLTokenizer.SMALLMONEY:
switch(operation){
case IN:
case EQUALS_NULL:
case EQUALS:    return left.getMoney() == right.getMoney();
case GREATER:   return left.getMoney() >  right.getMoney();
case GRE_EQU:   return left.getMoney() >= right.getMoney();
case LESSER:    return left.getMoney() <  right.getMoney();
case LES_EQU:   return left.getMoney() <= right.getMoney();
case UNEQUALS:  return left.getMoney() != right.getMoney();
case BETWEEN:
long _left = left.getMoney();
return _left >= right.getMoney() && right2.getMoney() >= _left;
default:
return getMoney() != 0;
}
case SQLTokenizer.DECIMAL:
case SQLTokenizer.NUMERIC:{
if(operation == NEGATIVE)
return left.getNumeric().getSignum() != 0;
int comp = left.getNumeric().compareTo( right.getNumeric() );
switch(operation){
case IN:
case EQUALS_NULL:
case EQUALS:    return comp == 0;
case GREATER:   return comp >  0;
case GRE_EQU:   return comp >= 0;
case LESSER:    return comp <  0;
case LES_EQU:   return comp <= 0;
case UNEQUALS:  return comp != 0;
case BETWEEN:
return comp >= 0 && 0 >= left.getNumeric().compareTo( right2.getNumeric() );
default:
return getNumeric().getSignum() != 0;
}
}
case SQLTokenizer.VARCHAR:
case SQLTokenizer.NVARCHAR:
case SQLTokenizer.CHAR:
case SQLTokenizer.NCHAR:
case SQLTokenizer.LONGVARCHAR:
case SQLTokenizer.LONGNVARCHAR:
case SQLTokenizer.CLOB:{
final String leftStr = left.getString();
final String rightStr = right.getString();
int comp = String.CASE_INSENSITIVE_ORDER.compare( leftStr, rightStr );
switch(operation){
case IN:
case EQUALS_NULL:
case EQUALS:    return comp == 0;
case GREATER:   return comp >  0;
case GRE_EQU:   return comp >= 0;
case LESSER:    return comp <  0;
case LES_EQU:   return comp <= 0;
case UNEQUALS:  return comp != 0;
case BETWEEN:
return comp >= 0 && 0 >= String.CASE_INSENSITIVE_ORDER.compare( leftStr, right2.getString() );
case ADD:       return Utils.string2boolean(leftStr + rightStr);
}
break;}
case SQLTokenizer.BINARY:
case SQLTokenizer.VARBINARY:
case SQLTokenizer.LONGVARBINARY:
case SQLTokenizer.BLOB:
case SQLTokenizer.UNIQUEIDENTIFIER:{
byte[] leftBytes = left.getBytes();
byte[] rightBytes= right.getBytes();
int comp = Utils.compareBytes( leftBytes, rightBytes);
switch(operation){
case IN:
case EQUALS_NULL:
case EQUALS:    return comp == 0;
case GREATER:   return comp >  0;
case GRE_EQU:   return comp >= 0;
case LESSER:    return comp <  0;
case LES_EQU:   return comp <= 0;
case UNEQUALS:  return comp != 0;
case BETWEEN:
return comp >= 0 && 0 >= Utils.compareBytes( leftBytes, right2.getBytes() );
}
break;}
}
throw createUnspportedDataType();switch(operation){
case ADD: return left.getFloat() + right.getFloat();
case SUB: return left.getFloat() - right.getFloat();
case MUL: return left.getFloat() * right.getFloat();
case DIV: return left.getFloat() / right.getFloat();
case NEGATIVE:  return           - left.getFloat();
case MOD:		return left.getFloat() % right.getFloat();
}
throw createUnspportedConversion( SQLTokenizer.REAL );int type = left == null ? right.getDataType() : getDataType(left, right);
Object[] params = new Object[] {
SQLTokenizer.getKeyWord(dataType),
SQLTokenizer.getKeyWord(type),
getKeywordFromOperation(operation)
};
return SmallSQLException.create(Language.UNSUPPORTED_CONVERSION_OPER, params);switch(operation){
case NEGATIVE:
case BIT_NOT:
return left.getDataType();
case EQUALS:
case EQUALS_NULL:
case GREATER:
case GRE_EQU:
case LESSER:
case LES_EQU:
case UNEQUALS:
case BETWEEN:
case OR:
case AND:
case NOT:
case LIKE:
case ISNULL:
case ISNOTNULL:
return SQLTokenizer.BOOLEAN;
default:
return getDataType(left, right);
}if(isNull()) return 0;
int dataType = getDataType();
switch(dataType){
case SQLTokenizer.BIT:
case SQLTokenizer.BOOLEAN:
return getBoolean() ? 1 : 0;
case SQLTokenizer.TINYINT:
case SQLTokenizer.SMALLINT:
case SQLTokenizer.INT:
return getIntImpl();
case SQLTokenizer.BIGINT:
return getLongImpl();
case SQLTokenizer.REAL:
return (long)getFloatImpl();
case SQLTokenizer.FLOAT:
case SQLTokenizer.DOUBLE:
case SQLTokenizer.MONEY:
case SQLTokenizer.SMALLMONEY:
case SQLTokenizer.NUMERIC:
case SQLTokenizer.DECIMAL:
return (long)getDoubleImpl();
}
throw createUnspportedConversion( SQLTokenizer.LONG);int dataType = getDataType();
switch(dataType){
case SQLTokenizer.DECIMAL:
case SQLTokenizer.NUMERIC:
switch(operation){
case ADD:
case SUB:
return Math.max(left.getScale(), right.getScale());
case MUL:
return left.getScale() + right.getScale();
case DIV:
return Math.max(left.getScale()+5, right.getScale()+4);
case NEGATIVE:
return left.getScale();
case MOD:
return 0;
}
}
return getScale(dataType);if(isNull()) return 0;
int dataType = getDataType();
switch(dataType){
case SQLTokenizer.BIT:
case SQLTokenizer.BOOLEAN:
return getBoolean() ? 10000 : 0;
case SQLTokenizer.TINYINT:
case SQLTokenizer.SMALLINT:
case SQLTokenizer.INT:
return getIntImpl() * 10000;
case SQLTokenizer.BIGINT:
return getLongImpl() * 10000;
case SQLTokenizer.REAL:
return Utils.doubleToMoney( getFloatImpl() );
case SQLTokenizer.FLOAT:
case SQLTokenizer.DOUBLE:
case SQLTokenizer.NUMERIC:
case SQLTokenizer.DECIMAL:
return Utils.doubleToMoney( getDoubleImpl() );
case SQLTokenizer.MONEY:
case SQLTokenizer.SMALLMONEY:
return getMoneyImpl();
}
throw createUnspportedConversion( SQLTokenizer.DOUBLE);if(!super.equals(expr)) return false;
if(!(expr instanceof ExpressionArithmetic)) return false;
if( ((ExpressionArithmetic)expr).operation != operation) return false;
return true;throw createUnspportedConversion( SQLTokenizer.BINARY );switch(operation){
case ADD:
{
MutableNumeric num = left.getNumeric();
num.add( right.getNumeric() );
return num;
}
case SUB:
{
MutableNumeric num = left.getNumeric();
num.sub( right.getNumeric() );
return num;
}
case MUL:
if(getDataType(right.getDataType(), SQLTokenizer.INT) == SQLTokenizer.INT){
MutableNumeric num = left.getNumeric();
num.mul(right.getInt());
return num;
}else
if(getDataType(left.getDataType(), SQLTokenizer.INT) == SQLTokenizer.INT){
MutableNumeric num = right.getNumeric();
num.mul(left.getInt());
return num;
}else{
MutableNumeric num = left.getNumeric();
num.mul( right.getNumeric() );
return num;
}
case DIV:
{
MutableNumeric num = left.getNumeric();
if(getDataType(right.getDataType(), SQLTokenizer.INT) == SQLTokenizer.INT)
num.div( right.getInt() );
else
num.div( right.getNumeric() );
return num;
}
case NEGATIVE:
{
MutableNumeric num = left.getNumeric();
num.setSignum(-num.getSignum());
return num;
}
case MOD:
{
if(getDataType(getDataType(), SQLTokenizer.INT) == SQLTokenizer.INT)
return new MutableNumeric(getInt());
MutableNumeric num = left.getNumeric();
num.mod( right.getNumeric() );
return num;
}
default:    throw createUnspportedConversion( SQLTokenizer.NUMERIC );
}return operation;if(typeLeft == typeRight) return typeLeft;
int dataTypeIdx = Math.min( Utils.indexOf( typeLeft, DatatypeRange), Utils.indexOf( typeRight, DatatypeRange) );
if(dataTypeIdx < 0) throw new Error("getDataType(): "+typeLeft+", "+typeRight);
return DatatypeRange[ dataTypeIdx ];if(operation == NEGATIVE)
return getDoubleImpl(0, left.getDouble());
return getDoubleImpl(left.getDouble(), right.getDouble());int typeLeft  = left.getDataType();
int typeRight = right.getDataType();
return getDataType( typeLeft, typeRight);if(isNull()) return null;
int dataType = getDataType();
switch(dataType){
case SQLTokenizer.BIT:
case SQLTokenizer.BOOLEAN:
return new MutableNumeric(getBoolean() ? 1 : 0);
case SQLTokenizer.TINYINT:
case SQLTokenizer.SMALLINT:
case SQLTokenizer.INT:
return new MutableNumeric(getIntImpl());
case SQLTokenizer.BIGINT:
return new MutableNumeric(getLongImpl());
case SQLTokenizer.REAL:
return new MutableNumeric(getFloatImpl());
case SQLTokenizer.FLOAT:
case SQLTokenizer.DOUBLE:
return new MutableNumeric( getDoubleImpl() );
case SQLTokenizer.NUMERIC:
case SQLTokenizer.DECIMAL:
return getNumericImpl();
case SQLTokenizer.MONEY:
case SQLTokenizer.SMALLMONEY:
return new MutableNumeric(getMoneyImpl(),4);
}
throw createUnspportedConversion( SQLTokenizer.DOUBLE);switch(idx){
case 0:
left = param;
break;
case 1:
if(right != null){
right = param;
}
break;
case 2:
if(right != null){
right2 = param;
}
break;
}
if(inList != null && idx>0 && idx<=inList.length){
inList[idx-1] = param;
}
super.setParamAt( param, idx );switch(operation){
case ADD: return lVal + rVal;
}
throw createUnspportedConversion( SQLTokenizer.VARCHAR );switch(idx){
case 0:
param1 = param;
break;
case 1:
param2 = param;
break;
case 2:
param3 = param;
break;
case 3:
param4 = param;
break;
}
super.setParamAt( param, idx );Object[] params = {
SQLTokenizer.getKeyWord(dataType),
SQLTokenizer.getKeyWord(getFunction())
};
return SmallSQLException.create(Language.UNSUPPORTED_DATATYPE_FUNC, params);return ExpressionValue.getBytes(getObject(), getDataType());if(!super.equals(expr)) return false;
if(!(expr instanceof ExpressionFunction)) return false;
return ((ExpressionFunction)expr).getFunction() == getFunction();super.setParams( params );
if(params.length >0) param1 = params[0] ;
if(params.length >1) param2 = params[1] ;
if(params.length >2) param3 = params[2] ;
if(params.length >3) param4 = params[3] ;Object[] params = {
SQLTokenizer.getKeyWord(dataType),
SQLTokenizer.getKeyWord(getFunction())
};
return SmallSQLException.create(Language.UNSUPPORTED_CONVERSION_FUNC, params);return SQLTokenizer.ACOS;if(isNull()) return 0;
return Math.acos( param1.getDouble() );return SQLTokenizer.ASIN;if(isNull()) return 0;
return Math.asin( param1.getDouble() );return SQLTokenizer.ATAN;if(isNull()) return 0;
return Math.atan( param1.getDouble() );if(isNull()) return 0;
return Math.atan2( param1.getDouble(), param2.getDouble() );return param1.isNull() || param2.isNull();return SQLTokenizer.ATAN2;if(param1.isNull()) return null;
MutableNumeric num = param1.getNumeric();
if(num.getSignum() < 0) num.setSignum(1);
return num;Object obj = getObject();
if(obj == null) return null;
return obj.toString();return SQLTokenizer.ABS;if(param1.isNull()) return null;
Object para1 = param1.getObject();
switch(param1.getDataType()){
case SQLTokenizer.FLOAT:
case SQLTokenizer.DOUBLE:
double dValue = ((Double)para1).doubleValue();
return (dValue<0) ? new Double(-dValue) : para1;
case SQLTokenizer.REAL:
double fValue = ((Float)para1).floatValue();
return (fValue<0) ? new Float(-fValue) : para1;
case SQLTokenizer.BIGINT:
long lValue = ((Number)para1).longValue();
return (lValue<0) ? new Long(-lValue) : para1;
case SQLTokenizer.TINYINT:
case SQLTokenizer.SMALLINT:
case SQLTokenizer.INT:
int iValue = ((Number)para1).intValue();
return (iValue<0) ? new Integer(-iValue) : para1;
case SQLTokenizer.NUMERIC:
case SQLTokenizer.DECIMAL:
MutableNumeric nValue = (MutableNumeric)para1;
if(nValue.getSignum() <0) nValue.setSignum(1);
return nValue;
case SQLTokenizer.MONEY:
Money mValue = (Money)para1;
if(mValue.value <0) mValue.value = -mValue.value;
return mValue;
default: throw createUnspportedDataType(param1.getDataType());
}return Math.abs( param1.getInt() );return Math.abs( param1.getFloat() );return Math.abs( param1.getLong() );return Math.abs( param1.getDouble() );return Math.abs( param1.getMoney() );return getDouble() != 0;String str = param1.getString();
if(str == null || str.length() == 0) return null;
return Utils.getInteger(str.charAt(0));return param1.isNull() || param1.getString().length() == 0;String str = param1.getString();
if(str == null || str.length() == 0) return 0;
return str.charAt(0);return SQLTokenizer.ASCII;if(isNull()) return 0;
String str = param1.getString();
return str.length() * BYTES_PER_CHAR * 8;return param1.isNull();return SQLTokenizer.BITLEN;int precision = 0;
for(int i=results.size()-1; i>=0; i--){
precision = Math.max(precision, results.get(i).getScale());
}
return precision;return getResult().getString();return getResult().getInt();if(dataType < 0){
dataType = elseResult.getDataType();
for(int i=0; i<results.size(); i++){
dataType = ExpressionArithmetic.getDataType(dataType, results.get(i).getDataType());
}
}
return dataType;return getResult().getMoney();return getResult().isNull();for(int i=0; i<cases.size(); i++){
if(cases.get(i).getBoolean()) return results.get(i);
}
return elseResult;elseResult = expr;super.setParams(params);
int i = 0;
for(int p=0; p<cases.size(); p++){
cases  .set( p, params[i++]);
results.set( p, params[i++]);
}
if(i<params.length)
elseResult = params[i];return getResult().getBoolean();Expression[] params = new Expression[cases.size()*2 + (elseResult!=null ? 1 : 0)];
int i=0;
for(int p=0; p<cases.size(); p++){
params[i++] = cases  .get( p );
params[i++] = results.get( p );
}
if(i<params.length)
params[i] = elseResult;
super.setParams(params);cases.add(condition);
results.add(result);return getResult().getNumeric();super.setParamAt( param, idx );
int p = idx / 2;
if(p>=cases.size()){
elseResult = param;
return;
}
if(idx % 2 > 0){
results.set( p, param );
}else{
cases.set( p, param );
}return getResult().getLong();return getResult().getDouble();return getResult().getFloat();return getResult().getObject();return getResult().getBytes();return SQLTokenizer.CASE;int precision = 0;
for(int i=results.size()-1; i>=0; i--){
precision = Math.max(precision, results.get(i).getPrecision());
}
return precision;if(isNull()) return 0;
return Math.ceil( param1.getDouble() );return SQLTokenizer.CEILING;return 1;if(isNull()) return null;
char chr = (char)param1.getInt();
return String.valueOf(chr);return SQLTokenizer.CHAR;return SQLTokenizer.CHAR;if(isNull()) return 0;
String str = param1.getString();
return str.length();return param1.isNull();return SQLTokenizer.CHARLEN;return param1.isNull();return ExpressionValue.getBoolean( getObject(), getDataType() );return datatype.getDataType();switch(param1.getDataType()){
case SQLTokenizer.LONGVARCHAR:
case SQLTokenizer.VARCHAR:
case SQLTokenizer.CHAR:
return DateTime.parse( param1.getString() );
}
return param1.getLong();if(param2 != null){
int type = param1.getDataType();
switch(type){
case SQLTokenizer.SMALLDATETIME:
type = SQLTokenizer.TIMESTAMP;
case SQLTokenizer.TIMESTAMP:
case SQLTokenizer.DATE:
case SQLTokenizer.TIME:
return new DateTime( param1.getLong(), type ).toString(param2.getInt());
default:
return param1.getString();
}
}else
return param1.getString();return ExpressionValue.getInt( getObject(), getDataType() );final int dataType = getDataType();
switch(dataType){
case SQLTokenizer.VARCHAR:
case SQLTokenizer.VARBINARY:
case SQLTokenizer.BINARY:
case SQLTokenizer.CHAR:
case SQLTokenizer.NUMERIC:
case SQLTokenizer.DECIMAL:
return datatype.getPrecision();
default:
return super.getPrecision();
}return datatype.getScale();if(param1.isNull()) return null;
final int dataType = getDataType();
switch(dataType){
case SQLTokenizer.LONGVARCHAR:
return convertToString();
case SQLTokenizer.VARCHAR:{
String str = convertToString();
int length = datatype.getDisplaySize();
if(length > str.length())
return str;
return str.substring(0,length);
}
case SQLTokenizer.CHAR:{
String str = convertToString();
int length = datatype.getDisplaySize();
if(length > str.length()){
char[] buffer = new char[length-str.length()];
Arrays.fill(buffer, ' ');
return str + new String(buffer);
}
return str.substring(0,length);
}
case SQLTokenizer.LONGVARBINARY:
return param1.getBytes();
case SQLTokenizer.VARBINARY:{
byte[] bytes = param1.getBytes();
int length = datatype.getPrecision();
if(length < bytes.length){
byte[] buffer = new byte[length];
System.arraycopy(bytes, 0, buffer, 0, Math.min(bytes.length,length) );
return buffer;
}
return bytes;
}
case SQLTokenizer.BINARY:{
byte[] bytes = param1.getBytes();
int length = datatype.getPrecision();
if(length != bytes.length){
byte[] buffer = new byte[length];
System.arraycopy(bytes, 0, buffer, 0, Math.min(bytes.length,length) );
return buffer;
}
return bytes;
}
case SQLTokenizer.BOOLEAN:
case SQLTokenizer.BIT:
return param1.getBoolean() ? Boolean.TRUE : Boolean.FALSE;
case SQLTokenizer.TINYINT:
return Utils.getInteger(param1.getInt() & 0xFF);
case SQLTokenizer.SMALLINT:
return Utils.getInteger((short)param1.getInt());
case SQLTokenizer.INT:
return Utils.getInteger(param1.getInt());
case SQLTokenizer.BIGINT:
return new Long(param1.getLong());
case SQLTokenizer.REAL:
return new Float(param1.getFloat());
case SQLTokenizer.FLOAT:
case SQLTokenizer.DOUBLE:
return new Double(param1.getDouble());
case SQLTokenizer.DATE:
case SQLTokenizer.TIME:
case SQLTokenizer.TIMESTAMP:
case SQLTokenizer.SMALLDATETIME:
return new DateTime( getDateTimeLong(), dataType );
case SQLTokenizer.NUMERIC:
case SQLTokenizer.DECIMAL:
MutableNumeric num = param1.getNumeric();
if(num != null && (dataType == SQLTokenizer.NUMERIC || dataType == SQLTokenizer.DECIMAL))
num.setScale(getScale());
return num;
case SQLTokenizer.MONEY:
case SQLTokenizer.SMALLMONEY:
return Money.createFromUnscaledValue(param1.getMoney());
case SQLTokenizer.UNIQUEIDENTIFIER:
switch(param1.getDataType()){
case SQLTokenizer.VARCHAR:
case SQLTokenizer.CHAR:
case SQLTokenizer.LONGVARCHAR:
case SQLTokenizer.CLOB:
return Utils.bytes2unique( Utils.unique2bytes(param1.getString()), 0);
}
return Utils.bytes2unique(param1.getBytes(), 0);
}
Object[] param = { SQLTokenizer.getKeyWord(dataType) };
throw SmallSQLException.create(Language.UNSUPPORTED_TYPE_CONV, param);return ExpressionValue.getMoney(getObject(), getDataType());return SQLTokenizer.CONVERT;return ExpressionValue.getNumeric(getObject(), getDataType());Object obj = getObject();
if(obj == null) return null;
switch(datatype.getDataType()){
case SQLTokenizer.BIT:
return ((Boolean)obj).booleanValue() ? "1" : "0";
case SQLTokenizer.BINARY:
case SQLTokenizer.VARBINARY:
case SQLTokenizer.LONGVARBINARY:
return new String( (byte[])obj );
}
return obj.toString();return ExpressionValue.getDouble( getObject(), getDataType() );return ExpressionValue.getLong( getObject(), getDataType() );return ExpressionValue.getFloat( getObject(), getDataType() );return SQLTokenizer.COS;if(isNull()) return 0;
return Math.cos( param1.getDouble() );if(isNull()) return 0;
return 1/Math.tan( param1.getDouble() );return SQLTokenizer.COT;return SQLTokenizer.DAYOFMONTH;if(param1.isNull()) return 0;
DateTime.Details details = new DateTime.Details(param1.getLong());
return details.day;if(param1.isNull()) return 0;
return DateTime.dayOfWeek(param1.getLong())+1;return SQLTokenizer.DAYOFWEEK;if(param1.isNull()) return 0;
DateTime.Details details = new DateTime.Details(param1.getLong());
return details.dayofyear+1;return SQLTokenizer.DAYOFYEAR;if(isNull()) return 0;
return Math.toDegrees( param1.getDouble() );return SQLTokenizer.DEGREES;if(isNull()) return 0;
String str1 = ExpressionFunctionSoundex.getString(param1.getString());
String str2 = ExpressionFunctionSoundex.getString(param2.getString());
int diff = 0;
for(int i=0; i<4; i++){
if(str1.charAt(i) == str2.charAt(i)){
diff++;
}
}
return diff;return param1.isNull() || param2.isNull();return SQLTokenizer.DIFFERENCE;return SQLTokenizer.EXP;if(isNull()) return 0;
return Math.exp( param1.getDouble() );return Math.floor( param1.getDouble() );return SQLTokenizer.FLOOR;Object obj = getObject();
if(obj == null) return null;
return obj.toString();return SQLTokenizer.HOUR;if(param1.isNull()) return 0;
DateTime.Details details = new DateTime.Details(param1.getLong());
return details.hour;return SQLTokenizer.IIF;return Math.max( param2.getScale(), param3.getScale() );return ExpressionArithmetic.getDataType(param2, param3);if(param1.getBoolean())
return param2.getObject();
return param3.getObject();return Math.max( param2.getPrecision(), param3.getPrecision() );if(param1.getBoolean())
return param2.getMoney();
return param3.getMoney();if(param1.getBoolean())
return param2.getString();
return param3.getString();if(param1.getBoolean())
return param2.getInt();
return param3.getInt();if(param1.getBoolean())
return param2.isNull();
return param3.isNull();if(param1.getBoolean())
return param2.getBoolean();
return param3.getBoolean();if(param1.getBoolean())
return param2.getNumeric();
return param3.getNumeric();if(param1.getBoolean())
return param2.getFloat();
return param3.getFloat();if(param1.getBoolean())
return param2.getDouble();
return param3.getDouble();if(param1.getBoolean())
return param2.getLong();
return param3.getLong();return SQLTokenizer.INSERT;return param1.isNull() || param2.isNull() || param3.isNull() || param4.isNull();if(isNull()) return null;
String str = param1.getString();
int start  = Math.min(Math.max( 0, param2.getInt() - 1), str.length() );
int length = Math.min(param3.getInt(), str.length() );
StringBuffer buffer = new StringBuffer();
buffer.append(str.substring(0,start));
buffer.append(param4.getString());
if(length < 0)
throw SmallSQLException.create(Language.INSERT_INVALID_LEN, new Integer(length));
buffer.append(str.substring(start+length));
return buffer.toString();return param1.getPrecision()+param2.getPrecision();if(isNull()) return null;
byte[] bytes = param1.getBytes();
int start  = Math.min(Math.max( 0, param2.getInt() - 1), bytes.length );
int length = Math.min(param3.getInt(), bytes.length );
ByteArrayOutputStream buffer = new ByteArrayOutputStream();
buffer.write(bytes,0,start);
buffer.write(param4.getBytes());
if(length < 0)
throw SmallSQLException.create(Language.INSERT_INVALID_LEN, new Integer(length));
buffer.write(bytes, start+length, bytes.length-start-length);
return buffer.toByteArray();return param1.isNull();if(isNull()) return null;
return param1.getString().toLowerCase();return SQLTokenizer.LCASE;if(isNull()) return null;
return getString().getBytes();return param1.isNull();return SQLTokenizer.LTRIM;if(isNull()) return null;
byte[] bytes = param1.getBytes();
int start = 0;
int length = bytes.length;
while(start<length && bytes[start]==0){
start++;
}
length -= start;
byte[] b = new byte[length];
System.arraycopy(bytes, start, b, 0, length);
return b;if(isNull()) return null;
String str = param1.getString();
int start = 0;
while(start<str.length() && str.charAt(start)==' '){
start++;
}
return str.substring(start);return SQLTokenizer.LEFT;return param1.isNull() || param2.isNull();if(isNull()) return null;
String str = param1.getString();
int length = param2.getInt();
length = Math.min( length, str.length() );
return str.substring(0,length);if(isNull()) return null;
byte[] bytes = param1.getBytes();
int length = param2.getInt();
if(bytes.length <= length) return bytes;
byte[] b = new byte[length];
System.arraycopy(bytes, 0, b, 0, length);
return b;return SQLTokenizer.LENGTH;String str = param1.getString();
if(str == null) return 0;
int length = str.length();
while(length>=0 && str.charAt(length-1) == ' ') length--;
return length;return SQLTokenizer.LOCATE;return param1.isNull() || param2.isNull();String suchstr = param1.getString();
String value   = param2.getString();
if(suchstr == null || value == null || suchstr.length() == 0 || value.length() == 0) return 0;
int start = 0;
if(param3 != null){
start = param3.getInt()-1;
}
return value.toUpperCase().indexOf( suchstr.toUpperCase(), start ) +1;if(isNull()) return 0;
return Math.log( param1.getDouble() );return SQLTokenizer.LOG;return SQLTokenizer.LOG10;if(isNull()) return 0;
return Math.log( param1.getDouble() ) / divisor;return SQLTokenizer.MINUTE;if(param1.isNull()) return 0;
DateTime.Details details = new DateTime.Details(param1.getLong());
return details.minute;if(isNull()) return 0;
return param1.getInt() % param2.getInt();return param1.isNull() || param2.isNull();return SQLTokenizer.MOD;return SQLTokenizer.MONTH;if(param1.isNull()) return 0;
DateTime.Details details = new DateTime.Details(param1.getLong());
return details.month+1;return param1.isNull();return SQLTokenizer.OCTETLEN;if(isNull()) return 0;
String str = param1.getString();
return str.length() * BYTES_PER_CHAR;return false;return SQLTokenizer.PI;return Math.PI;return param1.isNull() || param2.isNull();if(isNull()) return 0;
return Math.pow( param1.getDouble(), param2.getDouble() );return SQLTokenizer.POWER;return param1.isNull();return SQLTokenizer.RTRIM;if(isNull()) return null;
String str = param1.getString();
int length = str.length();
while(length>0 && str.charAt(length-1)==' '){
length--;
}
return str.substring(0,length);if(isNull()) return null;
byte[] bytes = param1.getBytes();
int length = bytes.length;
while(length>0 && bytes[length-1]==0){
length--;
}
byte[] b = new byte[length];
System.arraycopy(bytes, 0, b, 0, length);
return b;if(isNull()) return 0;
return Math.toRadians( param1.getDouble() );return SQLTokenizer.RADIANS;return getParams().length == 1 && param1.isNull();if(getParams().length == 0)
return random.nextDouble();
if(isNull()) return 0;
return new Random(param1.getLong()).nextDouble();return SQLTokenizer.RAND;return SQLTokenizer.REPEAT;return SSResultSetMetaData.getDataTypePrecision( getDataType(), -1 );if(isNull()) return null;
byte[] bytes = param1.getBytes();
int count  = param2.getInt();
ByteArrayOutputStream buffer = new ByteArrayOutputStream();
for(int i=0; i<count; i++){
buffer.write(bytes);
}
return buffer.toByteArray();if(isNull()) return null;
String str = param1.getString();
int count  = param2.getInt();
StringBuffer buffer = new StringBuffer();
for(int i=0; i<count; i++){
buffer.append(str);
}
return buffer.toString();if(isNull()) return null;
byte[] str1 = param1.getBytes();
byte[] str2  = param2.getBytes();
int length = str2.length;
if(length == 0){
return str1;
}
byte[] str3  = param3.getBytes();
ByteArrayOutputStream buffer = new ByteArrayOutputStream();
int idx1 = 0;
int idx2 = Utils.indexOf(str2,str1,idx1);
while(idx2 > 0){
buffer.write(str1,idx1,idx2-idx1);
buffer.write(str3);
idx1 = idx2 + length;
idx2 = Utils.indexOf(str2,str1,idx1);
}
if(idx1 > 0){
buffer.write(str1,idx1,str1.length-idx1);
return buffer.toByteArray();
}
return str1;return SQLTokenizer.REPLACE;return param1.isNull() || param2.isNull() || param3.isNull();if(isNull()) return null;
String str1 = param1.getString();
String str2  = param2.getString();
int length = str2.length();
if(length == 0){
return str1;
}
String str3  = param3.getString();
StringBuffer buffer = new StringBuffer();
int idx1 = 0;
int idx2 = str1.indexOf(str2,idx1);
while(idx2 >= 0){
buffer.append(str1.substring(idx1,idx2));
buffer.append(str3);
idx1 = idx2 + length;
idx2 = str1.indexOf(str2,idx1);
}
if(idx1 > 0){
buffer.append(str1.substring(idx1));
return buffer.toString();
}
return str1;return SSResultSetMetaData.getDataTypePrecision( getDataType(), -1 );return (long)getDouble();return (float)getDouble();return (int)getDouble();if(isNull()) return null;
return new Double(getDouble());if(isNull()) return null;
double value = getDouble();
if(Double.isInfinite(value) || Double.isNaN(value))
return null;
return new MutableNumeric(value);Object obj = getObject();
if(obj == null) return null;
return obj.toString();return param1.isNull();return SQLTokenizer.FLOAT;return getDouble() != 0;return Utils.doubleToMoney(getDouble());return getInt() != 0;return param1.isNull();return getInt() * 10000;if(isNull()) return null;
return new MutableNumeric(getInt());if(isNull()) return null;
return String.valueOf(getInt());return SQLTokenizer.INT;if(isNull()) return null;
return Utils.getInteger(getInt());return getInt();return getInt();return getInt();return param1.getScale();return param1.getDataType();if(isNull()) return null;
int dataType = getDataType();
switch(dataType){
case SQLTokenizer.BIT:
case SQLTokenizer.BOOLEAN:
return getBoolean() ? Boolean.TRUE : Boolean.FALSE;
case SQLTokenizer.BINARY:
case SQLTokenizer.VARBINARY:
return getBytes();
case SQLTokenizer.TINYINT:
case SQLTokenizer.SMALLINT:
case SQLTokenizer.INT:
return new Integer( getInt() );
case SQLTokenizer.BIGINT:
return new Long( getLong() );
case SQLTokenizer.REAL:
return new Float( getFloat() );
case SQLTokenizer.FLOAT:
case SQLTokenizer.DOUBLE:
return new Double( getDouble() );
case SQLTokenizer.MONEY:
case SQLTokenizer.SMALLMONEY:
return Money.createFromUnscaledValue( getMoney() );
case SQLTokenizer.NUMERIC:
case SQLTokenizer.DECIMAL:
return getNumeric();
case SQLTokenizer.CHAR:
case SQLTokenizer.NCHAR:
case SQLTokenizer.VARCHAR:
case SQLTokenizer.NVARCHAR:
case SQLTokenizer.LONGNVARCHAR:
case SQLTokenizer.LONGVARCHAR:
return getString();
case SQLTokenizer.LONGVARBINARY:
return getBytes();
case SQLTokenizer.DATE:
case SQLTokenizer.TIME:
case SQLTokenizer.TIMESTAMP:
case SQLTokenizer.SMALLDATETIME:
return new DateTime( getLong(), dataType );
case SQLTokenizer.UNIQUEIDENTIFIER:
return getBytes();
default: throw createUnspportedDataType(param1.getDataType());
}return param1.getPrecision();return param1.isNull();if(param1.isNull()) return null;
switch(getDataType()){
case SQLTokenizer.INT:
return new MutableNumeric(getInt());
case SQLTokenizer.BIGINT:
return new MutableNumeric(getLong());
case SQLTokenizer.MONEY:
return new MutableNumeric(getMoney(), 4);
case SQLTokenizer.DECIMAL:
MutableNumeric num = param1.getNumeric();
num.floor();
return num;
case SQLTokenizer.DOUBLE:
return new MutableNumeric(getDouble());
default:
throw new Error();
}if(isNull()) return null;
return getObject().toString();return Utils.double2long(getDouble());return ExpressionArithmetic.getBestNumberDataType(param1.getDataType());return getDouble() != 0;return Utils.long2int(getLong());return (float)getDouble();return Utils.doubleToMoney(getDouble());if(isNull()) return false;
return Utils.string2boolean(getString().trim());if(isNull()) return 0;
return Integer.parseInt(getString().trim());if(isNull()) return 0;
return Money.parseMoney(getString().trim());if(isNull()) return 0;
return Float.parseFloat(getString().trim());if(isNull()) return 0;
return Long.parseLong(getString().trim());if(isNull()) return 0;
return Double.parseDouble(getString().trim());if(SSResultSetMetaData.isBinaryDataType(param1.getDataType()))
return getBytes();
return getString();if(isNull()) return null;
return new MutableNumeric(getString().trim());if(isNull()) return false;
return Utils.string2boolean(getString().trim());if(isNull()) return 0;
return Integer.parseInt(getString().trim());if(isNull()) return 0;
return Money.parseMoney(getString().trim());return getString();if(isNull()) return 0;
return Float.parseFloat(getString().trim());if(isNull()) return 0;
return Long.parseLong(getString().trim());if(isNull()) return 0;
return Double.parseDouble(getString().trim());return param1.isNull();if(isNull()) return null;
return new MutableNumeric(getString().trim());return SQLTokenizer.RIGHT;if(isNull()) return null;
byte[] bytes = param1.getBytes();
int length = param2.getInt();
if(bytes.length <= length) return bytes;
byte[] b = new byte[length];
System.arraycopy(bytes, bytes.length -length, b, 0, length);
return b;return param1.isNull() || param2.isNull();if(isNull()) return null;
String str = param1.getString();
int length  = param2.getInt();
int start = str.length() - Math.min( length, str.length() );
return str.substring(start);return SQLTokenizer.ROUND;return param1.isNull() || param2.isNull();if(isNull()) return 0;
final int places = param2.getInt();
double value = param1.getDouble();
long factor = 1;
if(places > 0){
for(int i=0; i<places; i++){
factor *= 10;
}
value *= factor;
}else{
for(int i=0; i>places; i--){
factor *= 10;
}
value /= factor;
}
value = Math.rint( value );
if(places > 0){
value /= factor;
}else{
value *= factor;
}
return value;return SQLTokenizer.SIGN;if(param1.isNull()) return 0;
switch(ExpressionArithmetic.getBestNumberDataType(param1.getDataType())){
case SQLTokenizer.INT:
int intValue = param1.getInt();
if(intValue < 0)
return -1;
if(intValue > 0)
return 1;
return 0;
case SQLTokenizer.BIGINT:
long longValue = param1.getLong();
if(longValue < 0)
return -1;
if(longValue > 0)
return 1;
return 0;
case SQLTokenizer.MONEY:
longValue = param1.getMoney();
if(longValue < 0)
return -1;
if(longValue > 0)
return 1;
return 0;
case SQLTokenizer.DECIMAL:
return param1.getNumeric().getSignum();
case SQLTokenizer.DOUBLE:
double doubleValue = param1.getDouble();
if(doubleValue < 0)
return -1;
if(doubleValue > 0)
return 1;
return 0;
default:
throw new Error();
}return SQLTokenizer.SIN;if(isNull()) return 0;
return Math.sin( param1.getDouble() );char[] output = new char[4];
int idx = 0;
input = input.toUpperCase();
if(input.length()>0){
output[idx++] = input.charAt(0);
}
char last = '0';
for(int i=1; idx<4 && i<input.length(); i++){
char c = input.charAt(i);
switch(c){
case 'B':
case 'F':
case 'P':
case 'V':
c = '1';
break;
case 'C':
case 'G':
case 'J':
case 'K':
case 'Q':
case 'S':
case 'X':
case 'Z':
c = '2';
break;
case 'D':
case 'T':
c = '3';
break;
case 'L':
c = '4';
break;
case 'M':
case 'N':
c = '5';
break;
case 'R':
c = '6';
break;
default:
c = '0';
break;
}
if(c > '0' && last != c){
output[idx++] = c;
}
last = c;
}
for(; idx<4;){
output[idx++] = '0';
}
return new String(output);return param1.isNull();return 4;throw createUnspportedConversion(SQLTokenizer.BINARY);return SQLTokenizer.SOUNDEX;if(isNull()) return null;
String input = param1.getString();
return getString(input);return SQLTokenizer.VARCHAR;return param1.isNull() || param1.getInt()<0;if(isNull()) return null;
int size = param1.getInt();
if(size < 0){
return null;
}
char[] buffer = new char[size];
for(int i=0; i<size; i++){
buffer[i] = ' ';
}
return new String(buffer);return SQLTokenizer.SPACE;return SQLTokenizer.SQRT;if(isNull()) return 0;
return Math.sqrt( param1.getDouble() );if(isNull()) return null;
String str = param1.getString();
int strLen = str.length();
int start  = Math.min( Math.max( 0, param2.getInt() - 1), strLen);
int length = param3.getInt();
if(length < 0)
throw SmallSQLException.create(Language.SUBSTR_INVALID_LEN, new Integer(length));
length = Math.min( length, strLen-start );
return str.substring(start, start+length);return SQLTokenizer.SUBSTRING;if(isNull()) return null;
byte[] bytes = param1.getBytes();
int byteLen = bytes.length;
int start  = Math.min( Math.max( 0, param2.getInt() - 1), byteLen);
int length = param3.getInt();
if(length < 0)
throw SmallSQLException.create(Language.SUBSTR_INVALID_LEN, new Integer(length));
if(start == 0 && byteLen == length) return bytes;
if(byteLen > length + start){
byte[] b = new byte[length];
System.arraycopy(bytes, start, b, 0, length);
return b;
}else{
byte[] b = new byte[byteLen - start];
System.arraycopy(bytes, start, b, 0, b.length);
return b;
}return param1.isNull() || param2.isNull() || param3.isNull();return SQLTokenizer.TAN;if(isNull()) return 0;
return Math.tan( param1.getDouble() );return SQLTokenizer.TIMESTAMP;return SQLTokenizer.TIMESTAMPADD;return getLong() != 0;return getLong() * 10000;if(isNull()) return null;
return new DateTime( getLong(), SQLTokenizer.TIMESTAMP ).toString();if(isNull()) return null;
return new DateTime( getLong(), SQLTokenizer.TIMESTAMP );if(isNull()) return null;
return new MutableNumeric(getLong());if(isNull()) return 0;
switch(interval){
case SQLTokenizer.SQL_TSI_FRAC_SECOND:
return param2.getLong() + param1.getLong();
case SQLTokenizer.SQL_TSI_SECOND:
return param2.getLong() + param1.getLong() * 1000;
case SQLTokenizer.SQL_TSI_MINUTE:
return param2.getLong() + param1.getLong() * 60000;
case SQLTokenizer.SQL_TSI_HOUR:
return param2.getLong() + param1.getLong() * 3600000;
case SQLTokenizer.SQL_TSI_DAY:
return param2.getLong() + param1.getLong() * 86400000;
case SQLTokenizer.SQL_TSI_WEEK:{
return param2.getLong() + param1.getLong() * 604800000;
}case SQLTokenizer.SQL_TSI_MONTH:{
DateTime.Details details2 = new DateTime.Details(param2.getLong());
details2.month += param1.getLong();
return DateTime.calcMillis(details2);
}
case SQLTokenizer.SQL_TSI_QUARTER:{
DateTime.Details details2 = new DateTime.Details(param2.getLong());
details2.month += param1.getLong() * 3;
return DateTime.calcMillis(details2);
}
case SQLTokenizer.SQL_TSI_YEAR:{
DateTime.Details details2 = new DateTime.Details(param2.getLong());
details2.year += param1.getLong();
return DateTime.calcMillis(details2);
}
default: throw new Error();
}return getLong();return getLong();return (int)getLong();return param1.isNull() || param2.isNull();return getInt() != 0;if(isNull()) return 0;
switch(interval){
case SQLTokenizer.SQL_TSI_FRAC_SECOND:
return (int)(param2.getLong() - param1.getLong());
case SQLTokenizer.SQL_TSI_SECOND:
return (int)(param2.getLong() /1000 - param1.getLong() /1000);
case SQLTokenizer.SQL_TSI_MINUTE:
return (int)(param2.getLong() /60000 - param1.getLong() /60000);
case SQLTokenizer.SQL_TSI_HOUR:
return (int)(param2.getLong() /3600000 - param1.getLong() /3600000);
case SQLTokenizer.SQL_TSI_DAY:
return (int)(param2.getLong() /86400000 - param1.getLong() /86400000);
case SQLTokenizer.SQL_TSI_WEEK:{
long day2 = param2.getLong() /86400000;
long day1 = param1.getLong() /86400000;
return (int)((day2 + 3) / 7 - (day1 + 3) / 7);
}case SQLTokenizer.SQL_TSI_MONTH:{
DateTime.Details details2 = new DateTime.Details(param2.getLong());
DateTime.Details details1 = new DateTime.Details(param1.getLong());
return (details2.year * 12 + details2.month) - (details1.year * 12 + details1.month);
}
case SQLTokenizer.SQL_TSI_QUARTER:{
DateTime.Details details2 = new DateTime.Details(param2.getLong());
DateTime.Details details1 = new DateTime.Details(param1.getLong());
return (details2.year * 4 + details2.month / 3) - (details1.year * 4 + details1.month / 3);
}
case SQLTokenizer.SQL_TSI_YEAR:{
DateTime.Details details2 = new DateTime.Details(param2.getLong());
DateTime.Details details1 = new DateTime.Details(param1.getLong());
return details2.year - details1.year;
}
default: throw new Error();
}if(isNull()) return null;
return new MutableNumeric(getInt());return param1.isNull() || param2.isNull();return getInt() * 10000L;return SQLTokenizer.INT;if(isNull()) return null;
return Utils.getInteger(getInt());if(isNull()) return null;
return String.valueOf(getInt());return SQLTokenizer.TIMESTAMPDIFF;switch(intervalType){
case SQLTokenizer.MILLISECOND:
return SQLTokenizer.SQL_TSI_FRAC_SECOND;
case SQLTokenizer.SECOND:
return SQLTokenizer.SQL_TSI_SECOND;
case SQLTokenizer.MINUTE:
return SQLTokenizer.SQL_TSI_MINUTE;
case SQLTokenizer.HOUR:
return SQLTokenizer.SQL_TSI_HOUR;
case SQLTokenizer.D:
case SQLTokenizer.DAY:
return SQLTokenizer.SQL_TSI_DAY;
case SQLTokenizer.WEEK:
return SQLTokenizer.SQL_TSI_WEEK;
case SQLTokenizer.MONTH:
return SQLTokenizer.SQL_TSI_MONTH;
case SQLTokenizer.QUARTER:
return SQLTokenizer.SQL_TSI_QUARTER;
case SQLTokenizer.YEAR:
return SQLTokenizer.SQL_TSI_YEAR;
default:
return intervalType;
}return getInt();return getInt();return getInt();if(isNull()) return 0;
final int places = param2.getInt();
double value = param1.getDouble();
long factor = 1;
if(places > 0){
for(int i=0; i<places; i++){
factor *= 10;
}
value *= factor;
}else{
for(int i=0; i>places; i--){
factor *= 10;
}
value /= factor;
}
value -= value % 1;
if(places > 0){
value /= factor;
}else{
value *= factor;
}
return value;return param1.isNull() || param2.isNull();return SQLTokenizer.TRUNCATE;return param1.isNull();if(isNull()) return null;
return param1.getString().toUpperCase();if(isNull()) return null;
return getString().getBytes();return SQLTokenizer.UCASE;if(param1.isNull()) return 0;
DateTime.Details details = new DateTime.Details(param1.getLong());
return details.year;return SQLTokenizer.YEAR;loadInList();
return index.findRows(getParams(), false, null) != null;if(cmdSel.compile(con)){
cmdSel.from.execute();
if(cmdSel.columnExpressions.size() != 1)
throw SmallSQLException.create(Language.SUBQUERY_COL_COUNT, new Integer(cmdSel.columnExpressions.size()));
index.clear();
while(cmdSel.next()){
try{
index.addValues(0, cmdSel.columnExpressions );
}catch(Exception e){
}
}
}return fromEntry;return column.getScale();return fromEntry.getBoolean(colIdx);return colIdx;return fromEntry.getObject(colIdx);return column;return fromEntry.getMoney(colIdx);return fromEntry.getNumeric(colIdx);return column.isAutoIncrement();tableAlias = getName();
setName( name );return fromEntry.getString(colIdx);return column.getPrecision();return table;return true;if(table != null){
return table.getName();
}
return null;this.fromEntry  = fromEntry;
this.colIdx     = colIdx;
this.table      = table;
this.column		= table.columns.get(colIdx);this.fromEntry  = fromEntry;
this.colIdx     = colIdx;
this.column		= column;return column.isCaseSensitive();return column.isNullable();return tableAlias;if(tableAlias == null) return String.valueOf(getAlias());
return tableAlias + "." + getAlias();return fromEntry.isNull(colIdx);return fromEntry.getBytes(colIdx);return column.getDisplaySize();return fromEntry.getDouble(colIdx);return fromEntry.getLong(colIdx);return fromEntry.getFloat(colIdx);if(!super.equals(expr)) return false;
if(!(expr instanceof ExpressionName)) return false;
if( ((ExpressionName)expr).fromEntry != fromEntry) return false;
return true;switch(getType()){
case NAME:
case GROUP_BY:
return fromEntry.getDataType(colIdx);
case FIRST:
case LAST:
case MAX:
case MIN:
case SUM:
return getParams()[0].getDataType();
case COUNT:
return SQLTokenizer.INT;
default: throw new Error();
}return fromEntry.getInt(colIdx);return getNumeric( getObject(), dataType );return getInt( getObject(), dataType );if(!super.equals(expr)) return false;
if(!(expr instanceof ExpressionValue)) return false;
Object v = ((ExpressionValue)expr).value;
if(v == value) return true;
if(value == null) return false;
return value.equals(v);int type = getType();
if(type != GROUP_BY) expr = expr.getParams()[0];
switch(type){
case GROUP_BY:
case FIRST:
if(isEmpty()) set( expr.getObject(), expr.getDataType() );
break;
case LAST:
set( expr.getObject(), expr.getDataType() );
break;
case COUNT:
if(!expr.isNull()) ((MutableInteger)value).value++;
break;
case SUM:
if(isEmpty()){
initValue( expr );
}else
switch(dataType){
case SQLTokenizer.TINYINT:
case SQLTokenizer.SMALLINT:
case SQLTokenizer.INT:
((MutableInteger)value).value += expr.getInt();
break;
case SQLTokenizer.BIGINT:
((MutableLong)value).value += expr.getLong();
break;
case SQLTokenizer.REAL:
((MutableFloat)value).value += expr.getFloat();
break;
case SQLTokenizer.FLOAT:
case SQLTokenizer.DOUBLE:
((MutableDouble)value).value += expr.getDouble();
break;
case SQLTokenizer.NUMERIC:
case SQLTokenizer.DECIMAL:
MutableNumeric newValue = expr.getNumeric();
if(newValue != null)
((MutableNumeric)value).add( newValue );
break;
case SQLTokenizer.MONEY:
((Money)value).value += expr.getMoney();
break;
default: throw SmallSQLException.create(Language.UNSUPPORTED_TYPE_SUM, SQLTokenizer.getKeyWord(dataType));
}
break;
case MAX:
if(value == null){
if(expr.isNull())
dataType = expr.getDataType();
else
initValue( expr );
}else if(!expr.isNull()){
switch(dataType){
case SQLTokenizer.TINYINT:
case SQLTokenizer.SMALLINT:
case SQLTokenizer.INT:
((MutableInteger)value).value = Math.max( ((MutableInteger)value).value, expr.getInt());
break;
case SQLTokenizer.BIGINT:
((MutableLong)value).value = Math.max( ((MutableLong)value).value, expr.getLong());
break;
case SQLTokenizer.REAL:
((MutableFloat)value).value = Math.max( ((MutableFloat)value).value, expr.getFloat());
break;
case SQLTokenizer.FLOAT:
case SQLTokenizer.DOUBLE:
((MutableDouble)value).value = Math.max( ((MutableDouble)value).value, expr.getDouble());
break;
case SQLTokenizer.CHAR:
case SQLTokenizer.VARCHAR:
case SQLTokenizer.LONGVARCHAR:
String str = expr.getString();
if(String.CASE_INSENSITIVE_ORDER.compare( (String)value, str ) < 0)
value = str;
break;
case SQLTokenizer.NUMERIC:
case SQLTokenizer.DECIMAL:
MutableNumeric newValue = expr.getNumeric();
if(((MutableNumeric)value).compareTo( newValue ) < 0)
value = newValue;
break;
case SQLTokenizer.MONEY:
((Money)value).value = Math.max( ((Money)value).value, expr.getMoney());
break;
case SQLTokenizer.TIMESTAMP:
case SQLTokenizer.SMALLDATETIME:
case SQLTokenizer.DATE:
case SQLTokenizer.TIME:
((DateTime)value).time = Math.max( ((DateTime)value).time, expr.getLong());
break;
case SQLTokenizer.UNIQUEIDENTIFIER:
String uuidStr = expr.getString();
if (uuidStr.compareTo( (String)value) > 0) value = uuidStr;
break;
default:
String keyword = SQLTokenizer.getKeyWord(dataType);
throw SmallSQLException.create(Language.UNSUPPORTED_TYPE_MAX, keyword);
}
}
break;
case MIN:
if(value == null){
if(expr.isNull())
dataType = expr.getDataType();
else
initValue( expr );
}else if(!expr.isNull()){
switch(dataType){
case SQLTokenizer.TINYINT:
case SQLTokenizer.SMALLINT:
case SQLTokenizer.INT:
((MutableInteger)value).value = Math.min( ((MutableInteger)value).value, expr.getInt());
break;
case SQLTokenizer.BIGINT:
((MutableLong)value).value = Math.min( ((MutableLong)value).value, expr.getLong());
break;
case SQLTokenizer.REAL:
((MutableFloat)value).value = Math.min( ((MutableFloat)value).value, expr.getFloat());
break;
case SQLTokenizer.FLOAT:
case SQLTokenizer.DOUBLE:
((MutableDouble)value).value = Math.min( ((MutableDouble)value).value, expr.getDouble());
break;
case SQLTokenizer.CHAR:
case SQLTokenizer.VARCHAR:
case SQLTokenizer.LONGVARCHAR:
String str = expr.getString();
if(String.CASE_INSENSITIVE_ORDER.compare( (String)value, str ) > 0)
value = str;
break;
case SQLTokenizer.NUMERIC:
case SQLTokenizer.DECIMAL:
MutableNumeric newValue = expr.getNumeric();
if(((MutableNumeric)value).compareTo( newValue ) > 0)
value = newValue;
break;
case SQLTokenizer.MONEY:
((Money)value).value = Math.min( ((Money)value).value, expr.getMoney());
break;
case SQLTokenizer.TIMESTAMP:
case SQLTokenizer.SMALLDATETIME:
case SQLTokenizer.DATE:
case SQLTokenizer.TIME:
((DateTime)value).time = Math.min( ((DateTime)value).time, expr.getLong());
break;
default: throw new Error(""+dataType);
}
}
break;
default: throw new Error();
}switch(dataType){
case SQLTokenizer.VARCHAR:
case SQLTokenizer.CHAR:
return ((String)value).length();
case SQLTokenizer.VARBINARY:
case SQLTokenizer.BINARY:
return ((byte[])value).length;
default:
return super.getPrecision();
}if(obj == null) return 0;
switch(dataType){
case SQLTokenizer.BIT:
case SQLTokenizer.BOOLEAN:
return (obj == Boolean.TRUE) ? 1 : 0;
case SQLTokenizer.TINYINT:
case SQLTokenizer.SMALLINT:
case SQLTokenizer.INT:
case SQLTokenizer.BIGINT:
case SQLTokenizer.REAL:
case SQLTokenizer.FLOAT:
case SQLTokenizer.DOUBLE:
case SQLTokenizer.MONEY:
case SQLTokenizer.DECIMAL:
case SQLTokenizer.NUMERIC:
return ((Number)obj).intValue();
case SQLTokenizer.TIMESTAMP:
case SQLTokenizer.TIME:
case SQLTokenizer.DATE:
case SQLTokenizer.SMALLDATETIME:
return (int)((DateTime)obj).getTimeMillis();
default:
String str = obj.toString().trim();
try{
return Integer.parseInt( str );
}catch(Throwable th){}
return (int)Double.parseDouble( str );
}if(obj == null) return 0;
switch(dataType){
case SQLTokenizer.BIT:
return (obj.equals(Boolean.TRUE)) ? 1 : 0;
case SQLTokenizer.INT:
case SQLTokenizer.BIGINT:
case SQLTokenizer.DOUBLE:
case SQLTokenizer.MONEY:
return ((Number)obj).doubleValue();
case SQLTokenizer.TIMESTAMP:
case SQLTokenizer.TIME:
case SQLTokenizer.DATE:
case SQLTokenizer.SMALLDATETIME:
return ((DateTime)obj).getTimeMillis();
default: return Double.parseDouble( obj.toString() );
}dataType = expr.getDataType();
switch(dataType){
case SQLTokenizer.TINYINT:
case SQLTokenizer.SMALLINT:
case SQLTokenizer.INT:
value = new MutableInteger(expr.getInt());
break;
case SQLTokenizer.BIGINT:
value = new MutableLong(expr.getLong());
break;
case SQLTokenizer.REAL:
value = new MutableFloat(expr.getFloat());
break;
case SQLTokenizer.FLOAT:
case SQLTokenizer.DOUBLE:
value = new MutableDouble(expr.getDouble());
break;
case SQLTokenizer.SMALLMONEY:
case SQLTokenizer.MONEY:
value = Money.createFromUnscaledValue(expr.getMoney());
break;
case SQLTokenizer.NUMERIC:
case SQLTokenizer.DECIMAL:
value = new MutableNumeric(expr.getNumeric());
break;
case SQLTokenizer.TIMESTAMP:
case SQLTokenizer.SMALLDATETIME:
case SQLTokenizer.DATE:
case SQLTokenizer.TIME:
value = new DateTime(expr.getLong(), dataType);
break;
default:
value = expr.getObject();
}return getBoolean( getObject(), dataType );return null;return getLong( getObject(), dataType);if(obj == null) return null;
switch(dataType){
case SQLTokenizer.BINARY:
case SQLTokenizer.VARBINARY:
case SQLTokenizer.LONGVARBINARY:
return (byte[])obj;
case SQLTokenizer.VARCHAR:
case SQLTokenizer.CHAR:
case SQLTokenizer.NVARCHAR:
case SQLTokenizer.NCHAR:
return ((String)obj).getBytes();
case SQLTokenizer.UNIQUEIDENTIFIER:
return Utils.unique2bytes((String)obj);
case SQLTokenizer.INT:
return Utils.int2bytes( ((Number)obj).intValue() );
case SQLTokenizer.DOUBLE:
return Utils.double2bytes( ((Number)obj).doubleValue() );
case SQLTokenizer.REAL:
return Utils.float2bytes( ((Number)obj).floatValue() );
default: throw createUnsupportedConversion(dataType, obj, SQLTokenizer.VARBINARY);
}set( value, _dataType );
this.length = length;switch(dataType){
case SQLTokenizer.DECIMAL:
case SQLTokenizer.NUMERIC:
MutableNumeric obj = getNumeric();
return (obj == null) ? 0: obj.getScale();
default:
return getScale(dataType);
}return getFloat( getObject(), dataType);return getDouble( getObject(), dataType);if(obj == null) return 0;
switch(dataType){
case SQLTokenizer.BIT:
case SQLTokenizer.BOOLEAN:
return (obj == Boolean.TRUE) ? 1 : 0;
case SQLTokenizer.TINYINT:
case SQLTokenizer.SMALLINT:
case SQLTokenizer.INT:
case SQLTokenizer.BIGINT:
case SQLTokenizer.DOUBLE:
case SQLTokenizer.MONEY:
return ((Number)obj).longValue();
case SQLTokenizer.TIMESTAMP:
case SQLTokenizer.TIME:
case SQLTokenizer.DATE:
case SQLTokenizer.SMALLDATETIME:
return ((DateTime)obj).getTimeMillis();
default:
String str = obj.toString();
if(str.indexOf('-') > 0 || str.indexOf(':') > 0)
return DateTime.parse(str);
try{
return Long.parseLong( str );
}catch(NumberFormatException e){
return (long)Double.parseDouble( str );
}
}this.value      = newValue;
this.dataType   = newDataType;
if(dataType < 0){
if(newValue == null)
this.dataType = SQLTokenizer.NULL;
else
if(newValue instanceof String)
this.dataType = SQLTokenizer.VARCHAR;
else
if(newValue instanceof Byte)
this.dataType = SQLTokenizer.TINYINT;
else
if(newValue instanceof Short)
this.dataType = SQLTokenizer.SMALLINT;
else
if(newValue instanceof Integer)
this.dataType = SQLTokenizer.INT;
else
if(newValue instanceof Long || newValue instanceof Identity)
this.dataType = SQLTokenizer.BIGINT;
else
if(newValue instanceof Float)
this.dataType = SQLTokenizer.REAL;
else
if(newValue instanceof Double)
this.dataType = SQLTokenizer.DOUBLE;
else
if(newValue instanceof Number)
this.dataType = SQLTokenizer.DECIMAL;
else
if(newValue instanceof java.util.Date){
DateTime dateTime;
this.value = dateTime = DateTime.valueOf((java.util.Date)newValue);
this.dataType = dateTime.getDataType();
}else
if(newValue instanceof byte[])
this.dataType = SQLTokenizer.VARBINARY;
else
if(newValue instanceof Boolean)
this.dataType = SQLTokenizer.BOOLEAN;
else
if(newValue instanceof Money)
this.dataType = SQLTokenizer.MONEY;
else
throw SmallSQLException.create(Language.PARAM_CLASS_UNKNOWN, newValue.getClass().getName());
}if(obj == null) return 0;
switch(dataType){
case SQLTokenizer.BIT:
return (obj == Boolean.TRUE) ? 10000 : 0;
case SQLTokenizer.TINYINT:
case SQLTokenizer.SMALLINT:
case SQLTokenizer.INT:
case SQLTokenizer.BIGINT:
return ((Number)obj).longValue() * 10000;
case SQLTokenizer.REAL:
case SQLTokenizer.FLOAT:
case SQLTokenizer.DOUBLE:
return Utils.doubleToMoney(((Number)obj).doubleValue());
case SQLTokenizer.MONEY:
case SQLTokenizer.SMALLMONEY:
return ((Money)obj).value;
default: return Money.parseMoney( obj.toString() );
}this.value 		= val.value;
this.dataType	= val.dataType;
this.length		= val.length;value = EMPTY;Object obj = getObject();
if(obj == null) return null;
if(dataType == SQLTokenizer.BIT){
return (obj == Boolean.TRUE) ? "1" : "0";
}
return obj.toString();if(isEmpty()){
return null;
}
return value;if(obj == null) return null;
switch(dataType){
case SQLTokenizer.BIT:
return new MutableNumeric( (obj == Boolean.TRUE) ? 1 : 0);
case SQLTokenizer.INT:
return new MutableNumeric( ((Number)obj).intValue() );
case SQLTokenizer.BIGINT:
return new MutableNumeric( ((Number)obj).longValue() );
case SQLTokenizer.REAL:
float fValue = ((Number)obj).floatValue();
if(Float.isInfinite(fValue) || Float.isNaN(fValue))
return null;
return new MutableNumeric( fValue );
case SQLTokenizer.FLOAT:
case SQLTokenizer.DOUBLE:
double dValue = ((Number)obj).doubleValue();
if(Double.isInfinite(dValue) || Double.isNaN(dValue))
return null;
return new MutableNumeric( dValue );
case SQLTokenizer.MONEY:
case SQLTokenizer.SMALLMONEY:
return new MutableNumeric( ((Money)obj).value, 4 );
case SQLTokenizer.DECIMAL:
case SQLTokenizer.NUMERIC:
if(obj instanceof MutableNumeric)
return (MutableNumeric)obj;
return new MutableNumeric( (BigDecimal)obj );
default: return new MutableNumeric( obj.toString() );
}if(obj == null) return 0;
switch(dataType){
case SQLTokenizer.BIT:
return (obj.equals(Boolean.TRUE)) ? 1 : 0;
case SQLTokenizer.INT:
case SQLTokenizer.BIGINT:
case SQLTokenizer.DOUBLE:
case SQLTokenizer.FLOAT:
case SQLTokenizer.REAL:
case SQLTokenizer.MONEY:
return ((Number)obj).floatValue();
case SQLTokenizer.TIMESTAMP:
case SQLTokenizer.TIME:
case SQLTokenizer.DATE:
case SQLTokenizer.SMALLDATETIME:
return ((DateTime)obj).getTimeMillis();
default: return Float.parseFloat( obj.toString() );
}return getMoney( getObject(), dataType );return getObject() == null;return getBytes( getObject(), dataType);Object[] params = {
SQLTokenizer.getKeyWord(fromDataType),
obj,
SQLTokenizer.getKeyWord(toDataType)
};
return SmallSQLException.create(Language.UNSUPPORTED_CONVERSION, params);return value == EMPTY;if(obj == null) return false;
switch(dataType){
case SQLTokenizer.BIT:
case SQLTokenizer.BOOLEAN:
return (obj.equals(Boolean.TRUE));
case SQLTokenizer.TINYINT:
case SQLTokenizer.SMALLINT:
case SQLTokenizer.INT:
case SQLTokenizer.BIGINT:
return ((Number)obj).intValue() != 0;
case SQLTokenizer.REAL:
case SQLTokenizer.DOUBLE:
case SQLTokenizer.MONEY:
return ((Number)obj).doubleValue() != 0;
default: return Utils.string2boolean( obj.toString() );
}return dataType;System.arraycopy( data, idx+1, data, idx, (--size)-idx);Expression[] dataNew = new Expression[newSize];
System.arraycopy(data, 0, dataNew, 0, size);
data = dataNew;size = 0;if (expr == null) {
for (int i = 0; i < size; i++)
if (data[i]==null)
return i;
} else {
for (int i = 0; i < size; i++)
if (expr.equals(data[i]))
return i;
}
return -1;for(int i=newSize; i<size; i++) data[i] = null;
size = newSize;
if(size>data.length) resize(newSize);if (idx >= size)
throw new IndexOutOfBoundsException("Index: "+idx+", Size: "+size);
return data[idx];if(size >= data.length ){
resize(size << 1);
}
System.arraycopy( data, idx, data, idx+1, (size++)-idx);
data[idx] = expr;return size;Expression[] array = new Expression[size];
System.arraycopy( data, 0, array, 0, size);
return array;System.arraycopy( data, 0, array, 0, size);if(size >= data.length ){
resize(size << 1);
}
data[size++] = expr;int count = cols.size();
if(size + count >= data.length ){
resize(size + count);
}
System.arraycopy( cols.data, 0, data, size, count);
size += count;data[idx] = expr;ByteBuffer buffer = ByteBuffer.allocate(1);
buffer.put(rootPage.getUnique() ? (byte)1 : (byte)0 );
buffer.position(0);
raFile.write( buffer );
((FileIndexNode)rootPage).save();raFile.close();ByteBuffer buffer = ByteBuffer.allocate(1);
raFile.read(buffer);
buffer.position(0);
boolean unique = buffer.get() != 0;
FileIndexNode root = FileIndexNode.loadRootNode( unique, raFile, raFile.position() );
return new FileIndex( root, raFile );IndexScrollStatus scroll = index.createScrollStatus(expressions);
long l;
while((l= scroll.getRowOffset(true)) >=0){
System.out.println(l);
}
System.out.println("============================");StorePage storePage = new StorePage( null, -1, file, offset);
StoreImpl store = StoreImpl.createStore( null, storePage, SQLTokenizer.SELECT, offset);
FileIndexNode node = new FileIndexNode( unique, (char)store.readShort(), file );
node.fileOffset = offset;
node.load( store );
return node;StorePage storePage = new StorePage( null, -1, file, offset);
StoreImpl store = StoreImpl.createStore( null, storePage, SQLTokenizer.INSERT, fileOffset);
MemoryStream input = new MemoryStream();
FileIndexNode node = new FileIndexNode( getUnique(), (char)input.readShort(), file );
node.fileOffset = offset;
node.load( store );
return node;StorePage storePage = new StorePage( null, -1, file, fileOffset);
StoreImpl store = StoreImpl.createStore( null, storePage, SQLTokenizer.INSERT, fileOffset);
save(store);
fileOffset = store.writeFinsh(null);if(fileOffset < 0){
save();
}
output.writeLong(fileOffset);return new FileIndexNode(unique, digit, file);if (idx >= size)
throw new IndexOutOfBoundsException("Column index: "+idx+", Size: "+size);
return data[idx];return size;ForeignKey[] dataNew = new ForeignKey[newSize];
System.arraycopy(data, 0, dataNew, 0, size);
data = dataNew;if(size >= data.length ){
resize(size << 1);
}
data[size++] = foreignKey;int type = expr.getType();
if(type >= Expression.GROUP_BEGIN){
throw SmallSQLException.create(Language.GROUP_AGGR_INVALID, expr);
}else{
int idx = internalExpressions.indexOf(expr);
if(idx >= 0) return idx;
internalExpressions.add(expr);
return internalExpressions.size()-1;
}ExpressionValue[] newRow = currentRow = new ExpressionValue[ expressions.size()];
for(int i=0; i<newRow.length; i++){
Expression expr = expressions.get(i);
int type = expr.getType();
if(type < Expression.GROUP_BEGIN) type = Expression.GROUP_BY;
newRow[i] = new ExpressionValue( type );
}
addRow(newRow);for(int i=0; i<currentRow.length; i++){
Expression src = expressions.get(i);
currentRow[i].accumulate(src);
}int idx = addInternalExpressionFromSelect( expr );
if(idx>=0){
Expression origExpression = expr;
ExpressionName exprName;
if(expr instanceof ExpressionName){
exprName = (ExpressionName)expr;
}else{
expr = exprName = new ExpressionName(expr.getAlias());
}
Column column = exprName.getColumn();
if(column == null){
column = new Column();
exprName.setFrom(this, idx, column);
switch(exprName.getType()){
case Expression.MAX:
case Expression.MIN:
case Expression.FIRST:
case Expression.LAST:
case Expression.SUM:
Expression baseExpression = exprName.getParams()[0];
column.setPrecision(baseExpression.getPrecision());
column.setScale(baseExpression.getScale());
break;
default:
column.setPrecision(origExpression.getPrecision());
column.setScale(origExpression.getScale());
}
column.setDataType(exprName.getDataType());
}else{
exprName.setFrom(this, idx, column);
}
}else{
patchExpressions(expr);
}
return expr;super.execute();
from.execute();
NextRow:
while(from.next()){
beforeFirst();
while(next()){
if(currentGroup == null || currentGroup.getBoolean()){
accumulateRow();
continue NextRow;
}
}
addGroupRow();
accumulateRow();
}
if(getRowCount() == 0 && groupBy == null){
addGroupRow();
}
beforeFirst();if(exprs == null) return;
for(int i=0; i<exprs.size(); i++){
exprs.set(i, patchExpression(exprs.get(i)));
}int type = expr.getType();
if(type == Expression.NAME){
int idx = internalExpressions.indexOf(expr);
if(idx >= 0) return idx;
throw SmallSQLException.create(Language.GROUP_AGGR_NOTPART, expr);
}else
if(type >= Expression.GROUP_BEGIN){
int idx = internalExpressions.indexOf(expr);
if(idx >= 0) return idx;
internalExpressions.add(expr);
return internalExpressions.size()-1;
}else{
int idx = internalExpressions.indexOf(expr);
if(idx >= 0) return idx;
Expression[] params = expr.getParams();
if(params != null){
for(int p=0; p<params.length; p++){
addInternalExpressionFromSelect( params[p]);
}
}
return -1;
}Expression[] params = expression.getParams();
if(params == null) return;
for(int i=0; i<params.length; i++){
expression.setParamAt( patchExpression(params[i]), i);
}return String.valueOf(value);value++;
con.add( createStorePage() );page[ 0 ] = (byte)(value >> 56);
page[ 1 ] = (byte)(value >> 48);
page[ 2 ] = (byte)(value >> 40);
page[ 3 ] = (byte)(value >> 32);
page[ 4 ] = (byte)(value >> 24);
page[ 5 ] = (byte)(value >> 16);
page[ 6 ] = (byte)(value >> 8);
page[ 7 ] = (byte)(value);
return new StorePage( page, 8, raFile, filePos);long newValue = expr.getLong();
if(newValue > value){
value = newValue;
createStorePage().commit();
}return value;return value;return value;return new Long(value);return (int)value;int length = value.length();
if(needTrim){
while(length > 0 && value.charAt(length-1) == ' ') length--;
}
char[] puffer = new char[length];
for(int i=0; i<length; i++){
puffer[i] = Character.toLowerCase(Character.toUpperCase( value.charAt(i) ));
}
return puffer;for(int i=digitCount-1; i>=0; i--){
char digit = (char)(key >> (i<<4));
if(i == 0){
if(isLastValue){
node.addNode( digit, rowOffset );
return null;
}
return node.addRoot(digit);
}
node = node.addNode(digit);
if(node.isEmpty()){
if(isLastValue){
node.addRemainderKey( rowOffset, key, i );
return null;
}
return node.addRootValue( key, i);
}else
if(equals(node.getRemainderValue(), key, i)){
if(isLastValue){
node.saveValue( rowOffset);
return null;
}
return node.addRoot();
}
}
throw new Error();if(expr.isNull()){
if(!searchNullValues){
return null;
}
page = findNull(page);
}else{
switch(expr.getDataType()){
case SQLTokenizer.REAL:
page = find( page, floatToBinarySortOrder( expr.getFloat()), 2, nodeList );
break;
case SQLTokenizer.DOUBLE:
case SQLTokenizer.FLOAT:
page = find( page, doubleToBinarySortOrder( expr.getDouble()), 4, nodeList );
break;
case SQLTokenizer.TINYINT:
page = find( page, expr.getInt(), 1, nodeList );
break;
case SQLTokenizer.SMALLINT:
page = find( page, shortToBinarySortOrder( expr.getInt()), 1, nodeList );
break;
case SQLTokenizer.INT:
page = find( page, intToBinarySortOrder( expr.getInt()), 2, nodeList );
break;
case SQLTokenizer.BIGINT:
case SQLTokenizer.DATE:
case SQLTokenizer.TIME:
case SQLTokenizer.TIMESTAMP:
case SQLTokenizer.SMALLDATETIME:
case SQLTokenizer.MONEY:
case SQLTokenizer.SMALLMONEY:
page = find( page, longToBinarySortOrder( expr.getLong()), 4, nodeList );
break;
case SQLTokenizer.VARCHAR:
case SQLTokenizer.NVARCHAR:
case SQLTokenizer.LONGVARCHAR:
case SQLTokenizer.LONGNVARCHAR:
case SQLTokenizer.CLOB:
page = find( page, stringToBinarySortOrder( expr.getString(), false ), nodeList );
break;
case SQLTokenizer.NCHAR:
case SQLTokenizer.CHAR:
page = find( page, stringToBinarySortOrder( expr.getString(), true ), nodeList );
break;
case SQLTokenizer.VARBINARY:
case SQLTokenizer.BINARY:
case SQLTokenizer.LONGVARBINARY:
case SQLTokenizer.BLOB:
case SQLTokenizer.UNIQUEIDENTIFIER:
page = find( page, bytesToBinarySortOrder( expr.getBytes()), nodeList );
break;
case SQLTokenizer.BIT:
case SQLTokenizer.BOOLEAN:
page = find( page, expr.getBoolean() ? 2 : 1, 1, nodeList );
break;
case SQLTokenizer.NUMERIC:
case SQLTokenizer.DECIMAL:
page = find( page, numericToBinarySortOrder( expr.getNumeric() ), nodeList );
break;
default:
throw new Error(String.valueOf(expr.getDataType()));
}
}
return page;rootPage.clear();return value ^ 0x80000000;int length = value.length;
char[] puffer = new char[length];
for(int i=0; i<length; i++){
puffer[i] = (char)(value[i] & 0xFF);
}
return puffer;return new IndexScrollStatus(rootPage, expressions);int length = key.length;
int i=-1;
while(true){
char digit = (i<0) ? (length == 0 ? (char)1 : 2)
: (key[i]);
if(++i == length){
if(isLast){
node.addNode( digit, rowOffset );
return null;
}
return node.addRoot(digit);
}
node = node.addNode(digit);
if(node.isEmpty()){
if(isLast){
node.addRemainderKey( rowOffset, key, i );
return null;
}
return node.addRootValue( key, i );
}else
if(equals(node.getRemainderValue(), key, i)){
if(isLast){
node.saveValue(rowOffset);
return null;
}
return node.addRoot();
}
}ArrayList nodeList = new ArrayList();
Object obj = findRows(expressions, true, nodeList);
if(!rootPage.getUnique()){
LongTreeList list = (LongTreeList)obj;
list.remove(rowOffset);
if(list.getSize() > 0) return;
}
IndexNode node = (IndexNode)nodeList.get(nodeList.size()-1);
node.clearValue();
for(int i = nodeList.size()-2; i >= 0; i--){
if(!node.isEmpty())
break;
IndexNode parent = (IndexNode)nodeList.get(i);
parent.removeNode( node.getDigit() );
node = parent;
}return value ^ 0x8000000000000000L;if(isLastValue){
page.addNode( (char)0, rowOffset );
return null;
}else
return page.addRoot((char)0);int[] value = numeric.getInternalValue();
int count = 1;
int i;
for(i=0; i<value.length; i++){
if(value[i] != 0){
count = 2*(value.length - i)+1;
break;
}
}
char[] puffer = new char[count];
puffer[0] = (char)count;
for(int c=1; c<count;){
puffer[c++] = (char)(value[i] >> 16);
puffer[c++] = (char)value[i++];
}
return puffer;IndexNode page = rootPage;
int count = expressions.size();
for(int i = 0; i < count; i++){
page = findRows(page, expressions.get(i), searchNullValues, nodeList);
if(page == null)
return null;
if(i + 1 == count)
return page.getValue();
else
page = (IndexNode)page.getValue();
}
throw new Error();return page.getChildNode( (char)0 );long intValue = Double.doubleToLongBits(value);
return (intValue<0) ?
~intValue :
intValue ^ 0x8000000000000000L;int length = key.length;
int i=-1;
while(true){
char digit = (i<0) ? (length == 0 ? (char)1 : 2)
: (key[i]);
node = node.getChildNode(digit);
if(node == null) return null;
if(nodeList != null) nodeList.add(node);
if(++i == length){
return node;
}
if(equals(node.getRemainderValue(), key, i)){
return node;
}
}return value ^ 0x8000;IndexNode page = rootPage;
int count = expressions.length;
for(int i = 0; i < count; i++){
page = findRows(page, expressions[i], searchNullValues, nodeList);
if(page == null)
return null;
if(i + 1 == count)
return page.getValue();
else
page = (IndexNode)page.getValue();
}
throw new Error();int intValue = Float.floatToIntBits(value);
return (intValue<0) ?
~intValue :
intValue ^ 0x80000000;for(int i=digitCount-1; i>=0; i--){
char digit = (char)(key >> (i<<4));
node = node.getChildNode(digit);
if(node == null) return null;
if(nodeList != null) nodeList.add(node);
if(equals(node.getRemainderValue(), key, i)){
return node;
}
}
return node;if(src1 == null) return false;
int length = src1.length;
if(length != charCount) return false;
for(int i=0, d = charCount-1; i<length; i++){
if(src1[i] != (char)((src2 >> (d-- << 4)))) return false;
}
return true;IndexNode page = this.rootPage;
int count = expressions.size();
for(int i=0; i<count; i++){
Expression expr = expressions.get(i);
boolean isLastValues = (i == count-1);
if(expr.isNull()){
page = addNull(page, rowOffset, isLastValues);
}else{
switch(expr.getDataType()){
case SQLTokenizer.REAL:
page = add( page, rowOffset, floatToBinarySortOrder( expr.getFloat()), isLastValues, 2 );
break;
case SQLTokenizer.DOUBLE:
case SQLTokenizer.FLOAT:
page = add( page, rowOffset, doubleToBinarySortOrder( expr.getDouble()), isLastValues, 4 );
break;
case SQLTokenizer.TINYINT:
page = add( page, rowOffset, expr.getInt(), isLastValues, 1 );
break;
case SQLTokenizer.SMALLINT:
page = add( page, rowOffset, shortToBinarySortOrder( expr.getInt()), isLastValues, 1 );
break;
case SQLTokenizer.INT:
page = add( page, rowOffset, intToBinarySortOrder( expr.getInt()), isLastValues, 2 );
break;
case SQLTokenizer.BIGINT:
case SQLTokenizer.DATE:
case SQLTokenizer.TIME:
case SQLTokenizer.TIMESTAMP:
case SQLTokenizer.SMALLDATETIME:
case SQLTokenizer.MONEY:
case SQLTokenizer.SMALLMONEY:
page = add( page, rowOffset, longToBinarySortOrder( expr.getLong()), isLastValues, 4 );
break;
case SQLTokenizer.VARCHAR:
case SQLTokenizer.NVARCHAR:
case SQLTokenizer.LONGVARCHAR:
case SQLTokenizer.LONGNVARCHAR:
page = add( page, rowOffset, stringToBinarySortOrder( expr.getString(), false ), isLastValues );
break;
case SQLTokenizer.NCHAR:
case SQLTokenizer.CHAR:
page = add( page, rowOffset, stringToBinarySortOrder( expr.getString(), true ), isLastValues );
break;
case SQLTokenizer.VARBINARY:
case SQLTokenizer.BINARY:
case SQLTokenizer.LONGVARBINARY:
case SQLTokenizer.BLOB:
case SQLTokenizer.UNIQUEIDENTIFIER:
page = add( page, rowOffset, bytesToBinarySortOrder( expr.getBytes()), isLastValues );
break;
case SQLTokenizer.BIT:
case SQLTokenizer.BOOLEAN:
page = add( page, rowOffset, expr.getBoolean() ? 2 : 1, isLastValues, 1 );
break;
case SQLTokenizer.NUMERIC:
case SQLTokenizer.DECIMAL:
page = add( page, rowOffset, numericToBinarySortOrder( expr.getNumeric()), isLastValues );
break;
default:
throw new Error(String.valueOf(expr.getDataType()));
}
}
}if(src1 == null) return false;
int length = src1.length;
if(length != src2.length - offset2) return false;
for(int i=0; i<length; i++){
if(src1[i] != src2[i+offset2]) return false;
}
return true;return constraintType == SQLTokenizer.PRIMARY;store.writeInt(constraintType);
store.writeInt(columns.size());
for(int c=0; c<columns.size(); c++){
store.writeString( columns.get(c) );
}
store.writeString(name);if( database.isReadOnly() ){
throw SmallSQLException.create(Language.DB_READONLY);
}
File file = getFile( database, name );
boolean ok = file.createNewFile();
if(!ok) throw SmallSQLException.create(Language.INDEX_EXISTS, name);
FileChannel randomFile = Utils.openRaFile( file, database.isReadOnly() );
con.add(new CreateFile(file, randomFile, con, database));
writeMagic(randomFile);
return randomFile;int size = tableView.columns.size();
matrix = new int[size];
for(int i=0; i<matrix.length; i++){
matrix[i] = -1;
}
for(int i=0; i<columns.size(); i++){
matrix[tableView.findColumnIdx(columns.get(i))] = i;
}return columns;close();
boolean ok = getFile( database, name).delete();
if(!ok) throw SmallSQLException.create(Language.TABLE_CANT_DROP, name);return constraintType == SQLTokenizer.PRIMARY || constraintType == SQLTokenizer.UNIQUE;if(defaultName == null){
defaultName = tableName + "_" + Long.toHexString(System.currentTimeMillis()) + Integer.toHexString(new Object().hashCode());
}
return defaultName;if(strings.size() < columns.size())
return Integer.MAX_VALUE;
nextColumn:
for(int c=0; c<columns.size(); c++){
String colName = columns.get(c);
for(int s=0; s<strings.size(); s++){
if(colName.equalsIgnoreCase(strings.get(s)) )
continue nextColumn;
}
return Integer.MAX_VALUE;
}
return strings.size() - columns.size();return name;int idx = matrix[columnIdx];
if(idx >= 0)
expressions.set(idx, valueExpression);int constraintType = store.readInt();
int count = store.readInt();
Strings columns = new Strings();
Expressions expressions = new Expressions();
SQLParser sqlParser = new SQLParser();
for(int c=0; c<count; c++){
String column = store.readString();
columns.add( column );
expressions.add( sqlParser.parseExpression(column));
}
IndexDescription indexDesc = new IndexDescription( store.readString(), tableView.name, constraintType, expressions, columns);
indexDesc.init( database, tableView );
indexDesc.load(database);
return indexDesc;return new File( Utils.createIdxFileName( database, name ) );if(raFile != null){
raFile.close();
raFile = null;
}try{
File file = getFile( database, name );
if(!file.exists())
throw SmallSQLException.create(Language.INDEX_MISSING, name);
raFile = Utils.openRaFile( file, database.isReadOnly() );
ByteBuffer buffer = ByteBuffer.allocate(8);
raFile.read(buffer);
buffer.position(0);
int magic   = buffer.getInt();
int version = buffer.getInt();
if(magic != MAGIC_INDEX){
throw SmallSQLException.create(Language.INDEX_FILE_INVALID, file.getName());
}
if(version > INDEX_VERSION){
Object[] params = { new Integer(version), file.getName() };
throw SmallSQLException.create(Language.FILE_TOONEW, params);
}
}catch(Throwable e){
if(raFile != null)
try{
raFile.close();
}catch(Exception e2){
DriverManager.println(e2.toString());
}
throw SmallSQLException.createFromException(e);
}ByteBuffer buffer = ByteBuffer.allocate(8);
buffer.putInt(MAGIC_INDEX);
buffer.putInt(INDEX_VERSION);
buffer.position(0);
raFile.write(buffer);init( database, tableView );
raFile = createFile( con, database );for(int i=0; i<size; i++){
data[i].create(con, database, tableView);
}if(size >= data.length ){
resize(size << 1);
}
if(hasPrimary && descr.isPrimary()){
throw SmallSQLException.create(Language.PK_ONLYONE);
}
hasPrimary = descr.isPrimary();
data[size++] = descr;int bestFactor = Integer.MAX_VALUE;
int bestIdx = 0;
for(int i=0; i<size; i++){
int factor = data[i].matchFactor(columns);
if(factor == 0)
return data[i];
if(factor < bestFactor){
bestFactor = factor;
bestIdx = i;
}
}
if(bestFactor == Integer.MAX_VALUE)
return null;
else
return data[bestIdx];return size;for(int i=0; i<size; i++){
data[i].close();
}if (idx >= size)
throw new IndexOutOfBoundsException("Column index: "+idx+", Size: "+size);
return data[idx];for(int i=0; i<indexes.size; i++){
add(indexes.data[i]);
}for(int i=0; i<size; i++){
data[i].drop(database);
}IndexDescription[] dataNew = new IndexDescription[newSize];
System.arraycopy(data, 0, dataNew, 0, size);
data = dataNew;int length = remainderValue.length-offset;
this.remainderKey = new char[length];
System.arraycopy( remainderValue, offset, this.remainderKey, 0, length);int length = nodes.length;
IndexNode[] temp = new IndexNode[length+1];
if(length == 0){
temp[0] = node;
}else{
int pos = findNodeInsertPos( node.digit, 0, length);
System.arraycopy(nodes, 0, temp, 0, pos);
System.arraycopy(nodes, pos, temp, pos+1, length-pos);
temp[pos] = node;
}
nodes = temp;IndexNode node = addNode(digit);
if(node.remainderKey != null) node.moveRemainderValue();
node.saveValue(rowOffset);saveRemainderValue(remainderValue, offset);
return addRoot();return findNodePos(digit, 0, nodes.length);int pos = findNodePos( digit );
if(pos != -1){
int length = nodes.length-1;
IndexNode[] temp = new IndexNode[length];
System.arraycopy(nodes, 0, temp, 0, pos);
System.arraycopy(nodes, pos+1, temp, pos, length-pos);
nodes = temp;
}int pos = findNodePos(digit);
if(pos >=0) return nodes[pos];
return null;nodes = EMPTY_NODES;
value = null;
remainderKey = null;return new IndexNode(unique, digit);int length = remainderValue.length-1;
this.remainderKey = new char[length];
value = rowOffset;
System.arraycopy( remainderValue, 1, this.remainderKey, 0, length);throw new Error();saveRemainderValue(remainderValue, charCount);
value = (unique) ? (Object)new Long(rowOffset) : new LongTreeList(rowOffset);output.writeShort(digit);
int length = remainderKey == null ? 0 : remainderKey.length;
output.writeInt(length);
if(length>0) output.writeChars(remainderKey);
if(value == null){
output.writeByte(0);
}else
if(value instanceof Long){
output.writeByte(1);
output.writeLong( ((Long)value).longValue() );
}else
if(value instanceof LongTreeList){
output.writeByte(2);
((LongTreeList)value).save(output);
}else
if(value instanceof IndexNode){
output.writeByte(3);
((IndexNode)value).saveRef(output);
}
output.writeShort(nodes.length);
for(int i=0; i<nodes.length; i++){
nodes[i].saveRef( output );
}return remainderKey;IndexNode node = addNode(digit);
if(node.remainderKey != null) node.moveRemainderValue();
return node.addRoot();saveRemainderValue(remainderValue, digitCount);
return addRoot();return nodes;saveRemainderValue(remainderValue, offset);
value = (unique) ? (Object)new Long(rowOffset) : new LongTreeList(rowOffset);return value;IndexNode root = (IndexNode)value;
if(root == null){
value = root = createIndexNode(unique, (char)-1);
}
return root;return unique;Object rowOffset = value;
char[] puffer = remainderKey;
value = null;
remainderKey = null;
IndexNode newNode = addNode(puffer[0]);
if(puffer.length == 1){
newNode.value  = rowOffset;
}else{
newNode.moveRemainderValueSub( rowOffset, puffer);
}if(start == nodes.length) return -1;
int mid = start + (end - start)/2;
char nodeDigit = nodes[mid].digit;
if(nodeDigit == digit) return mid;
if(nodeDigit < digit){
return findNodePos( digit, mid+1, end );
}else{
if(start == mid) return -1;
return findNodePos( digit, start, mid-1 );
}return digit;value = null;if(unique){
if(value != null) throw SmallSQLException.create(Language.KEY_DUPLICATE);
value = new Long(rowOffset);
}else{
LongTreeList list = (LongTreeList)value;
if(list == null){
value = list = new LongTreeList();
}
list.add(rowOffset);
}return nodes == EMPTY_NODES && value == null;if(start == end) return start;
int mid = start + (end - start)/2;
char nodeDigit = nodes[mid].digit;
if(nodeDigit == digit) return mid;
if(nodeDigit < digit){
return findNodeInsertPos( digit, mid+1, end );
}else{
if(start == mid) return start;
return findNodeInsertPos( digit, start, mid );
}int length = input.readInt();
remainderKey = (length>0) ? input.readChars(length) : null;
int valueType = input.readByte();
switch(valueType){
case 0:
value = null;
break;
case 1:
value = new Long(input.readLong());
break;
case 2:
value = new LongTreeList(input);
break;
case 3:
value = loadRef( input.readLong());
break;
default:
throw SmallSQLException.create(Language.INDEX_CORRUPT, String.valueOf(valueType));
}
nodes = new IndexNode[input.readShort()];
for(int i=0; i<nodes.length; i++){
nodes[i] = loadRef( input.readLong() );
}this.remainderKey = new char[charCount];
for(int i=charCount-1, d=0; i>=0; i--){
this.remainderKey[d++] = (char)(remainderValue >> (i<<4));
}if(remainderKey != null) moveRemainderValue();
int pos = findNodePos( digit );
if(pos == -1){
IndexNode node = createIndexNode(unique, digit);
saveNode( node );
return node;
}else{
return nodes[pos];
}idx = (asc) ? nodes.length : -2;nodeStack.clear();
boolean asc = (expressions.get(0).getAlias() != SQLTokenizer.DESC_STR);
nodeStack.push( new IndexNodeScrollStatus(rootPage, asc, true, 0) );if(longList != null){
long rowOffset = scroll ?
longList.getNext(longListEnum) :
longList.getPrevious(longListEnum);
if(rowOffset < 0){
longList = null;
}else{
return rowOffset;
}
}
while(true){
IndexNodeScrollStatus status = (IndexNodeScrollStatus)nodeStack.peek();
int level = status.level;
if(!status.asc ^ scroll){
int idx = ++status.idx;
if(idx == -1){
if(status.nodeValue != null){
if(status.nodeValue instanceof IndexNode){
level++;
nodeStack.push(
new IndexNodeScrollStatus( 	(IndexNode)status.nodeValue,
(expressions.get(level).getAlias() != SQLTokenizer.DESC_STR),
scroll, level));
continue;
}else
return getReturnValue(status.nodeValue);
}
idx = ++status.idx;
}
if(idx >= status.nodes.length){
if(nodeStack.size() > 1){
nodeStack.pop();
continue;
}else{
status.idx = status.nodes.length;
return -1;
}
}
IndexNode node = status.nodes[idx];
nodeStack.push( new IndexNodeScrollStatus(node, status.asc, scroll, level) );
}else{
int idx = --status.idx;
if(idx == -1){
if(status.nodeValue != null){
if(status.nodeValue instanceof IndexNode){
level++;
nodeStack.push(
new IndexNodeScrollStatus( 	(IndexNode)status.nodeValue,
(expressions.get(level).getAlias() != SQLTokenizer.DESC_STR),
scroll, level));
continue;
}else
return getReturnValue(status.nodeValue);
}
}
if(idx < 0){
if(nodeStack.size() > 1){
nodeStack.pop();
continue;
}else{
return -1;
}
}
IndexNode node = status.nodes[idx];
nodeStack.push( new IndexNodeScrollStatus(node, status.asc, scroll, level) );
}
}if(rootPage.getUnique()){
return ((Long)value).longValue();
}else{
longList = (LongTreeList)value;
longListEnum.reset();
return longList.getNext(longListEnum);
}longList = null;
nodeStack.setSize(1);
((IndexNodeScrollStatus)nodeStack.peek()).afterLast();if(isAfterLast) return false;
row++;
boolean result = scroll.next();
if(!result){
noRow();
}
return result;Expression[] params = cond.getParams();
int op = cond.getOperation();
if(op == ExpressionArithmetic.AND){
Expression param0 = params[0];
Expression param1 = params[1];
if(param0 instanceof ExpressionArithmetic && param1 instanceof ExpressionArithmetic){
op = createJoinScrollIndex((ExpressionArithmetic)param0, leftEx, rightEx, operation);
if(op == 0){
return 0;
}
return createJoinScrollIndex((ExpressionArithmetic)param1, leftEx, rightEx, operation);
}
return 0;
}
if(operation == 0){
operation = op;
}
if(operation != op){
return 0;
}
if(operation == ExpressionArithmetic.EQUALS){
Expression param0 = params[0];
Expression param1 = params[1];
Expressions columns0 = Utils.getExpressionNameFromTree(param0);
Expressions columns1 = Utils.getExpressionNameFromTree(param1);
if(left.isExpressionsFromThisRowSource(columns0) && right.isExpressionsFromThisRowSource(columns1)){
leftEx.add( param0 );
rightEx.add( param1 );
}else{
if(left.isExpressionsFromThisRowSource(columns1) && right.isExpressionsFromThisRowSource(columns0)){
leftEx.add( param1 );
rightEx.add( param0 );
}else{
return 0;
}
}
return operation;
}
return 0;isAfterLast = true;
noRow();scroll.beforeFirst();
isAfterLast  = false;
row = 0;if(rowPositions == null) rowPositions = new LongLongList();
rowPositions.add( left.getRowPosition(), right.getRowPosition());
return rowPositions.size()-1;return left.rowDeleted() || right.rowDeleted();left.execute();
right.execute();
if(!createJoinScrollIndex()){
scroll = new JoinScroll(type, left, right, condition);
}left.nullRow();
right.nullRow();
row = 0;return false;left .setRowPosition( rowPositions.get1((int)rowPosition));
right.setRowPosition( rowPositions.get2((int)rowPosition));if(left.isExpressionsFromThisRowSource(columns) || right.isExpressionsFromThisRowSource(columns)){
return true;
}
if(columns.size() == 1){
return false;
}
Expressions single = new Expressions();
for(int i=0; i<columns.size(); i++){
single.clear();
single.add(columns.get(i));
if(left.isExpressionsFromThisRowSource(columns) || right.isExpressionsFromThisRowSource(columns)){
continue;
}
return false;
}
return true;if(type == CROSS_JOIN){
return false;
}
if(type != INNER_JOIN){
return false;
}
if(condition instanceof ExpressionArithmetic){
ExpressionArithmetic cond = (ExpressionArithmetic)condition;
Expressions leftEx = new Expressions();
Expressions rightEx = new Expressions();
int operation = createJoinScrollIndex(cond, leftEx, rightEx, 0);
if(operation != 0){
scroll = new JoinScrollIndex( type, left, right, leftEx, rightEx, operation);
return true;
}
}
return false;beforeFirst();
return next();return left.rowInserted() || right.rowInserted();return row;isAfterLast = true;
left.noRow();
right.noRow();
row = 0;boolean result;
if(fullReturnCounter >=0){
do{
if(fullReturnCounter >= fullRowCount){
return false;
}
right.next();
}while(isFullNotValid[fullReturnCounter++]);
return true;
}
do{
if(isBeforeFirst){
result = left.next();
if(result){
result = right.first();
if(!result){
switch(type){
case Join.LEFT_JOIN:
case Join.FULL_JOIN:
isOuterValid = false;
isBeforeFirst = false;
right.nullRow();
return true;
}
}else fullRightRowCounter++;
}else{
if(type == Join.FULL_JOIN){
while(right.next()){
fullRightRowCounter++;
}
fullRowCount = fullRightRowCounter;
}
}
}else{
result = right.next();
if(!result){
switch(type){
case Join.LEFT_JOIN:
case Join.FULL_JOIN:
if(isOuterValid){
isOuterValid = false;
right.nullRow();
return true;
}
fullRowCount = Math.max( fullRowCount, fullRightRowCounter);
fullRightRowCounter = 0;
}
isOuterValid = true;
result = left.next();
if(result){
result = right.first();
if(!result){
switch(type){
case Join.LEFT_JOIN:
case Join.FULL_JOIN:
isOuterValid = false;
right.nullRow();
return true;
}
}else fullRightRowCounter++;
}
}else fullRightRowCounter++;
}
isBeforeFirst = false;
}while(result && !getBoolean());
isOuterValid = false;
if(type == Join.FULL_JOIN){
if(fullRightRowCounter >= isFullNotValid.length){
boolean[] temp = new boolean[fullRightRowCounter << 1];
System.arraycopy( isFullNotValid, 0, temp, 0, fullRightRowCounter);
isFullNotValid = temp;
}
if(!result){
if(fullRowCount == 0){
return false;
}
if(fullReturnCounter<0) {
fullReturnCounter = 0;
right.first();
left.nullRow();
}
while(isFullNotValid[fullReturnCounter++]){
if(fullReturnCounter >= fullRowCount){
return false;
}
right.next();
}
return true;
}else
isFullNotValid[fullRightRowCounter-1] = result;
}
return result;left.beforeFirst();
right.beforeFirst();
isBeforeFirst = true;
fullRightRowCounter = 0;
fullRowCount        = 0;
fullReturnCounter   = -1;return type == Join.CROSS_JOIN || condition.getBoolean();switch(compare){
case ExpressionArithmetic.EQUALS:
return nextEquals();
default:
throw new Error("Compare operation not supported:" + compare);
}index = new Index(false);
right.beforeFirst();
while(right.next()){
index.addValues(right.getRowPosition(), rightEx);
}if(rowList != null){
long rowPosition = rowList.getNext(longListEnum);
if(rowPosition != -1){
right.setRowPosition(rowPosition);
return true;
}
rowList = null;
}
Object rows;
do{
if(!left.next()){
return false;
}
rows = index.findRows(leftEx, false, null);
}while(rows == null);
if(rows instanceof Long){
right.setRowPosition(((Long)rows).longValue());
}else{
rowList = (LongTreeList)rows;
longListEnum.reset();
right.setRowPosition(rowList.getNext(longListEnum));
}
return true;return new File( Utils.createLobFileName( database, name ) );PrintWriter log = DriverManager.getLogWriter();
if(log != null){
synchronized(log){
log.print("[Small SQL]");
log.println(msg);
log.flush();
}
}return DriverManager.getLogWriter() != null;size = 0;if(size >= data.length ){
resize(size << 1);
}
data[ size++ ] = value;if (idx >= size)
throw new IndexOutOfBoundsException("Index: "+idx+", Size: "+size);
return data[idx];long[] dataNew = new long[newSize];
System.arraycopy(data, 0, dataNew, 0, size);
data = dataNew;return size;int size2 = size << 1;
if(size2 >= data.length ){
resize(size2);
}
data[ size2   ] = value1;
data[ size2 +1] = value2;
size++;if (idx >= size)
throw new IndexOutOfBoundsException("Index: "+idx+", Size: "+size);
return data[(idx << 1) +1];return size;long[] dataNew = new long[newSize << 1];
System.arraycopy(data, 0, dataNew, 0, size << 1);
data = dataNew;if (idx >= size)
throw new IndexOutOfBoundsException("Index: "+idx+", Size: "+size);
return data[idx << 1];size = 0;return ((data[ offset++ ] & 0xFF) << 8) | (data[ offset++ ] & 0xFF);int newsize = data.length << 1;
if(newsize > 0xFFFFFF){
newsize = 0xFFFFFF;
if(newsize == data.length) throw SmallSQLException.create(Language.INDEX_TOOMANY_EQUALS);
}
byte[] temp = new byte[newsize];
System.arraycopy(data, 0, temp, 0, data.length);
data = temp;return size;output.writeInt(size);
output.writeBytes(data, 0, size);int oldOffset = offset;
if(data.length < size + 2) resize();
System.arraycopy(data, offset, data, offset + 2, size-offset);
size += 2;
writeShort( octet );
correctPointers( 0, oldOffset, 2, 0 );int oldOffset = offset;
correctPointers( 0, oldOffset, -(2+pointerSize), 0 );
size -= 2+pointerSize;
System.arraycopy(data, oldOffset + 2+pointerSize, data, oldOffset, size-oldOffset);
offset = oldOffset;int oldOffset = offset;
if(data.length < size + 4 + pointerSize) resize();
System.arraycopy(data, oldOffset, data, oldOffset + 2+pointerSize, size-oldOffset);
size += 2+pointerSize;
writeShort( octet );
writePointer( size );
correctPointers( 0, oldOffset, 2+pointerSize, 0 );
data[size++] = (byte)0;
data[size++] = (byte)0;
return size-2;if(size == 0) return;
int offset1 = 0;
int offset2 = 0;
int offset3 = 0;
offset = 0;
int shift = 48;
boolean firstNode = true;
boolean firstNode1 = true;
boolean firstNode2 = true;
boolean firstNode3 = true;
while(shift>=0){
int octet = (int)(value >> shift) & 0xFFFF;
while(true){
int nextEntry = getUnsignedShort();
if(nextEntry == octet){
if(shift == 0){
offset -= 2;
removeNodeLastLevel();
while(firstNode && getUnsignedShort() == 0){
offset -= 2;
removeNodeLastLevel();
if(shift >= 3)
break;
offset = offset1;
offset1 = offset2;
offset2 = offset3;
firstNode = firstNode1;
firstNode1 = firstNode2;
firstNode2 = firstNode3;
removeNode();
shift++;
}
return;
}
offset3 = offset2;
offset2 = offset1;
offset1 = offset -2;
offset = getPointer();
firstNode3 = firstNode2;
firstNode2 = firstNode1;
firstNode1 = firstNode;
firstNode = true;
break;
}
if((nextEntry == 0 && !firstNode) || nextEntry > octet){
return;
}
firstNode = false;
if(shift != 0) offset += pointerSize;
}
shift -= 16;
}int shift = (3-listEnum.stack) << 4;
if(shift >= 64){
shift = 48;
offset = 0;
listEnum.stack = 0;
listEnum.offsetStack[0] = 2 + pointerSize;
loopToEndOfNode(listEnum);
}else{
setPreviousOffset(listEnum);
}
long result = listEnum.resultStack[listEnum.stack];
while(true){
int nextEntry = (offset < 0) ? -1 : getUnsignedShort();
if(nextEntry >= 0){
result |= (((long)nextEntry) << shift);
if(listEnum.stack>=3){
listEnum.offsetStack[listEnum.stack] = offset;
return result;
}
listEnum.offsetStack[listEnum.stack] = offset+pointerSize;
offset = getPointer();
shift -= 16;
listEnum.stack++;
listEnum.resultStack[listEnum.stack] = result;
loopToEndOfNode(listEnum);
}else{
shift += 16;
listEnum.stack--;
if(listEnum.stack<0) return -1;
result = listEnum.resultStack[listEnum.stack];
setPreviousOffset(listEnum);
}
}offset = startOffset;
boolean firstNode = true;
while(offset < size){
if(offset == oldOffset){
int absDiff = Math.abs(diff);
if(absDiff == 2) return;
offset += absDiff;
firstNode = false;
continue;
}
int value = getUnsignedShort();
if(value != 0 || firstNode){
int pointer = getPointer();
if(pointer > oldOffset){
offset  -= pointerSize;
writePointer( pointer + diff );
if(diff > 0) pointer += diff;
}
if(level < 2){
startOffset = offset;
correctPointers( pointer, oldOffset, diff, level+1);
offset = startOffset;
}
firstNode = false;
}else{
return;
}
}int shift = (3-listEnum.stack) << 4;
if(shift >= 64) return -1;
offset 		= listEnum.offsetStack[listEnum.stack];
long result = listEnum.resultStack[listEnum.stack];
boolean firstNode = (offset == 0);
while(true){
int nextEntry = getUnsignedShort();
if(nextEntry != 0 || firstNode){
result |= (((long)nextEntry) << shift);
if(listEnum.stack>=3){
listEnum.offsetStack[listEnum.stack] = offset;
return result;
}
listEnum.offsetStack[listEnum.stack] = offset+pointerSize;
offset = getPointer();
shift -= 16;
listEnum.stack++;
listEnum.resultStack[listEnum.stack] = result;
firstNode = true;
}else{
shift += 16;
listEnum.stack--;
if(listEnum.stack<0) return -1;
result = listEnum.resultStack[listEnum.stack];
offset = listEnum.offsetStack[listEnum.stack];
firstNode = false;
}
}offset = 0;
if(size == 0){
writeShort( (int)(value >> 48) );
writePointer ( offset+pointerSize+2 );
writeShort( 0 );
writeShort( (int)(value >> 32) );
writePointer ( offset+pointerSize+2 );
writeShort( 0 );
writeShort( (int)(value >> 16) );
writePointer ( offset+pointerSize+2 );
writeShort( 0 );
writeShort( (int)(value) );
writeShort( 0 );
size = offset;
return;
}
int shift = 48;
boolean firstNode = (size > 2);
while(shift>=0){
int octet = (int)(value >> shift) & 0xFFFF;
while(true){
int nextEntry = getUnsignedShort();
if(nextEntry == octet){
if(shift == 0) return;
offset = getPointer();
firstNode = true;
break;
}
if((nextEntry == 0 && !firstNode) || nextEntry > octet){
offset -= 2;
while(true){
if(shift != 0){
offset = insertNode(octet);
}else{
insertNodeLastLevel(octet);
return;
}
shift -= 16;
octet = (int)(value >> shift) & 0xFFFF;
}
}
firstNode = false;
if(shift != 0) offset += pointerSize;
}
shift -= 16;
}int oldOffset = offset;
correctPointers( 0, oldOffset, -2, 0 );
size -= 2;
System.arraycopy(data, oldOffset + 2, data, oldOffset, size-oldOffset);
offset = oldOffset;int nextEntry;
int nextOffset1, nextOffset2;
nextOffset1 = offset;
offset += 2;
if(listEnum.stack<3)
offset += pointerSize;
do{
nextOffset2 = nextOffset1;
nextOffset1 = offset;
nextEntry = getUnsignedShort();
if(listEnum.stack<3)
offset += pointerSize;
}while(nextEntry != 0);
offset = nextOffset2;int value = 0;
for(int i=0; i<pointerSize; i++){
value <<= 8;
value += (data[offset++] & 0xFF);
}
return value;data[offset++] = (byte)(value >> 8);
data[offset++] = (byte)(value);int previousOffset = listEnum.offsetStack[listEnum.stack] - 2*(2 + (listEnum.stack>=3 ? 0 : pointerSize));
if(listEnum.stack == 0){
offset = previousOffset;
return;
}
offset = listEnum.offsetStack[listEnum.stack-1] - pointerSize;
int pointer = getPointer();
if(pointer <= previousOffset){
offset = previousOffset;
return;
}
offset = -1;for(int i=pointerSize-1; i>=0; i--){
data[offset++] = (byte)(value >> (i*8));
}stack = 0;
offsetStack[0] = 0;return true;return rowIdx >= rowList.size() || rowList.size() == 0;rowIdx = 0;
return move();currentRow = null;rowList.clear();return get( colIdx ).getInt();return get( colIdx ).getMoney();rowIdx++;
return move();return get( colIdx ).getObject();return get( colIdx ).getBoolean();rowList.add(row);throw new Error();if(rowIdx-- < 0) rowIdx = -1;
return move();return columns.get(colIdx);if(currentRow == null) throw SmallSQLException.create(Language.ROW_NOCURRENT);
return currentRow[ colIdx ];rowIdx = rowList.size() - 1;
return move();rowIdx = (int)rowPosition;
move();return rowIdx < 0 || rowList.size() == 0;if(row == 0) throw SmallSQLException.create(Language.ROW_0_ABSOLUTE);
rowIdx = (row > 0) ?
Math.min( row - 1, rowList.size() ):
Math.max( row +rowList.size(), -1 );
return move();columns.add(column);return get( colIdx ).getString();if(rowIdx < rowList.size() && rowIdx >= 0){
currentRow = (ExpressionValue[])rowList.get(rowIdx);
return true;
}
currentRow = null;
return false;return rowIdx == 0 && currentRow != null;rowIdx = -1;
currentRow = null;return false;return false;return get( colIdx ).getNumeric();return rowIdx;throw SmallSQLException.create(Language.RSET_READONLY);return rowIdx == rowList.size() - 1 && currentRow != null;throw SmallSQLException.create(Language.RSET_READONLY);throw SmallSQLException.create(Language.RSET_READONLY);rowIdx = rowList.size();
currentRow = null;return columns.get( colIdx ).getDataType();return get( colIdx ).getDouble();return null;return get( colIdx ).getFloat();return get( colIdx ).getLong();return get( colIdx ).getBytes();if(rows == 0) return (currentRow != null);
rowIdx = Math.min( Math.max( rowIdx + rows, -1), rowList.size());
return move();return get( colIdx ).isNull();return rowList.size();return currentRow == null ? 0 : rowIdx+1;verifyFreePufferSize(2*value.length);
for(int i=0; i<value.length; i++){
char c = value[i];
puffer[ offset++ ] = (byte)(c >> 8);
puffer[ offset++ ] = (byte)(c);
}ByteBuffer buffer = ByteBuffer.wrap( puffer, 0, offset );
file.write(buffer);verifyFreePufferSize(1);
puffer[ offset++ ] = (byte)(value);return ((puffer[ offset++ ] & 0xFF) << 8) | (puffer[ offset++ ] & 0xFF);int minSize = offset+freeSize;
if(minSize < puffer.length){
int newSize = puffer.length << 1;
if(newSize < minSize) newSize = minSize;
byte[] temp = new byte[newSize];
System.arraycopy(puffer, 0, temp, 0, offset);
puffer = temp;
}verifyFreePufferSize(length);
System.arraycopy(value, off, puffer, offset, length);
offset += length;return puffer[ offset++ ];verifyFreePufferSize(8);
puffer[ offset++ ] = (byte)(value >> 56);
puffer[ offset++ ] = (byte)(value >> 48);
puffer[ offset++ ] = (byte)(value >> 40);
puffer[ offset++ ] = (byte)(value >> 32);
puffer[ offset++ ] = (byte)(value >> 24);
puffer[ offset++ ] = (byte)(value >> 16);
puffer[ offset++ ] = (byte)(value >> 8);
puffer[ offset++ ] = (byte)(value);verifyFreePufferSize(4);
puffer[ offset++ ] = (byte)(value >> 24);
puffer[ offset++ ] = (byte)(value >> 16);
puffer[ offset++ ] = (byte)(value >> 8);
puffer[ offset++ ] = (byte)(value);char[] chars = new char[length];
for(int i=0; i<length; i++){
chars[i] = (char)readShort();
}
return chars;verifyFreePufferSize(2);
puffer[ offset++ ] = (byte)(value >> 8);
puffer[ offset++ ] = (byte)(value);offset += count;byte[] bytes = new byte[length];
System.arraycopy(puffer, offset, bytes, 0, length);
offset += length;
return bytes;return ((puffer[ offset++ ] & 0xFF) << 24)
| ((puffer[ offset++ ] & 0xFF) << 16)
| ((puffer[ offset++ ] & 0xFF) << 8)
|  (puffer[ offset++ ] & 0xFF);return (((long)(puffer[ offset++ ] & 0xFF)) << 56)
| (((long)(puffer[ offset++ ] & 0xFF)) << 48)
| (((long)(puffer[ offset++ ] & 0xFF)) << 40)
| (((long)(puffer[ offset++ ] & 0xFF)) << 32)
| ((puffer[ offset++ ] & 0xFF) << 24)
| ((puffer[ offset++ ] & 0xFF) << 16)
| ((puffer[ offset++ ] & 0xFF) << 8)
|  (puffer[ offset++ ] & 0xFF);return (int)(value ^ (value >>> 32));return toBigDecimal();byte[] bytes = new byte[8];
int offset = 0;
bytes[offset++] = (byte)(value >> 56);
bytes[offset++] = (byte)(value >> 48);
bytes[offset++] = (byte)(value >> 40);
bytes[offset++] = (byte)(value >> 32);
bytes[offset++] = (byte)(value >> 24);
bytes[offset++] = (byte)(value >> 16);
bytes[offset++] = (byte)(value >> 8);
bytes[offset++] = (byte)(value);
return bytes;return (long)(value / 10000.0);return Utils.doubleToMoney(Double.parseDouble( str ));return value;return (int)(value / 10000.0);return value / 10000.0F;return value / 10000.0;StringBuffer buffer = new StringBuffer();
buffer.append(longValue()).append('.');
final long v = Math.abs(value);
buffer.append( (char)((v % 10000) / 1000 + '0') );
buffer.append( (char)((v % 1000) / 100 + '0') );
buffer.append( (char)((v % 100) / 10 + '0') );
buffer.append( (char)((v % 10) + '0') );
return buffer.toString();Money money = new Money();
money.value = value;
return money;Money money = new Money();
money.value = value;
return money;if(value == 0) return ZERO;
return new BigDecimal( new BigInteger( toByteArray() ), 4 );return (obj instanceof Money && ((Money)obj).value == value);return value;return new Double(value);return (long)value;return String.valueOf(value);return (float)value;return (int)value;return new Float(value);return (long)value;return String.valueOf(value);return (int)value;return value;return value;return Utils.getInteger(value);return String.valueOf(value);return value;return value;return value;return value;return new Long(value);return String.valueOf(value);return (int)value;return value;return value;return value;int val[] = new int[value.length+1];
val[0] = highBits;
System.arraycopy(value, 0, val, 1, value.length);
value = val;return toBigDecimal();int newScale = Math.max(scale+5, num.scale +4);
BigDecimal big = toBigDecimal().divide(num.toBigDecimal(), newScale, BigDecimal.ROUND_HALF_EVEN);
setValue( big.unscaledValue().toByteArray() );
scale = big.scale();
signum = big.signum();if(!(obj instanceof MutableNumeric)) return false;
return compareTo((MutableNumeric)obj) == 0;int oldScale = scale;
setScale(0);
setScale(oldScale);StringBuffer buf = new StringBuffer();
if(value.length == 0 || signum == 0){
buf.append( '0' );
}else{
if (value.length == 1 && (value[0] > 0)){
buf.append( Integer.toString(value[0]) );
}else
if (value.length == 1){
long temp = value[0] & 0xFFFFFFFFL;
buf.append( Long.toString( temp ) );
}else
if (value.length == 2 && (value[0] > 0)){
long temp = (((long)value[0]) << 32) | (value[1] & 0xFFFFFFFFL);
buf.append( Long.toString( temp ) );
}else{
return new BigDecimal( new BigInteger( toByteArray() ), scale ).toString();
}
}
if(scale > 0){
while(buf.length() <= scale) buf.insert( 0, '0' );
buf.insert( buf.length() - scale, '.' );
}
if (signum < 0) buf.insert( 0, '-');
return buf.toString();if(newScale == scale) return;
int factor = 1;
if(newScale > scale){
for(;newScale>scale; scale++){
factor *=10;
if(factor == 1000000000){
mul(factor);
factor = 1;
}
}
mul(factor);
}else{
for(;newScale<scale; scale--){
factor *=10;
if(factor == 1000000000){
divImpl(factor);
factor = 1;
}
}
divImpl(factor);
}num = new MutableNumeric( doubleValue() % num.doubleValue() );
value = num.value;
scale = num.scale;
signum = num.signum;mul(100000);
scale += 5;
divImpl(quotient);this.signum = signum;int last = complement.length-1;
for(int i=0; i<=last; i++){
complement[i] = (byte)( (i == last) ? -complement[i] : ~complement[i]);
}
while(complement[last] == 0){
last--;
complement[last]++;
}if(quotient == 1) return;
if(quotient < 0){
quotient = - quotient;
signum = -signum;
}
int valueLength = value.length;
long carryover = 0;
for(int i = 0; i<valueLength; i++){
long v = (value[i] & 0xFFFFFFFFL) + carryover;
value[i] = (int)(v / quotient);
carryover = ((v % quotient) << 32);
}
carryover /= quotient;
if(carryover > 2147483648L ||
(carryover == 2147483648L && (value[valueLength-1] % 2 == 1))){
int i = valueLength-1;
boolean isCarryOver = true;
while(i >= 0 && isCarryOver)
isCarryOver = (value[i--] += 1) == 0;
}
if(valueLength>1 && value[0] == 0){
int[] temp = new int[valueLength-1];
System.arraycopy(value, 1, temp, 0, valueLength-1);
value = temp;
}if(num.scale < scale){
num.setScale(scale);
}else
if(num.scale > scale){
setScale(num.scale);
}
add( -num.signum, num.value );long temp = 0;
int v1 = value.length;
for(int v2 = val2.length; v2>0; ){
temp = (value[--v1] & 0xFFFFFFFFL) - (val2 [--v2] & 0xFFFFFFFFL) + (temp >>>= 32);
value[v1] = (int)temp;
}
boolean uebertrag = (temp >>> 32) != 0;
while(v1 > 0 && uebertrag)
uebertrag = (value[--v1] = value[v1] - 1) == -1;
if(uebertrag){
signum = -signum;
int last = value.length-1;
for(int i=0; i<=last; i++){
value[i] = (i == last) ? -value[i] : ~value[i];
}
}int length = complement.length;
if(length == 0){
value   = EMPTY_INTS;
signum  = 0;
return;
}
value = new int[ (length + 3) / 4 ];
if(complement[0] < 0){
negate( complement );
signum = -1;
}else{
signum = 0;
for(int i=0; i<complement.length; i++)
if(complement[i] != 0){
signum = 1;
break;
}
}
for(int v=value.length-1; v>=0; v--){
int temp = 0;
for(int i=0; i<4 && 0<length; i++){
temp |= (complement[ --length ] & 0xFF) << (i*8);
}
value[v] = temp;
}if(factor < 0){
factor = - factor;
signum = -signum;
}
long carryover = 0;
for(int i = value.length-1; i>=0; i--){
long v = (value[i] & 0xFFFFFFFFL) * factor + carryover;
value[i] = (int)v;
carryover = v >> 32;
}
if(carryover > 0){
resizeValue( (int)carryover );
}if(signum == 0) return new BigDecimal( BigInteger.ZERO, scale);
return new BigDecimal( new BigInteger( toByteArray() ), scale );return Utils.long2int(longValue());return toBigDecimal().compareTo(numeric.toBigDecimal());if(newScale == this.scale) return toBigDecimal();
return toBigDecimal().setScale( newScale, BigDecimal.ROUND_HALF_EVEN);return signum;if(signum == 0) return EMPTY_BYTES;
byte[] complement;
int offset;
int v = 0;
while(v < value.length && value[v] == 0) v++;
if (v == value.length) return EMPTY_BYTES;
if(value[v] < 0){
complement = new byte[(value.length-v)*4 + 4];
if(signum < 0)
complement[0] = complement[1] = complement[2] = complement[3] = -1;
offset = 4;
}else{
complement = new byte[(value.length-v)*4];
offset = 0;
}
int last = value.length-1;
for(; v <= last; v++){
int val = (signum>0) ? value[v] : (v == last) ? -value[v] : ~value[v];
complement[offset++] = (byte)(val >> 24);
complement[offset++] = (byte)(val >> 16);
complement[offset++] = (byte)(val >> 8);
complement[offset++] = (byte)(val);
}
return complement;long temp = 0;
int v1 = value.length;
for(int v2 = val2.length; v2>0; ){
temp = (value[--v1] & 0xFFFFFFFFL) + (val2 [--v2] & 0xFFFFFFFFL) + (temp >>> 32);
value[v1] = (int)temp;
}
boolean uebertrag = (temp >>> 32) != 0;
while(v1 > 0 && uebertrag)
uebertrag = (value[--v1] = value[v1] + 1) == 0;
if(uebertrag){
resizeValue(1);
}BigDecimal big = toBigDecimal().multiply(num.toBigDecimal() );
setValue( big.unscaledValue().toByteArray() );
scale = big.scale();
signum = big.signum();return scale;if(val2.length > value.length){
int[] temp = val2;
val2 = value;
value = temp;
int tempi = signum;
signum = sig2;
sig2 = tempi;
}
if(signum != sig2)
sub(val2);
else
add(val2);if(value.length == 0 || signum == 0){
return 0;
}else{
if (value.length == 1 && (value[0] > 0)){
return value[0] / scaleFloatFactor[scale] * signum;
}else
if (value.length == 1){
long temp = value[0] & 0xFFFFFFFFL;
return temp / scaleFloatFactor[scale] * signum;
}else
if (value.length == 2 && (value[0] > 0)){
long temp = (((long)value[0]) << 32) | (value[1] & 0xFFFFFFFFL);
return temp / scaleFloatFactor[scale] * signum;
}else{
return new BigDecimal( new BigInteger( toByteArray() ), scale ).floatValue();
}
}if(value.length == 0 || signum == 0){
return 0;
}else{
if (value.length == 1 && (value[0] > 0)){
return value[0] / scaleDoubleFactor[scale] * signum;
}else
if (value.length == 1){
long temp = value[0] & 0xFFFFFFFFL;
return temp / scaleDoubleFactor[scale] * signum;
}else
if (value.length == 2 && (value[0] > 0)){
long temp = (((long)value[0]) << 32) | (value[1] & 0xFFFFFFFFL);
return temp / scaleDoubleFactor[scale] * signum;
}else{
return new BigDecimal( new BigInteger( toByteArray() ), scale ).doubleValue();
}
}return value;if(value.length == 0 || signum == 0){
return 0;
}else{
if (value.length == 1 && (value[0] > 0)){
return Utils.double2long(value[0] / scaleDoubleFactor[scale] * signum);
}else
if (value.length == 1){
long temp = value[0] & 0xFFFFFFFFL;
return Utils.double2long(temp / scaleDoubleFactor[scale] * signum);
}else
if (value.length == 2 && (value[0] > 0)){
long temp = (((long)value[0]) << 32) | (value[1] & 0xFFFFFFFFL);
return Utils.double2long(temp / scaleDoubleFactor[scale] * signum);
}else{
if(scale != 0){
MutableNumeric numeric = new MutableNumeric(this);
numeric.setScale(0);
return numeric.longValue();
}
return (signum > 0) ? Long.MAX_VALUE : Long.MIN_VALUE;
}
}if(num.scale < scale){
num.setScale(scale);
}else
if(num.scale > scale){
setScale(num.scale);
}
add( num.signum, num.value );return rowPos > 1;if(rows == 0) return rowPos == 1;
rowPos = Math.min( Math.max( rowPos + rows, -1), 1);
return rowPos == 1;rowPos = (row > 0) ?
Math.min( row, 1 ) :
Math.min( row +1, -1 );
return rowPos == 1;return rowPos;return rowPos == 1 ? 1 : 0;rowPos = 0;rowPos++;
return rowPos == 1;rowPos = 2;return columns.size() == 0;return true;return false;return false;rowPos--;
return rowPos == 1;rowPos = 1;
return true;rowPos = 1;
return true;return rowPos == 1;return rowPos == 1;throw new Error();throw new Error();rowPos = (int)rowPosition;return rowPos <= 0;return true;throw SmallSQLException.create(Language.RSET_FWDONLY);throw SmallSQLException.create(Language.RSET_FWDONLY);throw SmallSQLException.create(Language.ALIAS_UNSUPPORTED);throw SmallSQLException.create(Language.RSET_FWDONLY);throw SmallSQLException.create(Language.RSET_FWDONLY);throw SmallSQLException.create(Language.RSET_FWDONLY);throw SmallSQLException.create(Language.RSET_FWDONLY);throw SmallSQLException.create(Language.RSET_FWDONLY);throw SmallSQLException.create(Language.RSET_FWDONLY);String message = getErrorString(token, addMessageCode, param0);
return SmallSQLException.create(Language.CUSTOM_MESSAGE, message);if(constraintType != SQLTokenizer.UNIQUE) nextToken( MISSING_KEY );
SQLToken token = nextToken();
if(token != null){
switch(token.value){
case SQLTokenizer.CLUSTERED:
case SQLTokenizer.NONCLUSTERED:
break;
default:
previousToken();
}
}else{
previousToken();
}
Strings columns = new Strings();
Expressions expressions = new Expressions();
if(columnName != null){
columns.add(columnName);
expressions.add(new ExpressionName(columnName));
}else{
expressionDefList( cmd, expressions, columns );
}
return new IndexDescription( contrainName, tableName, constraintType, expressions, columns);SQLToken token = nextToken();
if(token.value != SQLTokenizer.PARENTHESIS_L) throw createSyntaxError(token, MISSING_PARENTHESIS_L );
Loop:
while(true){
int offset = token.offset + token.length;
token = nextToken();
if(token != null) offset = token.offset;
previousToken();
expressions.add( expression(cmd, 0) );
SQLToken last = lastToken();
int length = last.offset + last.length - offset;
columns.add( new String( sql, offset, length ) );
token = nextToken(MISSING_COMMA_PARENTHESIS);
switch(token.value){
case SQLTokenizer.PARENTHESIS_R:
break Loop;
case SQLTokenizer.COMMA:
continue;
default:
throw new Error();
}
}SQLToken token = nextToken();
if(token != null && token.value == SQLTokenizer.POINT){
return nextIdentifier();
}else{
previousToken();
}
return name;SQLToken token = nextToken( MISSING_ISOLATION );
token = nextToken( MISSING_LEVEL );
token = nextToken( COMMANDS_TRANS_LEVEL );
CommandSet cmd = new CommandSet( con.log, SQLTokenizer.LEVEL );
switch(token.value){
case SQLTokenizer.READ:
token = nextToken( MISSING_COMM_UNCOMM );
switch(token.value){
case SQLTokenizer.COMMITTED:
cmd.isolationLevel = Connection.TRANSACTION_READ_COMMITTED;
break;
case SQLTokenizer.UNCOMMITTED:
cmd.isolationLevel = Connection.TRANSACTION_READ_UNCOMMITTED;
break;
default:
throw new Error();
}
return cmd;
case SQLTokenizer.REPEATABLE:
token = nextToken( MISSING_READ );
cmd.isolationLevel = Connection.TRANSACTION_REPEATABLE_READ;
return cmd;
case SQLTokenizer.SERIALIZABLE:
cmd.isolationLevel = Connection.TRANSACTION_SERIALIZABLE;
return cmd;
default:
throw new Error();
}RowSource fromSource = null;
fromSource = tableSource(cmd, tables);
while(true){
SQLToken token = nextToken();
if(token == null) return fromSource;
switch(token.value){
case SQLTokenizer.ON:
previousToken();
return fromSource;
case SQLTokenizer.CROSS:
nextToken(MISSING_JOIN);
case SQLTokenizer.COMMA:
fromSource = new Join( Join.CROSS_JOIN, fromSource, rowSource(cmd, tables, 0), null);
break;
case SQLTokenizer.INNER:
nextToken(MISSING_JOIN);
case SQLTokenizer.JOIN:
fromSource = join( cmd, tables, fromSource, Join.INNER_JOIN );
break;
case SQLTokenizer.LEFT:
token = nextToken(MISSING_OUTER_JOIN);
if(token.value == SQLTokenizer.OUTER)
token = nextToken(MISSING_JOIN);
fromSource = join( cmd, tables, fromSource, Join.LEFT_JOIN );
break;
case SQLTokenizer.RIGHT:
token = nextToken(MISSING_OUTER_JOIN);
if(token.value == SQLTokenizer.OUTER)
token = nextToken(MISSING_JOIN);
fromSource = join( cmd, tables, fromSource, Join.RIGHT_JOIN );
break;
case SQLTokenizer.FULL:
token = nextToken(MISSING_OUTER_JOIN);
if(token.value == SQLTokenizer.OUTER)
token = nextToken(MISSING_JOIN);
fromSource = join( cmd, tables, fromSource, Join.FULL_JOIN );
break;
case SQLTokenizer.PARENTHESIS_R:
case SQLTokenizer.ESCAPE_R:
if(parenthesis == token.value) return fromSource;
if(parenthesis == 0){
previousToken();
return fromSource;
}
throw createSyntaxError( token, Language.STXADD_FROM_PAR_CLOSE );
default:
if(isKeyword(token)){
previousToken();
return fromSource;
}
if(!fromSource.hasAlias()){
fromSource.setAlias( token.getName( sql ) );
break;
}
throw createSyntaxError( token, new int[]{SQLTokenizer.COMMA, SQLTokenizer.GROUP, SQLTokenizer.ORDER, SQLTokenizer.HAVING} );
}
}SQLToken tokenType = nextToken(MISSING_ADD_ALTER_DROP);
CommandTable cmd = new CommandTable( con.log, catalog, name, tokenType.value );
switch(tokenType.value){
case SQLTokenizer.ADD:
SQLToken token;
do{
token = nextToken( MISSING_IDENTIFIER );
token = addColumn( token, cmd );
}while(token != null && token.value == SQLTokenizer.COMMA );
return cmd;
default:
Object[] param = { "ALTER TABLE " + tokenType.getName( sql ) };
throw SmallSQLException.create(Language.UNSUPPORTED_OPERATION, param);
}cmd.setHaving( expression(cmd, 0) );this.sql = expr.toCharArray();
this.tokens = SQLTokenizer.parseSQL( sql );
tokenIdx = 0;
return expression( null, 0);Expression expr;
switch(token.value){
case SQLTokenizer.CONVERT:{
Column col;
Expression style = null;
if(isEscape){
expr = expression( cmd, 0);
nextToken(MISSING_COMMA);
col = datatype(isEscape);
}else{
col = datatype(isEscape);
nextToken(MISSING_COMMA);
expr = expression( cmd, 0);
token = nextToken(MISSING_COMMA_PARENTHESIS);
if(token.value == SQLTokenizer.COMMA){
style = expression( cmd, 0);
}else
previousToken();
}
nextToken(MISSING_PARENTHESIS_R);
return new ExpressionFunctionConvert( col, expr, style );
}
case SQLTokenizer.CAST:
expr = expression( cmd, 0);
nextToken(MISSING_AS);
Column col = datatype(false);
nextToken(MISSING_PARENTHESIS_R);
return new ExpressionFunctionConvert( col, expr, null );
case SQLTokenizer.TIMESTAMPDIFF:
token = nextToken(MISSING_INTERVALS);
nextToken(MISSING_COMMA);
expr = expression( cmd, 0);
nextToken(MISSING_COMMA);
expr = new ExpressionFunctionTimestampDiff( token.value, expr, expression( cmd, 0));
nextToken(MISSING_PARENTHESIS_R);
return expr;
case SQLTokenizer.TIMESTAMPADD:
token = nextToken(MISSING_INTERVALS);
nextToken(MISSING_COMMA);
expr = expression( cmd, 0);
nextToken(MISSING_COMMA);
expr = new ExpressionFunctionTimestampAdd( token.value, expr, expression( cmd, 0));
nextToken(MISSING_PARENTHESIS_R);
return expr;
}
Expressions paramList = expressionParenthesisList(cmd);
int paramCount = paramList.size();
Expression[] params = paramList.toArray();
boolean invalidParamCount;
switch(token.value){
case SQLTokenizer.ABS:
invalidParamCount = (paramCount != 1);
expr = new ExpressionFunctionAbs();
break;
case SQLTokenizer.ACOS:
invalidParamCount = (paramCount != 1);
expr = new ExpressionFunctionACos();
break;
case SQLTokenizer.ASIN:
invalidParamCount = (paramCount != 1);
expr = new ExpressionFunctionASin();
break;
case SQLTokenizer.ATAN:
invalidParamCount = (paramCount != 1);
expr = new ExpressionFunctionATan();
break;
case SQLTokenizer.ATAN2:
invalidParamCount = (paramCount != 2);
expr = new ExpressionFunctionATan2();
break;
case SQLTokenizer.CEILING:
invalidParamCount = (paramCount != 1);
expr = new ExpressionFunctionCeiling();
break;
case SQLTokenizer.COS:
invalidParamCount = (paramCount != 1);
expr = new ExpressionFunctionCos();
break;
case SQLTokenizer.COT:
invalidParamCount = (paramCount != 1);
expr = new ExpressionFunctionCot();
break;
case SQLTokenizer.DEGREES:
invalidParamCount = (paramCount != 1);
expr = new ExpressionFunctionDegrees();
break;
case SQLTokenizer.EXP:
invalidParamCount = (paramCount != 1);
expr = new ExpressionFunctionExp();
break;
case SQLTokenizer.FLOOR:
invalidParamCount = (paramCount != 1);
expr = new ExpressionFunctionFloor();
break;
case SQLTokenizer.LOG:
invalidParamCount = (paramCount != 1);
expr = new ExpressionFunctionLog();
break;
case SQLTokenizer.LOG10:
invalidParamCount = (paramCount != 1);
expr = new ExpressionFunctionLog10();
break;
case SQLTokenizer.MOD:
invalidParamCount = (paramCount != 2);
expr = new ExpressionFunctionMod();
break;
case SQLTokenizer.PI:
invalidParamCount = (paramCount != 0);
expr = new ExpressionFunctionPI();
break;
case SQLTokenizer.POWER:
invalidParamCount = (paramCount != 2);
expr = new ExpressionFunctionPower();
break;
case SQLTokenizer.RADIANS:
invalidParamCount = (paramCount != 1);
expr = new ExpressionFunctionRadians();
break;
case SQLTokenizer.RAND:
invalidParamCount =  (paramCount != 0) && (paramCount != 1);
expr = new ExpressionFunctionRand();
break;
case SQLTokenizer.ROUND:
invalidParamCount =  (paramCount != 2);
expr = new ExpressionFunctionRound();
break;
case SQLTokenizer.SIN:
invalidParamCount = (paramCount != 1);
expr = new ExpressionFunctionSin();
break;
case SQLTokenizer.SIGN:
invalidParamCount = (paramCount != 1);
expr = new ExpressionFunctionSign();
break;
case SQLTokenizer.SQRT:
invalidParamCount = (paramCount != 1);
expr = new ExpressionFunctionSqrt();
break;
case SQLTokenizer.TAN:
invalidParamCount = (paramCount != 1);
expr = new ExpressionFunctionTan();
break;
case SQLTokenizer.TRUNCATE:
invalidParamCount =  (paramCount != 2);
expr = new ExpressionFunctionTruncate();
break;
case SQLTokenizer.ASCII:
invalidParamCount = (paramCount != 1);
expr = new ExpressionFunctionAscii();
break;
case SQLTokenizer.BITLEN:
invalidParamCount = (paramCount != 1);
expr = new ExpressionFunctionBitLen();
break;
case SQLTokenizer.CHARLEN:
case SQLTokenizer.CHARACTLEN:
invalidParamCount = (paramCount != 1);
expr = new ExpressionFunctionCharLen();
break;
case SQLTokenizer.CHAR:
invalidParamCount = (paramCount != 1);
expr = new ExpressionFunctionChar();
break;
case SQLTokenizer.CONCAT:
if(paramCount != 2){
invalidParamCount = true;
expr = null;
break;
}
invalidParamCount = false;
expr = new ExpressionArithmetic( params[0], params[1], ExpressionArithmetic.ADD);
break;
case SQLTokenizer.DIFFERENCE:
invalidParamCount = (paramCount != 2);
expr = new ExpressionFunctionDifference();
break;
case SQLTokenizer.INSERT:
invalidParamCount = (paramCount != 4);
expr = new ExpressionFunctionInsert();
break;
case SQLTokenizer.LCASE:
invalidParamCount = (paramCount != 1);
expr = new ExpressionFunctionLCase();
break;
case SQLTokenizer.LEFT:
invalidParamCount = (paramCount != 2);
expr = new ExpressionFunctionLeft();
break;
case SQLTokenizer.LENGTH:
invalidParamCount = (paramCount != 1);
expr = new ExpressionFunctionLength();
break;
case SQLTokenizer.LOCATE:
invalidParamCount = (paramCount != 2) && (paramCount != 3);
expr = new ExpressionFunctionLocate();
break;
case SQLTokenizer.LTRIM:
invalidParamCount = (paramCount != 1);
expr = new ExpressionFunctionLTrim();
break;
case SQLTokenizer.OCTETLEN:
invalidParamCount = (paramCount != 1);
expr = new ExpressionFunctionOctetLen();
break;
case SQLTokenizer.REPEAT:
invalidParamCount = (paramCount != 2);
expr = new ExpressionFunctionRepeat();
break;
case SQLTokenizer.REPLACE:
invalidParamCount = (paramCount != 3);
expr = new ExpressionFunctionReplace();
break;
case SQLTokenizer.RIGHT:
invalidParamCount = (paramCount != 2);
expr = new ExpressionFunctionRight();
break;
case SQLTokenizer.RTRIM:
invalidParamCount = (paramCount != 1);
expr = new ExpressionFunctionRTrim();
break;
case SQLTokenizer.SPACE:
invalidParamCount = (paramCount != 1);
expr = new ExpressionFunctionSpace();
break;
case SQLTokenizer.SOUNDEX:
invalidParamCount = (paramCount != 1);
expr = new ExpressionFunctionSoundex();
break;
case SQLTokenizer.SUBSTRING:
invalidParamCount = (paramCount != 3);
expr = new ExpressionFunctionSubstring();
break;
case SQLTokenizer.UCASE:
invalidParamCount = (paramCount != 1);
expr = new ExpressionFunctionUCase();
break;
case SQLTokenizer.CURDATE:
case SQLTokenizer.CURRENTDATE:
invalidParamCount = (paramCount != 0);
expr = new ExpressionValue( new DateTime(DateTime.now(), SQLTokenizer.DATE), SQLTokenizer.DATE);
break;
case SQLTokenizer.CURTIME:
invalidParamCount = (paramCount != 0);
expr = new ExpressionValue( new DateTime(DateTime.now(), SQLTokenizer.TIME), SQLTokenizer.TIME);
break;
case SQLTokenizer.DAYOFMONTH:
invalidParamCount = (paramCount != 1);
expr = new ExpressionFunctionDayOfMonth();
break;
case SQLTokenizer.DAYOFWEEK:
invalidParamCount = (paramCount != 1);
expr = new ExpressionFunctionDayOfWeek();
break;
case SQLTokenizer.DAYOFYEAR:
invalidParamCount = (paramCount != 1);
expr = new ExpressionFunctionDayOfYear();
break;
case SQLTokenizer.HOUR:
invalidParamCount = (paramCount != 1);
expr = new ExpressionFunctionHour();
break;
case SQLTokenizer.MINUTE:
invalidParamCount = (paramCount != 1);
expr = new ExpressionFunctionMinute();
break;
case SQLTokenizer.MONTH:
invalidParamCount = (paramCount != 1);
expr = new ExpressionFunctionMonth();
break;
case SQLTokenizer.NOW:
invalidParamCount = (paramCount != 0);
expr = new ExpressionValue( new DateTime(DateTime.now(), SQLTokenizer.TIMESTAMP), SQLTokenizer.TIMESTAMP);
break;
case SQLTokenizer.YEAR:
invalidParamCount = (paramCount != 1);
expr = new ExpressionFunctionYear();
break;
case SQLTokenizer.IIF:
invalidParamCount = (paramCount != 3);
expr = new ExpressionFunctionIIF();
break;
case SQLTokenizer.SWITCH:
invalidParamCount = (paramCount % 2 != 0);
ExpressionFunctionCase exprCase = new ExpressionFunctionCase();
for(int i=0; i < paramCount-1; i +=2)
exprCase.addCase(params[i], params[i+1] );
exprCase.setEnd();
expr = exprCase;
break;
case SQLTokenizer.IFNULL:
switch(paramCount){
case 1:
return new ExpressionArithmetic( params[0], ExpressionArithmetic.ISNULL );
case 2:
invalidParamCount = false;
expr = new ExpressionFunctionIIF();
Expression[] newParams = new Expression[3];
newParams[0] = new ExpressionArithmetic( params[0], ExpressionArithmetic.ISNULL );
newParams[1] = params[1];
newParams[2] = params[0];
params = newParams;
paramCount = 3;
break;
default:
invalidParamCount = true;
expr = null;
}
break;
case SQLTokenizer.COUNT:
invalidParamCount = (paramCount != 1);
if(params[0].getType() == Expression.NAME){
ExpressionName param = (ExpressionName)params[0];
if("*".equals(param.getName()) && param.getTableAlias() == null){
params[0] = new ExpressionValue("*", SQLTokenizer.VARCHAR);
}
}
expr = new ExpressionName( Expression.COUNT );
break;
case SQLTokenizer.SUM:
invalidParamCount = (paramCount != 1);
expr = new ExpressionName( Expression.SUM );
break;
case SQLTokenizer.MAX:
invalidParamCount = (paramCount != 1);
expr = new ExpressionName( Expression.MAX );
break;
case SQLTokenizer.MIN:
invalidParamCount = (paramCount != 1);
expr = new ExpressionName( Expression.MIN );
break;
case SQLTokenizer.FIRST:
invalidParamCount = (paramCount != 1);
expr = new ExpressionName( Expression.FIRST );
break;
case SQLTokenizer.LAST:
invalidParamCount = (paramCount != 1);
expr = new ExpressionName( Expression.LAST );
break;
case SQLTokenizer.AVG:
if(paramCount != 1){
invalidParamCount = true;
expr = null;
break;
}
expr = new ExpressionName( Expression.SUM );
expr.setParams( params );
Expression expr2 = new ExpressionName( Expression.COUNT );
expr2.setParams( params );
expr = new ExpressionArithmetic( expr, expr2, ExpressionArithmetic.DIV );
return expr;
default:
throw createSyntaxError(token, Language.STXADD_FUNC_UNKNOWN);
}
if(invalidParamCount) {
throw createSyntaxError(token, Language.STXADD_PARAM_INVALID_COUNT);
}
expr.setParams( params );
return expr;String message = getErrorString(token, addMessageCode, null);
return SmallSQLException.create(Language.CUSTOM_MESSAGE, message);SQLToken token = nextToken( COMMANDS_SET );
switch(token.value){
case SQLTokenizer.TRANSACTION:
return setTransaction();
default:
throw new Error();
}Expressions list = new Expressions();
{
SQLToken token = nextToken();
if(token != null && token.value == SQLTokenizer.PARENTHESIS_R){
return list;
}
previousToken();
}
while(true){
list.add( expression(cmd, 0) );
SQLToken token = nextToken(MISSING_COMMA_PARENTHESIS);
switch(token.value){
case SQLTokenizer.PARENTHESIS_R:
return list;
case SQLTokenizer.COMMA:
continue;
default:
throw new Error();
}
}Expressions list = new Expressions();
while(true){
Expression expr = expression(cmd, 0);
list.add( expr );
SQLToken token = nextToken();
if(listType == SQLTokenizer.ORDER && token != null){
switch(token.value){
case SQLTokenizer.DESC:
expr.setAlias(SQLTokenizer.DESC_STR);
case SQLTokenizer.ASC:
token = nextToken();
}
}
if(token == null) {
previousToken();
return list;
}
switch(token.value){
case SQLTokenizer.COMMA:
continue;
default:
if(isKeyword(token) ){
previousToken();
return list;
}
throw createSyntaxError( token, MISSING_TOKEN_LIST);
}
}CommandSelect selCmd = singleSelect();
SQLToken token = nextToken();
UnionAll union = null;
while(token != null && token.value == SQLTokenizer.UNION){
if(union == null){
union = new UnionAll();
union.addDataSource(new ViewResult( con, selCmd ));
selCmd = new CommandSelect(con.log);
selCmd.setSource( union );
DataSources from = new DataSources();
from.add(union);
selCmd.setTables( from );
selCmd.addColumnExpression( new ExpressionName("*") );
}
nextToken(MISSING_ALL);
nextToken(MISSING_SELECT);
union.addDataSource( new ViewResult( con, singleSelect() ) );
token = nextToken();
}
if(token != null && token.value == SQLTokenizer.ORDER){
order( selCmd );
token = nextToken();
}
if(token != null && token.value == SQLTokenizer.LIMIT){
limit( selCmd );
token = nextToken();
}
previousToken();
return selCmd;SQLToken token;
int dataType;
if(isEscape){
token = nextToken( MISSING_SQL_DATATYPE );
switch(token.value){
case SQLTokenizer.SQL_BIGINT: 			dataType = SQLTokenizer.BIGINT;		break;
case SQLTokenizer.SQL_BINARY:			dataType = SQLTokenizer.BINARY; 	break;
case SQLTokenizer.SQL_BIT:				dataType = SQLTokenizer.BIT;		break;
case SQLTokenizer.SQL_CHAR:				dataType = SQLTokenizer.CHAR;		break;
case SQLTokenizer.SQL_DATE:				dataType = SQLTokenizer.DATE;		break;
case SQLTokenizer.SQL_DECIMAL:			dataType = SQLTokenizer.DECIMAL;	break;
case SQLTokenizer.SQL_DOUBLE:			dataType = SQLTokenizer.DOUBLE;		break;
case SQLTokenizer.SQL_FLOAT:			dataType = SQLTokenizer.FLOAT;		break;
case SQLTokenizer.SQL_INTEGER:			dataType = SQLTokenizer.INT;		break;
case SQLTokenizer.SQL_LONGVARBINARY:	dataType = SQLTokenizer.LONGVARBINARY;break;
case SQLTokenizer.SQL_LONGVARCHAR:		dataType = SQLTokenizer.LONGVARCHAR;break;
case SQLTokenizer.SQL_REAL:				dataType = SQLTokenizer.REAL;		break;
case SQLTokenizer.SQL_SMALLINT:			dataType = SQLTokenizer.SMALLINT;	break;
case SQLTokenizer.SQL_TIME:				dataType = SQLTokenizer.TIME;		break;
case SQLTokenizer.SQL_TIMESTAMP:		dataType = SQLTokenizer.TIMESTAMP;	break;
case SQLTokenizer.SQL_TINYINT:			dataType = SQLTokenizer.TINYINT;	break;
case SQLTokenizer.SQL_VARBINARY:		dataType = SQLTokenizer.VARBINARY;	break;
case SQLTokenizer.SQL_VARCHAR:			dataType = SQLTokenizer.VARCHAR;	break;
default: throw new Error();
}
}else{
token = nextToken( MISSING_DATATYPE );
dataType = token.value;
}
Column col = new Column();
if(dataType == SQLTokenizer.LONG){
token = nextToken();
if(token != null && token.value == SQLTokenizer.RAW){
dataType = SQLTokenizer.LONGVARBINARY;
}else{
dataType = SQLTokenizer.LONGVARCHAR;
previousToken();
}
}
switch(dataType){
case SQLTokenizer.RAW:
dataType = SQLTokenizer.VARBINARY;
case SQLTokenizer.CHAR:
case SQLTokenizer.VARCHAR:
case SQLTokenizer.NCHAR:
case SQLTokenizer.NVARCHAR:
case SQLTokenizer.BINARY:
case SQLTokenizer.VARBINARY:
{
token = nextToken();
int displaySize;
if(token == null || token.value != SQLTokenizer.PARENTHESIS_L){
displaySize = 30;
previousToken();
}else{
token = nextToken( MISSING_EXPRESSION );
try{
displaySize = Integer.parseInt(token.getName(sql) );
}catch(Exception e){
throw createSyntaxError(token, MISSING_NUMBERVALUE );
}
nextToken( MISSING_PARENTHESIS_R );
}
col.setPrecision( displaySize );
break;
}
case SQLTokenizer.SYSNAME:
col.setPrecision(255);
dataType = SQLTokenizer.VARCHAR;
break;
case SQLTokenizer.COUNTER:
col.setAutoIncrement(true);
dataType = SQLTokenizer.INT;
break;
case SQLTokenizer.NUMERIC:
case SQLTokenizer.DECIMAL:
token = nextToken();
if(token != null && token.value == SQLTokenizer.PARENTHESIS_L){
token = nextToken( MISSING_EXPRESSION );
int value;
try{
value = Integer.parseInt(token.getName(sql) );
}catch(Exception e){
throw createSyntaxError(token, MISSING_NUMBERVALUE );
}
col.setPrecision(value);
token = nextToken( MISSING_COMMA_PARENTHESIS );
if(token.value == SQLTokenizer.COMMA){
token = nextToken( MISSING_EXPRESSION );
try{
value = Integer.parseInt(token.getName(sql) );
}catch(Exception e){
throw createSyntaxError(token, MISSING_NUMBERVALUE );
}
col.setScale(value);
nextToken( MISSING_PARENTHESIS_R );
}
}else{
col.setPrecision(18);
previousToken();
}
break;
}
col.setDataType( dataType );
return col;if(token.value == SQLTokenizer.ASTERISK) return;
if(token.value != SQLTokenizer.VALUE &&
token.value != SQLTokenizer.IDENTIFIER &&
token.value < 200){
throw createSyntaxError( token, Language.STXADD_IDENT_EXPECT);
}
if(name.length() == 0) {
throw createSyntaxError( token, Language.STXADD_IDENT_EMPTY, name);
}
char firstChar = name.charAt(0);
if(firstChar != '#' && firstChar < '@') {
throw createSyntaxError( token, Language.STXADD_IDENT_WRONG, name );
}String indexName = nextIdentifier();
nextToken(MISSING_ON);
String catalog;
String tableName = catalog = nextIdentifier();
tableName = nextIdentiferPart(tableName);
if(tableName == catalog) catalog = null;
CommandTable cmd = new CommandTable( con.log, catalog, tableName, SQLTokenizer.INDEX );
Expressions expressions = new Expressions();
Strings columns = new Strings();
expressionDefList( cmd, expressions, columns );
IndexDescription indexDesc = new IndexDescription(
indexName,
tableName,
unique ? SQLTokenizer.UNIQUE : SQLTokenizer.INDEX,
expressions,
columns);
Object[] param = { "Create Index" };
throw SmallSQLException.create(Language.UNSUPPORTED_OPERATION, param);if(token == null) return false;
switch(token.value){
case SQLTokenizer.SELECT:
case SQLTokenizer.INSERT:
case SQLTokenizer.UPDATE:
case SQLTokenizer.UNION:
case SQLTokenizer.FROM:
case SQLTokenizer.WHERE:
case SQLTokenizer.GROUP:
case SQLTokenizer.HAVING:
case SQLTokenizer.ORDER:
case SQLTokenizer.COMMA:
case SQLTokenizer.SET:
case SQLTokenizer.JOIN:
case SQLTokenizer.LIMIT:
return true;
}
return false;CommandSelect selCmd = new CommandSelect(con.log);
SQLToken token;
Switch: while(true){
token = nextToken(MISSING_EXPRESSION);
switch(token.value){
case SQLTokenizer.TOP:
token = nextToken(MISSING_EXPRESSION);
try{
int maxRows = Integer.parseInt(token.getName(sql));
selCmd.setMaxRows(maxRows);
}catch(NumberFormatException e){
throw createSyntaxError(token, Language.STXADD_NOT_NUMBER, token.getName(sql));
}
break;
case SQLTokenizer.ALL:
selCmd.setDistinct(false);
break;
case SQLTokenizer.DISTINCT:
selCmd.setDistinct(true);
break;
default:
previousToken();
break Switch;
}
}
while(true){
Expression column = expression(selCmd, 0);
selCmd.addColumnExpression( column );
token = nextToken();
if(token == null) return selCmd;
boolean as = false;
if(token.value == SQLTokenizer.AS){
token = nextToken(MISSING_EXPRESSION);
as = true;
}
if(as || (!isKeyword(token))){
String alias = getIdentifier( token);
column.setAlias( alias );
token = nextToken();
if(token == null) return selCmd;
}
switch(token.value){
case SQLTokenizer.COMMA:
if(column == null) throw createSyntaxError( token, MISSING_EXPRESSION );
column = null;
break;
case SQLTokenizer.FROM:
if(column == null) throw createSyntaxError( token, MISSING_EXPRESSION );
column = null;
from(selCmd);
return selCmd;
default:
if(!isKeyword(token))
throw createSyntaxError( token, new int[]{SQLTokenizer.COMMA, SQLTokenizer.FROM} );
previousToken();
return selCmd;
}
}throw SmallSQLException.create(Language.UNSUPPORTED_OPERATION, "Execute");nextToken(MISSING_BY);
cmd.setOrder(expressionTokenList(cmd, SQLTokenizer.ORDER));String msgStr = SmallSQLException.translateMsg(
Language.STXADD_KEYS_REQUIRED, new Object[] { });
StringBuffer msgBuf = new StringBuffer( msgStr );
for(int i=0; i<validValues.length; i++){
String name = SQLTokenizer.getKeyWord(validValues[i]);
if(name == null) name = String.valueOf( (char)validValues[i] );
msgBuf.append( name );
if (i < validValues.length - 2)
msgBuf.append( ", ");
else
if ( i == validValues.length - 2 )
msgBuf.append( " or ");
}
String message = getErrorString(
token, Language.CUSTOM_MESSAGE, msgBuf);
return SmallSQLException.create(Language.CUSTOM_MESSAGE, message);SQLToken tokenType = nextToken(COMMANDS_ALTER);
String catalog;
String tableName = catalog = nextIdentifier();
switch(tokenType.value){
case SQLTokenizer.TABLE:
case SQLTokenizer.VIEW:
case SQLTokenizer.INDEX:
case SQLTokenizer.PROCEDURE:
tableName = nextIdentiferPart(tableName);
if(tableName == catalog) catalog = null;
}
switch(tokenType.value){
case SQLTokenizer.TABLE:
return alterTable( catalog, tableName );
default:
Object[] param = { "ALTER " + tokenType.getName( sql ) };
throw SmallSQLException.create(Language.UNSUPPORTED_OPERATION, param);
}return getIdentifier( nextToken( MISSING_IDENTIFIER ) );RowSource right = rowSource(cmd, tables, 0);
SQLToken token = nextToken();
while(true){
if(token == null) {
throw createSyntaxError(token, Language.STXADD_JOIN_INVALID);
}
switch(token.value){
case SQLTokenizer.ON:
if(type == Join.RIGHT_JOIN)
return new Join( Join.LEFT_JOIN, right, left, expression( cmd, 0 ) );
return new Join( type, left, right, expression( cmd, 0 ) );
default:
if(!right.hasAlias()){
right.setAlias( token.getName( sql ) );
token = nextToken();
continue;
}
throw createSyntaxError( token, MISSING_ON );
}
}StringBuffer buffer = new StringBuffer(1024);
if(token != null){
Object[] params = { String.valueOf(token.offset),
String.valueOf(sql, token.offset, token.length) };
String begin = SmallSQLException.translateMsg(Language.SYNTAX_BASE_OFS, params);
buffer.append(begin);
}
else{
String begin = SmallSQLException.translateMsg(
Language.SYNTAX_BASE_END, new Object[] { });
buffer.append(begin);
}
String middle = SmallSQLException.translateMsg(
middleMsgCode, new Object[] { middleMsgParam });
buffer.append(middle);
int valOffset = (token != null) ? token.offset : sql.length;
int valBegin = Math.max( 0, valOffset-40);
int valEnd   = Math.min( valOffset+20, sql.length );
String lineSeparator = System.getProperty( "line.separator" );
buffer.append( lineSeparator );
buffer.append( sql, valBegin, valEnd-valBegin);
buffer.append( lineSeparator );
for(; valBegin<valOffset; valBegin++) buffer.append(' ');
buffer.append('^');
return buffer.toString();CommandUpdate cmd = new CommandUpdate(con.log);
DataSources tables = new DataSources();
cmd.setTables( tables );
cmd.setSource( rowSource( cmd, tables, 0 ) );
SQLToken token = nextToken(MISSING_SET);
while(true){
token = nextToken();
Expression dest = expressionSingle( cmd, token);
if(dest.getType() != Expression.NAME) throw createSyntaxError( token, MISSING_IDENTIFIER );
nextToken(MISSING_EQUALS);
Expression src = expression(cmd, 0);
cmd.addSetting( dest, src);
token = nextToken();
if(token == null) break;
switch(token.value){
case SQLTokenizer.WHERE:
where(cmd);
return cmd;
case SQLTokenizer.COMMA:
continue;
default: throw createSyntaxError( token, MISSING_WHERE_COMMA );
}
}
return cmd;String colName = getIdentifier( token );
Column col = datatype(false);
col.setName( colName );
token = nextToken();
boolean nullableWasSet = false;
boolean defaultWasSet = col.isAutoIncrement();
while(true){
if(token == null){
cmdCreate.addColumn( col );
return null;
}
switch(token.value){
case SQLTokenizer.PARENTHESIS_R:
case SQLTokenizer.COMMA:
cmdCreate.addColumn( col );
return token;
case SQLTokenizer.DEFAULT:
if(defaultWasSet) throw createSyntaxError( token, MISSING_COMMA_PARENTHESIS );
int offset = token.offset + token.length;
token = nextToken();
if(token != null) offset = token.offset;
previousToken();
Expression expr = expression(cmdCreate, 0);
SQLToken last = lastToken();
int length = last.offset + last.length - offset;
String def = new String( sql, offset, length );
col.setDefaultValue( expr, def );
defaultWasSet = true;
break;
case SQLTokenizer.IDENTITY:
if(defaultWasSet) throw createSyntaxError( token, MISSING_COMMA_PARENTHESIS );
col.setAutoIncrement(true);
defaultWasSet = true;
break;
case SQLTokenizer.NULL:
if(nullableWasSet) throw createSyntaxError( token, MISSING_COMMA_PARENTHESIS );
nullableWasSet = true;
break;
case SQLTokenizer.NOT:
if(nullableWasSet) throw createSyntaxError( token, MISSING_COMMA_PARENTHESIS );
token = nextToken( MISSING_NULL );
col.setNullable(false);
nullableWasSet = true;
break;
case SQLTokenizer.PRIMARY:
case SQLTokenizer.UNIQUE:
IndexDescription index = index(cmdCreate, token.value, cmdCreate.name, null, colName);
cmdCreate.addIndex( index );
break;
default:
throw createSyntaxError(token, MISSING_OPTIONS_DATATYPE);
}
token = nextToken();
}DataSources tables = new DataSources();
cmd.setTables(tables);
cmd.setSource( rowSource( cmd, tables, 0 ) );
SQLToken token;
while(null != (token = nextToken())){
switch(token.value){
case SQLTokenizer.WHERE:
where( cmd );
break;
case SQLTokenizer.GROUP:
group( cmd );
break;
case SQLTokenizer.HAVING:
having( cmd );
break;
default:
previousToken();
return;
}
}String name = token.getName(sql);
checkValidIdentifier( name, token );
return name;this.con = con;
Command cmd = parse( sqlString.toCharArray() );
SQLToken token = nextToken();
if(token != null){
throw createSyntaxError(token, Language.STXADD_ADDITIONAL_TOK);
}
return cmd;tokenIdx--;CommandDelete cmd = new CommandDelete(con.log);
nextToken(MISSING_TABLE);
from(cmd);
return cmd;if(tokenIdx > tokens.size()){
return null;
}
return (SQLToken)tokens.get( tokenIdx-1 );SQLToken token = nextToken();
if(token == null) throw createSyntaxError( token, validValues);
if(validValues == MISSING_EXPRESSION){
return token;
}
if(validValues == MISSING_IDENTIFIER){
switch(token.value){
case SQLTokenizer.PARENTHESIS_L:
case SQLTokenizer.PARENTHESIS_R:
case SQLTokenizer.COMMA:
throw createSyntaxError( token, validValues);
}
return token;
}
for(int i=validValues.length-1; i>=0; i--){
if(token.value == validValues[i]) return token;
}
throw createSyntaxError( token, validValues);while(true){
SQLToken token = nextToken(COMMANDS_CREATE);
switch(token.value){
case SQLTokenizer.DATABASE:
return createDatabase();
case SQLTokenizer.TABLE:
return createTable();
case SQLTokenizer.VIEW:
return createView();
case SQLTokenizer.INDEX:
return createIndex(false);
case SQLTokenizer.PROCEDURE:
return createProcedure();
case SQLTokenizer.UNIQUE:
do{
token = nextToken(COMMANDS_CREATE_UNIQUE);
}while(token.value == SQLTokenizer.INDEX);
return createIndex(true);
case SQLTokenizer.NONCLUSTERED:
case SQLTokenizer.CLUSTERED:
continue;
default:
throw createSyntaxError( token, COMMANDS_CREATE );
}
}String catalog;
String tableName = catalog = nextIdentifier();
tableName = nextIdentiferPart(tableName);
if(tableName == catalog) catalog = null;
CommandTable cmdCreate = new CommandTable( con.log, catalog, tableName, SQLTokenizer.CREATE );
SQLToken token = nextToken( MISSING_PARENTHESIS_L );
nextCol:
while(true){
token = nextToken( MISSING_EXPRESSION );
String constraintName;
if(token.value == SQLTokenizer.CONSTRAINT){
constraintName = nextIdentifier();
token = nextToken( MISSING_KEYTYPE );
}else{
constraintName = null;
}
switch(token.value){
case SQLTokenizer.PRIMARY:
case SQLTokenizer.UNIQUE:
case SQLTokenizer.FOREIGN:
IndexDescription index = index(cmdCreate, token.value, tableName, constraintName, null);
if(token.value == SQLTokenizer.FOREIGN){
nextToken( MISSING_REFERENCES );
String pk = nextIdentifier();
Expressions expressions = new Expressions();
Strings columns = new Strings();
expressionDefList( cmdCreate, expressions, columns );
IndexDescription pkIndex = new IndexDescription( null, pk, SQLTokenizer.UNIQUE, expressions, columns);
ForeignKey foreignKey = new ForeignKey(pk, pkIndex, tableName, index);
cmdCreate.addForeingnKey(foreignKey);
}else{
cmdCreate.addIndex( index );
}
token = nextToken( MISSING_COMMA_PARENTHESIS );
switch(token.value){
case SQLTokenizer.PARENTHESIS_R:
return cmdCreate;
case SQLTokenizer.COMMA:
continue nextCol;
}
}
token = addColumn( token, cmdCreate );
if(token == null){
throw createSyntaxError(token, MISSING_COMMA_PARENTHESIS);
}
switch(token.value){
case SQLTokenizer.PARENTHESIS_R:
return cmdCreate;
case SQLTokenizer.COMMA:
continue nextCol;
default:
throw createSyntaxError(token, MISSING_COMMA_PARENTHESIS);
}
}nextToken(MISSING_BY);
cmd.setGroup( expressionTokenList(cmd, SQLTokenizer.GROUP) );SQLToken token = nextToken(MISSING_EXPRESSION);
try{
int maxRows = Integer.parseInt(token.getName(sql));
selCmd.setMaxRows(maxRows);
}catch(NumberFormatException e){
throw createSyntaxError(token, Language.STXADD_NOT_NUMBER, token.getName(sql));
}boolean isMinus = false;
if(token != null){
switch(token.value){
case SQLTokenizer.NULL:
return new ExpressionValue( null, SQLTokenizer.NULL );
case SQLTokenizer.STRING:
return new ExpressionValue( token.getName(null), SQLTokenizer.VARCHAR );
case SQLTokenizer.IDENTIFIER:
{
String name = getIdentifier( token );
ExpressionName expr =  new ExpressionName( name );
SQLToken token2 = nextToken();
if(token2 != null && token2.value == SQLTokenizer.POINT){
expr.setNameAfterTableAlias( nextIdentifier() );
}else{
previousToken();
}
return expr;
}
case SQLTokenizer.TRUE:
return new ExpressionValue( Boolean.TRUE, SQLTokenizer.BOOLEAN );
case SQLTokenizer.FALSE:
return new ExpressionValue( Boolean.FALSE, SQLTokenizer.BOOLEAN );
case SQLTokenizer.ESCAPE_L:{
token = nextToken(COMMANDS_ESCAPE);
SQLToken para = nextToken(MISSING_EXPRESSION);
Expression expr;
switch(token.value){
case SQLTokenizer.D:
expr = new ExpressionValue( DateTime.valueOf(para.getName(sql), SQLTokenizer.DATE), SQLTokenizer.DATE );
break;
case SQLTokenizer.T:
expr = new ExpressionValue( DateTime.valueOf(para.getName(sql), SQLTokenizer.TIME), SQLTokenizer.TIME );
break;
case SQLTokenizer.TS:
expr = new ExpressionValue( DateTime.valueOf(para.getName(sql), SQLTokenizer.TIMESTAMP), SQLTokenizer.TIMESTAMP );
break;
case SQLTokenizer.FN:
nextToken(MISSING_PARENTHESIS_L);
expr = function(cmd, para, true);
break;
case SQLTokenizer.CALL:
throw new java.lang.UnsupportedOperationException("call escape sequence");
default: throw new Error();
}
token = nextToken( ESCAPE_MISSING_CLOSE );
return expr;
}
case SQLTokenizer.QUESTION:
ExpressionValue param = new ExpressionValue();
cmd.addParameter( param );
return param;
case SQLTokenizer.CASE:
return caseExpr(cmd);
case SQLTokenizer.MINUS:
case SQLTokenizer.PLUS:
do{
if(token.value == SQLTokenizer.MINUS)
isMinus = !isMinus;
token = nextToken();
if(token == null) throw createSyntaxError( token, MISSING_EXPRESSION );
}while(token.value == SQLTokenizer.MINUS || token.value == SQLTokenizer.PLUS);
default:
SQLToken token2 = nextToken();
if(token2 != null && token2.value == SQLTokenizer.PARENTHESIS_L){
if(isMinus)
return new ExpressionArithmetic( function( cmd, token, false ),  ExpressionArithmetic.NEGATIVE );
return function( cmd, token, false );
}else{
char chr1 = sql[ token.offset ];
if(chr1 == '$'){
previousToken();
String tok = new String(sql, token.offset+1, token.length-1);
if(isMinus) tok = "-" + tok;
return new ExpressionValue( new Money(Double.parseDouble(tok)), SQLTokenizer.MONEY );
}
String tok = new String(sql, token.offset, token.length);
if((chr1 >= '0' && '9' >= chr1) || chr1 == '.'){
previousToken();
if(token.length>1 && (sql[ token.offset +1 ] | 0x20) == 'x'){
if(isMinus) {
throw createSyntaxError(token, Language.STXADD_OPER_MINUS);
}
return new ExpressionValue( Utils.hex2bytes( sql, token.offset+2, token.length-2), SQLTokenizer.VARBINARY );
}
if(isMinus) tok = "-" + tok;
if(Utils.indexOf( '.', sql, token.offset, token.length ) >= 0 ||
Utils.indexOf( 'e', sql, token.offset, token.length ) >= 0){
return new ExpressionValue( new Double(tok), SQLTokenizer.DOUBLE );
}else{
try{
return new ExpressionValue( new Integer(tok), SQLTokenizer.INT );
}catch(NumberFormatException e){
return new ExpressionValue( new Long(tok), SQLTokenizer.BIGINT );
}
}
}else{
checkValidIdentifier( tok, token );
ExpressionName expr = new ExpressionName(tok);
if(token2 != null && token2.value == SQLTokenizer.POINT){
expr.setNameAfterTableAlias( nextIdentifier() );
}else{
previousToken();
}
if(isMinus)
return new ExpressionArithmetic( expr,  ExpressionArithmetic.NEGATIVE );
return expr;
}
}
}
}
return null;CommandDelete cmd = new CommandDelete(con.log);
nextToken(MISSING_FROM);
from(cmd);
SQLToken token = nextToken();
if(token != null){
if(token.value != SQLTokenizer.WHERE)
throw this.createSyntaxError(token, MISSING_WHERE);
where(cmd);
}
return cmd;SQLToken token = nextToken(MISSING_EXPRESSION);
Expression leftExpr;
switch(token.value){
case SQLTokenizer.NOT:
leftExpr =  new ExpressionArithmetic( expression( cmd, ExpressionArithmetic.NOT      / 10), ExpressionArithmetic.NOT);
break;
case SQLTokenizer.MINUS:
leftExpr =  new ExpressionArithmetic( expression( cmd, ExpressionArithmetic.NEGATIVE / 10), ExpressionArithmetic.NEGATIVE);
break;
case SQLTokenizer.TILDE:
leftExpr =  new ExpressionArithmetic( expression( cmd, ExpressionArithmetic.BIT_NOT  / 10), ExpressionArithmetic.BIT_NOT);
break;
case SQLTokenizer.PARENTHESIS_L:
leftExpr = expression( cmd, 0);
token = nextToken(MISSING_PARENTHESIS_R);
break;
default:
leftExpr = expressionSingle( cmd, token);
}
boolean isNot = false;
while((token = nextToken()) != null){
Expression rightExpr;
int operation = ExpressionArithmetic.getOperationFromToken(token.value);
int level = operation / 10;
if(previousOperationLevel >= level){
previousToken();
return leftExpr;
}
switch(token.value){
case SQLTokenizer.PLUS:
case SQLTokenizer.MINUS:
case SQLTokenizer.ASTERISK:
case SQLTokenizer.SLACH:
case SQLTokenizer.PERCENT:
case SQLTokenizer.EQUALS:
case SQLTokenizer.LESSER:
case SQLTokenizer.LESSER_EQU:
case SQLTokenizer.GREATER:
case SQLTokenizer.GREATER_EQU:
case SQLTokenizer.UNEQUALS:
case SQLTokenizer.LIKE:
case SQLTokenizer.OR:
case SQLTokenizer.AND:
case SQLTokenizer.BIT_AND:
case SQLTokenizer.BIT_OR:
case SQLTokenizer.BIT_XOR:
rightExpr = expression( cmd, level );
leftExpr = new ExpressionArithmetic( leftExpr, rightExpr, operation );
break;
case SQLTokenizer.BETWEEN:
rightExpr = expression( cmd, ExpressionArithmetic.AND );
nextToken( MISSING_AND );
Expression rightExpr2 = expression( cmd, level );
leftExpr = new ExpressionArithmetic( leftExpr, rightExpr, rightExpr2, operation );
break;
case SQLTokenizer.IN:
nextToken(MISSING_PARENTHESIS_L);
token = nextToken(MISSING_EXPRESSION);
if(token.value == SQLTokenizer.SELECT){
CommandSelect cmdSel = select();
leftExpr = new ExpressionInSelect( con, leftExpr, cmdSel, operation );
nextToken(MISSING_PARENTHESIS_R);
}else{
previousToken();
Expressions list = expressionParenthesisList( cmd );
leftExpr = new ExpressionArithmetic( leftExpr, list, operation );
}
break;
case SQLTokenizer.IS:
token = nextToken(MISSING_NOT_NULL);
if(token.value == SQLTokenizer.NOT){
nextToken(MISSING_NULL);
operation++;
}
leftExpr = new ExpressionArithmetic( leftExpr, operation );
break;
case SQLTokenizer.NOT:
token = nextToken(MISSING_BETWEEN_IN);
previousToken();
isNot = true;
continue;
default:
previousToken();
return leftExpr;
}
if(isNot){
isNot = false;
leftExpr =  new ExpressionArithmetic( leftExpr, ExpressionArithmetic.NOT);
}
}
previousToken();
return leftExpr;String viewName = nextIdentifier();
nextToken(MISSING_AS);
SQLToken token = nextToken(MISSING_SELECT);
CommandCreateView cmd = new CommandCreateView( con.log, viewName );
cmd.sql = new String(sql, token.offset, sql.length-token.offset );
select();
return cmd;if(tokenIdx >= tokens.size()){
tokenIdx++;
return null;
}
return (SQLToken)tokens.get( tokenIdx++ );cmd.setWhere( expression(cmd, 0) );ExpressionFunctionCase expr = new ExpressionFunctionCase();
SQLToken token = nextToken(MISSING_EXPRESSION);
Expression input = null;
if(token.value != SQLTokenizer.WHEN){
previousToken();
input = expression(cmd, 0);
token = nextToken(MISSING_WHEN_ELSE_END);
}
while(true){
switch(token.value){
case SQLTokenizer.WHEN:
Expression condition = expression(cmd, 0);
if(input != null){
condition = new ExpressionArithmetic( input, condition, ExpressionArithmetic.EQUALS);
}
nextToken(MISSING_THEN);
Expression result = expression(cmd, 0);
expr.addCase(condition, result);
break;
case SQLTokenizer.ELSE:
expr.setElseResult(expression(cmd, 0));
break;
case SQLTokenizer.END:
expr.setEnd();
return expr;
default:
throw new Error();
}
token = nextToken(MISSING_WHEN_ELSE_END);
}SQLToken token = nextToken();
if(token == null) throw createSyntaxError( token, MISSING_EXPRESSION );
return new CommandCreateDatabase( con.log, token.getName(sql));SQLToken token = nextToken( MISSING_INTO );
CommandInsert cmd = new CommandInsert( con.log, nextIdentifier() );
int parthesisCount = 0;
token = nextToken(MISSING_PARENTHESIS_VALUES_SELECT);
if(token.value == SQLTokenizer.PARENTHESIS_L){
token = nextToken(MISSING_EXPRESSION);
if(token.value == SQLTokenizer.SELECT){
parthesisCount++;
cmd.noColumns = true;
}else{
previousToken();
Expressions list = expressionParenthesisList(cmd);
for(int i=0; i<list.size(); i++){
cmd.addColumnExpression( list.get( i ) );
}
token = nextToken(MISSING_PARENTHESIS_VALUES_SELECT);
}
}else cmd.noColumns = true;
Switch: while(true)
switch(token.value){
case SQLTokenizer.VALUES:{
token = nextToken(MISSING_PARENTHESIS_L);
cmd.addValues( expressionParenthesisList(cmd) );
return cmd;
}
case SQLTokenizer.SELECT:
cmd.addValues( select() );
while(parthesisCount-- > 0){
nextToken(MISSING_PARENTHESIS_R);
}
return cmd;
case SQLTokenizer.PARENTHESIS_L:
token = nextToken(MISSING_PARENTHESIS_VALUES_SELECT);
parthesisCount++;
continue Switch;
default:
throw new Error();
}this.sql = sql;
this.tokens = SQLTokenizer.parseSQL( sql );
tokenIdx = 0;
SQLToken token = nextToken(COMMANDS);
switch (token.value){
case SQLTokenizer.SELECT:
return select();
case SQLTokenizer.DELETE:
return delete();
case SQLTokenizer.INSERT:
return insert();
case SQLTokenizer.UPDATE:
return update();
case SQLTokenizer.CREATE:
return create();
case SQLTokenizer.DROP:
return drop();
case SQLTokenizer.ALTER:
return alter();
case SQLTokenizer.SET:
return set();
case SQLTokenizer.USE:
token = nextToken(MISSING_EXPRESSION);
String name = token.getName( sql );
checkValidIdentifier( name, token );
CommandSet set = new CommandSet( con.log, SQLTokenizer.USE);
set.name = name;
return set;
case SQLTokenizer.EXECUTE:
return execute();
case SQLTokenizer.TRUNCATE:
return truncate();
default:
throw new Error();
}SQLToken token = nextToken(MISSING_EXPRESSION);
switch(token.value){
case SQLTokenizer.PARENTHESIS_L:
return rowSource( cmd, tables, SQLTokenizer.PARENTHESIS_R );
case SQLTokenizer.ESCAPE_L:
token = nextToken(MISSING_OJ);
return rowSource( cmd, tables, SQLTokenizer.ESCAPE_R );
case SQLTokenizer.SELECT:
ViewResult viewResult = new ViewResult( con, select() );
tables.add(viewResult);
return viewResult;
}
String catalog = null;
String name = getIdentifier( token );
token = nextToken();
if(token != null && token.value == SQLTokenizer.POINT){
catalog = name;
name = nextIdentifier();
token = nextToken();
}
TableView tableView = Database.getTableView( con, catalog, name);
TableViewResult table = TableViewResult.createResult(tableView);
tables.add( table );
if(token != null && token.value == SQLTokenizer.AS){
token = nextToken(MISSING_EXPRESSION);
table.setAlias( token.getName( sql ) );
}else{
previousToken();
}
return table;SQLToken tokenType = nextToken(COMMANDS_DROP);
String catalog;
String name = catalog = nextIdentifier();
name = nextIdentiferPart( name );
if(name == catalog) catalog = null;
switch(tokenType.value){
case SQLTokenizer.DATABASE:
case SQLTokenizer.TABLE:
case SQLTokenizer.VIEW:
case SQLTokenizer.INDEX:
case SQLTokenizer.PROCEDURE:
return new CommandDrop( con.log, catalog, name, tokenType.value);
default:
throw createSyntaxError( tokenType, COMMANDS_DROP );
}Object[] param = { "Create Procedure" };
throw SmallSQLException.create(Language.UNSUPPORTED_OPERATION, param);if(name != null) return name;
return new String( sql, offset, length );return (String)keywords.get( Utils.getInteger(key) );keywords.put( Utils.getInteger( value), keyword );
char[] letters = keyword.toCharArray();
if(searchTree == null){
searchTree = new SearchNode();
searchTree.letter = (char)(letters[0] | 0x20);
}
SearchNode prev = null;
SearchNode node = searchTree;
boolean wasNextEntry = true;
for(int i=0; i<letters.length; i++){
char c = (char)(letters[i] | 0x20);
while(node != null && node.letter != c) {
prev = node;
node = node.nextEntry;
wasNextEntry = true;
}
if(node == null){
node = new SearchNode();
node.letter = c;
if(wasNextEntry)
prev.nextEntry = node;
else prev.nextLetter = node;
wasNextEntry = false;
prev = node;
node = null;
}else{
prev = node;
node = node.nextLetter;
wasNextEntry = false;
}
}
prev.value = value;switch(type){
case SQLTokenizer.BIT:
return Types.BIT;
case SQLTokenizer.BOOLEAN:
return Types.BOOLEAN;
case SQLTokenizer.BINARY:
return Types.BINARY;
case SQLTokenizer.VARBINARY:
return Types.VARBINARY;
case SQLTokenizer.LONGVARBINARY:
return Types.LONGVARBINARY;
case SQLTokenizer.BLOB:
return Types.BLOB;
case SQLTokenizer.TINYINT:
return Types.TINYINT;
case SQLTokenizer.SMALLINT:
return Types.SMALLINT;
case SQLTokenizer.INT:
return Types.INTEGER;
case SQLTokenizer.BIGINT:
return Types.BIGINT;
case SQLTokenizer.SMALLMONEY:
case SQLTokenizer.MONEY:
case SQLTokenizer.DECIMAL:
return Types.DECIMAL;
case SQLTokenizer.NUMERIC:
return Types.NUMERIC;
case SQLTokenizer.REAL:
return Types.REAL;
case SQLTokenizer.FLOAT:
return Types.FLOAT;
case SQLTokenizer.DOUBLE:
return Types.DOUBLE;
case SQLTokenizer.DATE:
return Types.DATE;
case SQLTokenizer.TIME:
return Types.TIME;
case SQLTokenizer.TIMESTAMP:
case SQLTokenizer.SMALLDATETIME:
return Types.TIMESTAMP;
case SQLTokenizer.CHAR:
case SQLTokenizer.NCHAR:
return Types.CHAR;
case SQLTokenizer.VARCHAR:
case SQLTokenizer.NVARCHAR:
return Types.VARCHAR;
case SQLTokenizer.LONGNVARCHAR:
case SQLTokenizer.LONGVARCHAR:
return Types.LONGVARCHAR;
case SQLTokenizer.CLOB:
case SQLTokenizer.NCLOB:
return Types.CLOB;
case SQLTokenizer.JAVA_OBJECT:
return Types.JAVA_OBJECT;
case SQLTokenizer.UNIQUEIDENTIFIER:
return -11;
case SQLTokenizer.NULL:
return Types.NULL;
default: throw new Error("DataType:"+type);
}SearchNode node = searchTree;
ArrayList tokens = new ArrayList();
int value = 0;
int tokenStart = 0;
boolean wasWhiteSpace = true;
int comment = NOT_COMMENT;
char quote = 0;
StringBuffer quoteBuffer = new StringBuffer();
for(int i=0; i<sql.length; i++){
char c = sql[i];
switch(c){
case '\"':
case '\'':
if (comment != NOT_COMMENT) {
break;
}else if(quote == 0){
quote = c;
}else if(quote == c){
if(i+1<sql.length && sql[i+1] == quote){
quoteBuffer.append(quote);
i++;
}else{
tokens.add( new SQLToken( quoteBuffer.toString(), (quote == '\'') ? STRING : IDENTIFIER,       tokenStart, i+1) );
quoteBuffer.setLength(0);
quote = 0;
tokenStart = i+1;
wasWhiteSpace = true;
}
}else quoteBuffer.append(c);
break;
case '.':
if (comment != NOT_COMMENT) {
break;
}else if(quote == 0){
int k=tokenStart;
if(k == i){
if(sql.length> k+1){
char cc = sql[k+1];
if((cc >= '0') && cc <= '9') break;
}
}else{
for(; k<i; k++){
char cc = sql[k];
if((cc != '-' && cc != '$' && cc < '0') || cc > '9') break;
}
if(k>=i) break;
}
}
case '-':
if (comment != NOT_COMMENT) {
break;
}
else if (c == '-' && (i+1 < sql.length) && (sql[i+1] == '-')) {
if(!wasWhiteSpace){
tokens.add( new SQLToken( value, tokenStart, i) );
value = 0;
}
i++;
tokenStart = i+1;
comment = LINE_COMMENT;
}
else if(quote == 0 && !wasWhiteSpace){
char c1 = sql[tokenStart];
char cx = sql[i-1];
if(((c1 >= '0' && c1 <= '9') || c1 == '.') && (cx == 'e' || cx == 'E'))
break;
if(c1 == '$' && tokenStart+1 == i)
break;
}
case ' ':
case '\t':
case '\n':
case '\r':
case ',':
case '(':
case ')':
case '{':
case '}':
case '*':
case '+':
case '/':
case '%':
case '&':
case '|':
case '=':
case '<':
case '>':
case '?':
case '^':
case '~':
if (comment == LINE_COMMENT) {
if (c == '\r' || c == '\n') {
comment = NOT_COMMENT;
wasWhiteSpace = true;
}
tokenStart = i+1;
break;
}
else if (comment == MULTI_COMMENT) {
if (c == '*' && (i+1 < sql.length) && (sql[i+1] == '/')) {
comment = NOT_COMMENT;
wasWhiteSpace = true;
i++;
}
tokenStart = i + 1;
break;
}
else if(quote == 0){
if(!wasWhiteSpace){
tokens.add( new SQLToken( value, tokenStart, i) );
value = 0;
}
switch(c){
case ' ':
case '\t':
case '\n':
case '\r':
break;
case '<':
if((i+1 < sql.length) && (sql[i+1] == '>')){
tokens.add( new SQLToken( UNEQUALS, i, i+2) );
i++;
break;
}
case '>':
if((i+1 < sql.length) && (sql[i+1] == '=')){
tokens.add( new SQLToken( 100 + c, i, i+2) );
i++;
break;
}
case '/':
if((i+1 < sql.length) && (sql[i+1] == '*')){
i++;
tokenStart = i+1;
comment = MULTI_COMMENT;
break;
}
default:
tokens.add( new SQLToken( c, i, i+1) );
}
wasWhiteSpace = true;
tokenStart = i+1;
}else{
quoteBuffer.append(c);
}
break;
default:
if (comment != NOT_COMMENT) {
break;
}else if(quote == 0){
if(wasWhiteSpace){
node = searchTree;
}else{
if(node == null){
value = 0;
wasWhiteSpace = false;
break;
}
}
c |= 0x20;
while(node != null && node.letter != c) node = node.nextEntry;
if(node != null){
value = node.value;
node = node.nextLetter;
}else{
value = 0;
node = null;
}
}else{
quoteBuffer.append(c);
}
wasWhiteSpace = false;
break;
}
}
if (comment == MULTI_COMMENT) {
throw SmallSQLException.create(Language.STXADD_COMMENT_OPEN);
}
if(!wasWhiteSpace) {
tokens.add( new SQLToken( value, tokenStart, sql.length) );
}
return tokens;setBigDecimal( findParameter( parameterName ), x );throw new java.lang.UnsupportedOperationException("Method getValue() not yet implemented.");setTimestamp( findParameter( parameterName ), x );try{
Expression expr = getValue(i);
wasNull = expr.isNull();
if(wasNull) return null;
return DateTime.getTime( expr.getLong() );
}catch(Exception e){
throw SmallSQLException.createFromException( e );
}setObject( findParameter( parameterName ), x );setFloat( findParameter( parameterName ), x );return getTimestamp( findParameter( parameterName ) );return getObject( findParameter( parameterName ), map );setString( findParameter( parameterName ), x );setShort( findParameter( parameterName ), x );return getURL( findParameter( parameterName ) );try{
Expression expr = getValue(i);
wasNull = expr.isNull();
if(wasNull) return null;
return DateTime.getDate( expr.getLong() );
}catch(Exception e){
throw SmallSQLException.createFromException( e );
}return getBlob( findParameter( parameterName ) );return getBoolean( findParameter( parameterName ) );return (byte)getInt( i );return getArray( findParameter( parameterName ) );return (byte)getInt( i );throw SmallSQLException.create(Language.UNSUPPORTED_OPERATION, "Method registerOutParameter() not yet implemented.");try{
Expression expr = getValue(i);
wasNull = expr.isNull();
return expr.getBoolean();
}catch(Exception e){
throw SmallSQLException.createFromException( e );
}throw SmallSQLException.create(Language.UNSUPPORTED_OPERATION, "Method getDate() not yet implemented.");throw SmallSQLException.create(Language.UNSUPPORTED_OPERATION, "Method getURL() not yet implemented.");throw SmallSQLException.create(Language.UNSUPPORTED_OPERATION, "Method getObject() not yet implemented.");setObject( findParameter( parameterName ), x, sqlType );throw SmallSQLException.create(Language.UNSUPPORTED_OPERATION, "Method getTime() not yet implemented.");throw SmallSQLException.create(Language.UNSUPPORTED_OPERATION, "Method getTimestamp() not yet implemented.");setBinaryStream( findParameter( parameterName ), x, length );setDate( findParameter( parameterName ), x, cal );setAsciiStream( findParameter( parameterName ), x, length );setBytes( findParameter( parameterName ), x );setCharacterStream( findParameter( parameterName ), x, length );setDouble( findParameter( parameterName ), x );return getDouble( findParameter( parameterName ) );return getFloat( findParameter( parameterName ) );return getByte( findParameter( parameterName ) );return getLong( findParameter( parameterName ) );setLong( findParameter( parameterName ), x );setByte( findParameter( parameterName ), x );setNull( findParameter( parameterName ), sqlType );try{
Object obj = getValue(i).getObject();
wasNull = obj == null;
return obj;
}catch(Exception e){
throw SmallSQLException.createFromException( e );
}throw new java.lang.UnsupportedOperationException("Method registerOutParameter() not yet implemented.");return wasNull;throw new java.lang.UnsupportedOperationException("Method registerOutParameter() not yet implemented.");setObject( findParameter( parameterName ), x, sqlType, scale );return getString( findParameter( parameterName ) );return getClob( findParameter( parameterName ) );return getShort( findParameter( parameterName ) );return getRef( findParameter( parameterName ) );return getBytes( findParameter( parameterName ) );try{
Expression expr = getValue(i);
wasNull = expr.isNull();
return expr.getFloat();
}catch(Exception e){
throw SmallSQLException.createFromException( e );
}try{
Expression expr = getValue(i);
wasNull = expr.isNull();
return expr.getLong();
}catch(Exception e){
throw SmallSQLException.createFromException( e );
}try{
Expression expr = getValue(i);
wasNull = expr.isNull();
return expr.getLong();
}catch(Exception e){
throw SmallSQLException.createFromException( e );
}return getTimestamp( findParameter( parameterName ), cal );try{
Expression expr = getValue(i);
wasNull = expr.isNull();
if(wasNull) return null;
return DateTime.getTimestamp( expr.getLong() );
}catch(Exception e){
throw SmallSQLException.createFromException( e );
}setInt( findParameter( parameterName ), x );setURL( findParameter( parameterName ), x );setBoolean( findParameter( parameterName ), x );return getTime( findParameter( parameterName ), cal );try{
byte[] obj = getValue(i).getBytes();
wasNull = obj == null;
return obj;
}catch(Exception e){
throw SmallSQLException.createFromException( e );
}setNull( findParameter( parameterName ), sqlType, typeName );setTime( findParameter( parameterName ), x );return getDate( findParameter( parameterName ), cal );return getObject( findParameter( parameterName ) );try{
MutableNumeric obj = getValue(i).getNumeric();
wasNull = obj == null;
if(wasNull) return null;
return obj.toBigDecimal(scale);
}catch(Exception e){
throw SmallSQLException.createFromException( e );
}try{
String obj = getValue(i).getString();
wasNull = obj == null;
return obj;
}catch(Exception e){
throw SmallSQLException.createFromException( e );
}setTime( findParameter( parameterName ), x, cal );return getInt( findParameter( parameterName ) );registerOutParameter( findParameter( parameterName ), sqlType, scale );throw SmallSQLException.create(Language.UNSUPPORTED_OPERATION, "Method getClob() not yet implemented.");setDate( findParameter( parameterName ), x );try{
Expression expr = getValue(i);
wasNull = expr.isNull();
return expr.getInt();
}catch(Exception e){
throw SmallSQLException.createFromException( e );
}throw SmallSQLException.create(Language.UNSUPPORTED_OPERATION, "Method getBlob() not yet implemented.");throw SmallSQLException.create(Language.UNSUPPORTED_OPERATION, "Method getRef() not yet implemented.");throw SmallSQLException.create(Language.UNSUPPORTED_OPERATION, "Method getArray() not yet implemented.");registerOutParameter( findParameter( parameterName ), sqlType );return getTime( findParameter( parameterName ) );return getBigDecimal( findParameter( parameterName ) );return getDate( findParameter( parameterName ) );registerOutParameter( findParameter( parameterName ), sqlType, typeName );setTimestamp( findParameter( parameterName ), x, cal );try{
MutableNumeric obj = getValue(i).getNumeric();
wasNull = obj == null;
if(wasNull) return null;
return obj.toBigDecimal();
}catch(Exception e){
throw SmallSQLException.createFromException( e );
}throw new java.lang.UnsupportedOperationException("Method findParameter() not yet implemented.");if(savepoint instanceof SSSavepoint){
if(((SSSavepoint)savepoint).transactionTime != transactionTime){
throw SmallSQLException.create(Language.SAVEPT_INVALID_TRANS);
}
rollback( savepoint.getSavepointId() );
return;
}
throw SmallSQLException.create(Language.SAVEPT_INVALID_DRIVER, savepoint);return new SSSavepoint(getSavepoint(), name, transactionTime);SSPreparedStatement pr = new SSPreparedStatement( this, sql);
pr.setNeedGeneratedKeys(columnIndexes);
return pr;return (commitPages == null);return sql;return autoCommit;testClosedConnection();
synchronized(getMonitor()){
commitPages.add(storePage);
}if(isClosed()) throw SmallSQLException.create(Language.CONNECTION_CLOSED);SSPreparedStatement pr = new SSPreparedStatement( this, sql);
pr.setNeedGeneratedKeys(columnNames);
return pr;return this;testClosedConnection();
database = Database.getDatabase(catalog, this, false);return new SSPreparedStatement( this, sql);testClosedConnection();
synchronized(getMonitor()){
for(int i = commitPages.size() - 1; i >= savepoint; i--){
TransactionStep page = (TransactionStep)commitPages.remove(i);
page.rollback();
page.freeLock();
}
}SSPreparedStatement pr = new SSPreparedStatement( this, sql);
pr.setNeedGeneratedKeys(autoGeneratedKeys);
return pr;if(!metadata.supportsTransactionIsolationLevel(level)) {
throw SmallSQLException.create(Language.ISOLATION_UNKNOWN, String.valueOf(level));
}
isolationLevel = level;return null;return holdability;return null;return metadata;testClosedConnection();
if(!returnNull && database == null) throw SmallSQLException.create(Language.DB_NOTCONNECTED);
return database;return readonly;rollback();
database = null;
commitPages = null;
Database.closeConnection(this);return isolationLevel;this.holdability = holdability;return new SSPreparedStatement( this, sql);return new SSCallableStatement( this, sql);if(log.isLogging()) log.println("AutoCommit:"+autoCommit);
if(this.autoCommit != autoCommit){
commit();
this.autoCommit = autoCommit;
}if(database == null)
return "";
return database.getName();log.println("Rollback");
testClosedConnection();
synchronized(getMonitor()){
int count = commitPages.size();
for(int i=0; i<count; i++){
TransactionStep page = (TransactionStep)commitPages.get(i);
page.rollback();
page.freeLock();
}
commitPages.clear();
transactionTime = System.currentTimeMillis();
}testClosedConnection();
synchronized(getMonitor()){
for(int i = commitPages.size() - 1; i >= 0; i--){
TransactionStep page = (TransactionStep)commitPages.get(i);
if(page.raFile == raFile){
page.rollback();
page.freeLock();
}
}
}log.println("Commit");
testClosedConnection();
synchronized(getMonitor()){
try{
int count = commitPages.size();
for(int i=0; i<count; i++){
TransactionStep page = (TransactionStep)commitPages.get(i);
page.commit();
}
for(int i=0; i<count; i++){
TransactionStep page = (TransactionStep)commitPages.get(i);
page.freeLock();
}
commitPages.clear();
transactionTime = System.currentTimeMillis();
}catch(Throwable e){
rollback();
throw SmallSQLException.createFromException(e);
}
}return new SSStatement( this, resultSetType, resultSetConcurrency);if(savepoint instanceof SSSavepoint){
((SSSavepoint)savepoint).transactionTime = 0;
return;
}
throw SmallSQLException.create(Language.SAVEPT_INVALID_DRIVER, new Object[] { savepoint });return new SSCallableStatement( this, sql, resultSetType, resultSetConcurrency);return new SSStatement(this);return new SSSavepoint(getSavepoint(), null, transactionTime);testClosedConnection();
return commitPages.size();return new SSStatement( this, resultSetType, resultSetConcurrency);return new SSCallableStatement( this, sql, resultSetType, resultSetConcurrency);return new SSPreparedStatement( this, sql, resultSetType, resultSetConcurrency);StringBuffer buf = new StringBuffer();
for(int i=from; i<=to; i++){
if(i != from) buf.append(',');
buf.append( SQLTokenizer.getKeyWord(i) );
}
return buf.toString();try {
String[] colNames = {"TABLE_CAT", "TABLE_SCHEM", "TABLE_NAME", "NON_UNIQUE", "INDEX_QUALIFIER", "INDEX_NAME", "TYPE", "ORDINAL_POSITION", "COLUMN_NAME", "ASC_OR_DESC", "CARDINALITY", "PAGES", "FILTER_CONDITION"};
Object[][] data   = con.getDatabase(false).getIndexInfo(con, table, unique);
return new SSResultSet( st, Utils.createMemoryCommandSelect( con, colNames, data));
} catch (Exception e) {
throw SmallSQLException.createFromException(e);
}try {
String[] colNames = {"SCOPE", "COLUMN_NAME", "DATA_TYPE", "TYPE_NAME", "COLUMN_SIZE", "BUFFER_LENGTH", "DECIMAL_DIGITS", "PSEUDO_COLUMN"};
Object[][] data   = con.getDatabase(false).getBestRowIdentifier(con, table);
return new SSResultSet( st, Utils.createMemoryCommandSelect( con, colNames, data));
} catch (Exception e) {
throw SmallSQLException.createFromException(e);
}return getFunctions(SQLTokenizer.ASCII, SQLTokenizer.UCASE);return SSDriver.drv.getMajorVersion();String[] colNames = {"TYPE_CAT", "TYPE_SCHEM", "TYPE_NAME", "CLASS_NAME", "DATA_TYPE", "REMARKS"};
Object[][] data   = new Object[0][];
return new SSResultSet( st, Utils.createMemoryCommandSelect( con, colNames, data));return Connection.TRANSACTION_READ_COMMITTED;return getCrossReference( null, null, null, null, null, table );return "";return 3;String[] colNames = {"TABLE_CAT"};
Object[][] data   = Database.getCatalogs(con.getDatabase(true));
return new SSResultSet( st, Utils.createMemoryCommandSelect( con, colNames, data));String[] colNames = {"TABLE_SCHEM"};
Object[][] data   = new Object[0][];
return new SSResultSet( st, Utils.createMemoryCommandSelect( con, colNames, data));String[] colNames = {"PROCEDURE_CAT", "PROCEDURE_SCHEM", "PROCEDURE_NAME", "", "", "", "REMARKS", "PROCEDURE_TYPE"};
Object[][] data   = new Object[0][];
return new SSResultSet( st, Utils.createMemoryCommandSelect( con, colNames, data));switch(type){
case ResultSet.TYPE_FORWARD_ONLY:
case ResultSet.TYPE_SCROLL_INSENSITIVE:
case ResultSet.TYPE_SCROLL_SENSITIVE:
return true;
}
return false;return getFunctions(SQLTokenizer.CURDATE, SQLTokenizer.YEAR);return ResultSet.HOLD_CURSORS_OVER_COMMIT;return "database,use";return "\"";return false;return false;return "SmallSQL Database";return "database";return false;return false;return false;return false;return false;return false;return false;return false;return false;return false;return false;return false;return false;return false;return false;return false;return "procedure";return "\\";return true;try {
String[] colNames = {"TABLE_CAT", "TABLE_SCHEM", "TABLE_NAME", "COLUMN_NAME", "DATA_TYPE", "TYPE_NAME", "COLUMN_SIZE", "BUFFER_LENGTH", "DECIMAL_DIGITS", "NUM_PREC_RADIX", "NULLABLE", "REMARKS", "COLUMN_DEF", "SQL_DATA_TYPE", "SQL_DATETIME_SUB", "CHAR_OCTET_LENGTH", "ORDINAL_POSITION", "IS_NULLABLE"};
Object[][] data   = con.getDatabase(false).getColumns(con, tableNamePattern, columnNamePattern);
return new SSResultSet( st, Utils.createMemoryCommandSelect( con, colNames, data));
} catch (Exception e) {
throw SmallSQLException.createFromException(e);
}String[] colNames = {		"TYPE_NAME", 				"DATA_TYPE", 																	"PRECISION", 	"LITERAL_PREFIX", "LITERAL_SUFFIX", 		"CREATE_PARAMS", "NULLABLE", 	 "CASE_SENSITIVE", "SEARCHABLE", "UNSIGNED_ATTRIBUTE", "FIXED_PREC_SCALE", "AUTO_INCREMENT", "LOCAL_TYPE_NAME", "MINIMUM_SCALE", "MAXIMUM_SCALE", "SQL_DATA_TYPE", "SQL_DATETIME_SUB", "NUM_PREC_RADIX"};
Object[][] data   = {
{SQLTokenizer.getKeyWord(SQLTokenizer.UNIQUEIDENTIFIER),Utils.getShort(SQLTokenizer.getSQLDataType( SQLTokenizer.UNIQUEIDENTIFIER)), Utils.getInteger(36),      	"'",  "'",  null, 				Utils.getShort(typeNullable), Boolean.FALSE, Utils.getShort(typeSearchable), null,          Boolean.FALSE, Boolean.FALSE, null, null,                null,                null, null, null},
{SQLTokenizer.getKeyWord(SQLTokenizer.BIT),             Utils.getShort(SQLTokenizer.getSQLDataType( SQLTokenizer.BIT) ),             Utils.getInteger(1),      	null, null, null, 				Utils.getShort(typeNullable), Boolean.FALSE, Utils.getShort(typeSearchable), null,          Boolean.FALSE, Boolean.FALSE, null, Utils.getInteger(0), Utils.getInteger(0), null, null, null},
{SQLTokenizer.getKeyWord(SQLTokenizer.TINYINT),         Utils.getShort(SQLTokenizer.getSQLDataType( SQLTokenizer.TINYINT) ),         Utils.getInteger(3),      	null, null, null, 				Utils.getShort(typeNullable), Boolean.FALSE, Utils.getShort(typeSearchable), Boolean.TRUE,  Boolean.FALSE, Boolean.FALSE, null, Utils.getInteger(0), Utils.getInteger(0), null, null, null},
{SQLTokenizer.getKeyWord(SQLTokenizer.BIGINT),          Utils.getShort(SQLTokenizer.getSQLDataType( SQLTokenizer.BIGINT) ),          Utils.getInteger(19),     	null, null, null, 				Utils.getShort(typeNullable), Boolean.FALSE, Utils.getShort(typeSearchable), Boolean.FALSE, Boolean.FALSE, Boolean.FALSE, null, Utils.getInteger(0), Utils.getInteger(0), null, null, null},
{SQLTokenizer.getKeyWord(SQLTokenizer.LONGVARBINARY),   Utils.getShort(SQLTokenizer.getSQLDataType( SQLTokenizer.LONGVARBINARY) ),   Utils.getInteger(2147483647),	"0x", null, null, 		 		Utils.getShort(typeNullable), Boolean.FALSE, Utils.getShort(typeSearchable), null, 			Boolean.FALSE, Boolean.FALSE, null, null, 				 null, 				  null, null, null},
{SQLTokenizer.getKeyWord(SQLTokenizer.VARBINARY),   	 Utils.getShort(SQLTokenizer.getSQLDataType( SQLTokenizer.VARBINARY) ),   	  Utils.getInteger(65535),	    "0x", null, "max length", 		Utils.getShort(typeNullable), Boolean.FALSE, Utils.getShort(typeSearchable), null, 			Boolean.FALSE, Boolean.FALSE, null, null, 				 null, 				  null, null, null},
{SQLTokenizer.getKeyWord(SQLTokenizer.BINARY),   	 	 Utils.getShort(SQLTokenizer.getSQLDataType( SQLTokenizer.BINARY) ),   	  	  Utils.getInteger(65535),	    "0x", null, "length", 			Utils.getShort(typeNullable), Boolean.FALSE, Utils.getShort(typeSearchable), null, 			Boolean.FALSE, Boolean.FALSE, null, null, 				 null, 				  null, null, null},
{SQLTokenizer.getKeyWord(SQLTokenizer.LONGVARCHAR),     Utils.getShort(SQLTokenizer.getSQLDataType( SQLTokenizer.LONGVARCHAR) ),     Utils.getInteger(2147483647),	"'",  "'",  null, 		 		Utils.getShort(typeNullable), Boolean.FALSE, Utils.getShort(typeSearchable), null, 			Boolean.FALSE, Boolean.FALSE, null, null, 				 null, 				  null, null, null},
{SQLTokenizer.getKeyWord(SQLTokenizer.LONGNVARCHAR),    Utils.getShort(SQLTokenizer.getSQLDataType( SQLTokenizer.LONGNVARCHAR) ),    Utils.getInteger(2147483647),	"'",  "'",  null, 		 		Utils.getShort(typeNullable), Boolean.FALSE, Utils.getShort(typeSearchable), null, 			Boolean.FALSE, Boolean.FALSE, null, null, 				 null, 				  null, null, null},
{SQLTokenizer.getKeyWord(SQLTokenizer.CHAR),         	 Utils.getShort(SQLTokenizer.getSQLDataType( SQLTokenizer.CHAR) ),         	  Utils.getInteger(65535),   	"'",  "'",  "length", 			Utils.getShort(typeNullable), Boolean.FALSE, Utils.getShort(typeSearchable), null, 			Boolean.FALSE, Boolean.FALSE, null, null, 				 null, 				  null, null, null},
{SQLTokenizer.getKeyWord(SQLTokenizer.NCHAR),         	 Utils.getShort(SQLTokenizer.getSQLDataType( SQLTokenizer.NCHAR) ),           Utils.getInteger(65535),   	"'",  "'",  "length", 			Utils.getShort(typeNullable), Boolean.FALSE, Utils.getShort(typeSearchable), null, 			Boolean.FALSE, Boolean.FALSE, null, null, 				 null, 				  null, null, null},
{SQLTokenizer.getKeyWord(SQLTokenizer.NUMERIC),         Utils.getShort(SQLTokenizer.getSQLDataType( SQLTokenizer.NUMERIC) ),         Utils.getInteger(38),     	null, null, "precision,scale", 	Utils.getShort(typeNullable), Boolean.FALSE, Utils.getShort(typeSearchable), Boolean.FALSE, Boolean.FALSE, Boolean.FALSE, null, Utils.getInteger(0), Utils.getInteger(38),null, null, null},
{SQLTokenizer.getKeyWord(SQLTokenizer.DECIMAL),         Utils.getShort(SQLTokenizer.getSQLDataType( SQLTokenizer.DECIMAL) ),         Utils.getInteger(38),     	null, null, "precision,scale", 	Utils.getShort(typeNullable), Boolean.FALSE, Utils.getShort(typeSearchable), Boolean.FALSE, Boolean.FALSE, Boolean.FALSE, null, Utils.getInteger(0), Utils.getInteger(38),null, null, null},
{SQLTokenizer.getKeyWord(SQLTokenizer.MONEY),           Utils.getShort(SQLTokenizer.getSQLDataType( SQLTokenizer.MONEY) ),           Utils.getInteger(19),     	null, null, null, 				Utils.getShort(typeNullable), Boolean.FALSE, Utils.getShort(typeSearchable), Boolean.FALSE, Boolean.FALSE, Boolean.FALSE, null, Utils.getInteger(4), Utils.getInteger(4), null, null, null},
{SQLTokenizer.getKeyWord(SQLTokenizer.SMALLMONEY),      Utils.getShort(SQLTokenizer.getSQLDataType( SQLTokenizer.SMALLMONEY) ),      Utils.getInteger(10),     	null, null, null, 				Utils.getShort(typeNullable), Boolean.FALSE, Utils.getShort(typeSearchable), Boolean.FALSE, Boolean.FALSE, Boolean.FALSE, null, Utils.getInteger(4), Utils.getInteger(4), null, null, null},
{SQLTokenizer.getKeyWord(SQLTokenizer.INT),             Utils.getShort(SQLTokenizer.getSQLDataType( SQLTokenizer.INT) ),             Utils.getInteger(10),     	null, null, null, 				Utils.getShort(typeNullable), Boolean.FALSE, Utils.getShort(typeSearchable), Boolean.FALSE, Boolean.FALSE, Boolean.FALSE, null, Utils.getInteger(0), Utils.getInteger(0), null, null, null},
{SQLTokenizer.getKeyWord(SQLTokenizer.SMALLINT),        Utils.getShort(SQLTokenizer.getSQLDataType( SQLTokenizer.SMALLINT) ),        Utils.getInteger(5),      	null, null, null, 				Utils.getShort(typeNullable), Boolean.FALSE, Utils.getShort(typeSearchable), Boolean.FALSE, Boolean.FALSE, Boolean.FALSE, null, Utils.getInteger(0), Utils.getInteger(0), null, null, null},
{SQLTokenizer.getKeyWord(SQLTokenizer.FLOAT),        	 Utils.getShort(SQLTokenizer.getSQLDataType( SQLTokenizer.FLOAT) ),           Utils.getInteger(15),      	null, null, null, 				Utils.getShort(typeNullable), Boolean.FALSE, Utils.getShort(typeSearchable), Boolean.FALSE, Boolean.FALSE, Boolean.FALSE, null, Utils.getInteger(0), Utils.getInteger(0), null, null, null},
{SQLTokenizer.getKeyWord(SQLTokenizer.REAL),        	 Utils.getShort(SQLTokenizer.getSQLDataType( SQLTokenizer.REAL) ),        	  Utils.getInteger(7),      	null, null, null, 				Utils.getShort(typeNullable), Boolean.FALSE, Utils.getShort(typeSearchable), Boolean.FALSE, Boolean.FALSE, Boolean.FALSE, null, Utils.getInteger(0), Utils.getInteger(0), null, null, null},
{SQLTokenizer.getKeyWord(SQLTokenizer.DOUBLE),          Utils.getShort(SQLTokenizer.getSQLDataType( SQLTokenizer.DOUBLE) ),          Utils.getInteger(15),      	null, null, null, 				Utils.getShort(typeNullable), Boolean.FALSE, Utils.getShort(typeSearchable), Boolean.FALSE, Boolean.FALSE, Boolean.FALSE, null, Utils.getInteger(0), Utils.getInteger(0), null, null, null},
{SQLTokenizer.getKeyWord(SQLTokenizer.VARCHAR),         Utils.getShort(SQLTokenizer.getSQLDataType( SQLTokenizer.VARCHAR) ),         Utils.getInteger(65535),   	"'",  "'",  "max length", 		Utils.getShort(typeNullable), Boolean.FALSE, Utils.getShort(typeSearchable), null, 			Boolean.FALSE, Boolean.FALSE, null, null, 				 null, 				  null, null, null},
{SQLTokenizer.getKeyWord(SQLTokenizer.NVARCHAR),        Utils.getShort(SQLTokenizer.getSQLDataType( SQLTokenizer.NVARCHAR) ),        Utils.getInteger(65535),   	"'",  "'",  "max length", 		Utils.getShort(typeNullable), Boolean.FALSE, Utils.getShort(typeSearchable), null, 			Boolean.FALSE, Boolean.FALSE, null, null, 				 null, 				  null, null, null},
{SQLTokenizer.getKeyWord(SQLTokenizer.BOOLEAN),         Utils.getShort(SQLTokenizer.getSQLDataType( SQLTokenizer.BOOLEAN) ),         Utils.getInteger(1),      	null, null, null, 				Utils.getShort(typeNullable), Boolean.FALSE, Utils.getShort(typeSearchable), null,          Boolean.FALSE, Boolean.FALSE, null, Utils.getInteger(0), Utils.getInteger(0), null, null, null},
{SQLTokenizer.getKeyWord(SQLTokenizer.DATE),   	 	 Utils.getShort(SQLTokenizer.getSQLDataType( SQLTokenizer.DATE) ), 	  		  Utils.getInteger(10),	    	"'",  "'",  null, 				Utils.getShort(typeNullable), Boolean.FALSE, Utils.getShort(typeSearchable), null, 			Boolean.FALSE, Boolean.FALSE, null, null, 				 null, 				  null, null, null},
{SQLTokenizer.getKeyWord(SQLTokenizer.TIME),   	 	 Utils.getShort(SQLTokenizer.getSQLDataType( SQLTokenizer.TIME) ), 	  		  Utils.getInteger(8),	    	"'",  "'",  null, 				Utils.getShort(typeNullable), Boolean.FALSE, Utils.getShort(typeSearchable), null, 			Boolean.FALSE, Boolean.FALSE, null, null, 				 null, 				  null, null, null},
{SQLTokenizer.getKeyWord(SQLTokenizer.TIMESTAMP),   	 Utils.getShort(SQLTokenizer.getSQLDataType( SQLTokenizer.TIMESTAMP) ), 	  Utils.getInteger(23),	    	"'",  "'",  null, 				Utils.getShort(typeNullable), Boolean.FALSE, Utils.getShort(typeSearchable), null, 			Boolean.FALSE, Boolean.FALSE, null, Utils.getInteger(3), Utils.getInteger(3), null, null, null},
{SQLTokenizer.getKeyWord(SQLTokenizer.SMALLDATETIME),   Utils.getShort(SQLTokenizer.getSQLDataType( SQLTokenizer.SMALLDATETIME) ),   Utils.getInteger(16),	    	"'",  "'",  null, 				Utils.getShort(typeNullable), Boolean.FALSE, Utils.getShort(typeSearchable), null, 			Boolean.FALSE, Boolean.FALSE, null, null, 				 null, 				  null, null, null},
{SQLTokenizer.getKeyWord(SQLTokenizer.JAVA_OBJECT),   	 Utils.getShort(SQLTokenizer.getSQLDataType( SQLTokenizer.JAVA_OBJECT) ),     Utils.getInteger(65535),	    null, null, null, 				Utils.getShort(typeNullable), Boolean.FALSE, Utils.getShort(typeSearchable), null, 			Boolean.FALSE, Boolean.FALSE, null, null, 				 null, 				  null, null, null},
{SQLTokenizer.getKeyWord(SQLTokenizer.BLOB),   		 Utils.getShort(SQLTokenizer.getSQLDataType( SQLTokenizer.BLOB) ),   		  Utils.getInteger(2147483647),	"0x", null, null, 		 		Utils.getShort(typeNullable), Boolean.FALSE, Utils.getShort(typeSearchable), null, 			Boolean.FALSE, Boolean.FALSE, null, null, 				 null, 				  null, null, null},
{SQLTokenizer.getKeyWord(SQLTokenizer.CLOB),     		 Utils.getShort(SQLTokenizer.getSQLDataType( SQLTokenizer.CLOB) ),     		  Utils.getInteger(2147483647),	"'",  "'",  null, 		 		Utils.getShort(typeNullable), Boolean.FALSE, Utils.getShort(typeSearchable), null, 			Boolean.FALSE, Boolean.FALSE, null, null, 				 null, 				  null, null, null},
{SQLTokenizer.getKeyWord(SQLTokenizer.NCLOB),     		 Utils.getShort(SQLTokenizer.getSQLDataType( SQLTokenizer.NCLOB) ),     	  Utils.getInteger(2147483647),	"'",  "'",  null, 		 		Utils.getShort(typeNullable), Boolean.FALSE, Utils.getShort(typeSearchable), null, 			Boolean.FALSE, Boolean.FALSE, null, null, 				 null, 				  null, null, null},
};
return new SSResultSet( st, Utils.createMemoryCommandSelect( con, colNames, data));return getCrossReference( null, null, table, null, null, null );return getDriverMajorVersion() + "." + SSDriver.drv.getMinorVersion();switch(level){
case Connection.TRANSACTION_NONE:
case Connection.TRANSACTION_READ_UNCOMMITTED:
case Connection.TRANSACTION_READ_COMMITTED:
case Connection.TRANSACTION_REPEATABLE_READ:
case Connection.TRANSACTION_SERIALIZABLE:
return true;
}
return false;return "owner";return sqlStateSQL99;return 0;return 0;return 0;return 0;return 0;return 0;return 0;return 0;return 0;return 0;return 0;return 0;return 0;return 0;return 0;return 0;return false;throw new java.lang.UnsupportedOperationException("Method getAttributes() not yet implemented.");return false;return false;return false;return con;return false;return getFunctions(SQLTokenizer.ABS, SQLTokenizer.TRUNCATE);String[] colNames = {"TABLE_CAT", "TABLE_SCHEM", "TABLE_NAME", "GRANTOR", "GRANTEE", "PRIVILEGE", "IS_GRANTABLE"};
throw new java.lang.UnsupportedOperationException("Method getTablePrivileges() not yet implemented.");return supportsResultSetType(type);return supportsResultSetType(type);Database database = con.getDatabase(true);
if(database == null)
return SSDriver.URL_PREFIX;
return SSDriver.URL_PREFIX + ':' + database.getName();try {
String[] colNames = {"TABLE_CAT", "TABLE_SCHEM", "TABLE_NAME", "COLUMN_NAME", "KEY_SEQ", "PK_NAME"};
Object[][] data   = con.getDatabase(false).getPrimaryKeys(con, table);
return new SSResultSet( st, Utils.createMemoryCommandSelect( con, colNames, data));
} catch (Exception e) {
throw SmallSQLException.createFromException(e);
}return supportsResultSetType(type);return supportsResultSetType(type);return supportsResultSetType(type);return supportsResultSetType(type);return supportsResultSetType(type);return supportsResultSetType(type);throw new java.lang.UnsupportedOperationException("Method supportsAlterTableWithDropColumn() not yet implemented.");throw new java.lang.UnsupportedOperationException("Method supportsAlterTableWithAddColumn() not yet implemented.");return SSDriver.drv.getMinorVersion();String[] colNames = {"TABLE_CAT","TABLE_SCHEM","TABLE_NAME","TABLE_TYPE","REMARKS","TYPE_CAT","TYPE_SCHEM","TYPE_NAME","SELF_REFERENCING_COL_NAME","REF_GENERATION"};
Database database;
if(catalog == null){
database = con.getDatabase(true);
if(database != null)
catalog = database.getName();
}else{
database = Database.getDatabase(catalog, con, false);
}
ArrayList rows = new ArrayList();
boolean isTypeTable = types == null;
boolean isTypeView = types == null;
for(int i=0; types != null && i<types.length; i++){
if("TABLE".equalsIgnoreCase(types[i])) isTypeTable = true;
if("VIEW" .equalsIgnoreCase(types[i])) isTypeView  = true;
}
if(database != null){
Strings tables = database.getTables(tableNamePattern);
for(int i=0; i<tables.size(); i++){
String table = tables.get(i);
Object[] row = new Object[10];
row[0] = catalog;
row[2] = table;
try{
if(database.getTableView( con, table) instanceof View){
if(isTypeView){
row[3] = "VIEW";
rows.add(row);
}
}else{
if(isTypeTable){
row[3] = "TABLE";
rows.add(row);
}
}
}catch(Exception e){
}
}
}
Object[][] data = new Object[rows.size()][];
rows.toArray(data);
CommandSelect cmdSelect = Utils.createMemoryCommandSelect( con, colNames, data);
Expressions order = new Expressions();
order.add( new ExpressionName("TABLE_TYPE") );
order.add( new ExpressionName("TABLE_NAME") );
cmdSelect.setOrder( order );
return new SSResultSet( st, cmdSelect);return getFunctions(SQLTokenizer.IFNULL, SQLTokenizer.IIF);return getDriverMajorVersion();return getDriverVersion();return 255;return 255;return 255;return 255;return 255;return ".";try {
String[] colNames = {"PKTABLE_CAT", "PKTABLE_SCHEM", "PKTABLE_NAME", "PKCOLUMN_NAME", "FKTABLE_CAT", "FKTABLE_SCHEM", "FKTABLE_NAME", "FKCOLUMN_NAME", "KEY_SEQ", "UPDATE_RULE", "DELETE_RULE", "FK_NAME", "PK_NAME", "DEFERRABILITY"};
Object[][] data   = con.getDatabase(false).getReferenceKeys(con, primaryTable, foreignTable);
return new SSResultSet( st, Utils.createMemoryCommandSelect( con, colNames, data));
} catch (Exception e) {
throw SmallSQLException.createFromException(e);
}return true;return true;return true;return true;return true;return true;return true;return true;return true;return true;return true;return true;return true;return true;return true;return true;return true;return true;return true;return true;return true;return true;return true;return true;return true;return true;return true;return true;return true;return true;return true;return true;return true;return true;return true;return true;return true;return true;return true;if(type >= ResultSet.TYPE_FORWARD_ONLY && type <= ResultSet.TYPE_SCROLL_SENSITIVE &&
concurrency >= ResultSet.CONCUR_READ_ONLY && concurrency <= ResultSet.CONCUR_UPDATABLE)
return true;
return false;String[] colNames = {"TABLE_TYPE"};
Object[][] data   = {{"SYSTEM TABLE"}, {"TABLE"}, {"VIEW"}};
return new SSResultSet( st, Utils.createMemoryCommandSelect( con, colNames, data));return false;throw new java.lang.UnsupportedOperationException("Method getSuperTables() not yet implemented.");throw new java.lang.UnsupportedOperationException("Method getSuperTypes() not yet implemented.");String[] colNames = {"PROCEDURE_CAT", "PROCEDURE_SCHEM", "PROCEDURE_NAME", "COLUMN_NAME", "COLUMN_TYPE", "DATA_TYPE", "TYPE_NAME", "PRECISION", "LENGTH", "SCALE", "RADIX", "NULLABLE", "REMARKS" };
Object[][] data   = new Object[0][];
return new SSResultSet( st, Utils.createMemoryCommandSelect( con, colNames, data));String[] colNames = {"TABLE_CAT", "TABLE_SCHEM", "TABLE_NAME", "COLUMN_NAME", "GRANTOR", "GRANTEE", "PRIVILEGE", "IS_GRANTABLE"};
throw new java.lang.UnsupportedOperationException("Method getColumnPrivileges() not yet implemented.");return "#$ÀÁÂÃÄÅÆÇÈÉÊËÌÍÎÏÐÑÒÓÔÕÖØÙÚÛÜÝÞßàáâãäåæçèéêëìíîïðñòóôõöøùúûüýþÿ";try {
String[] colNames = {"SCOPE", "COLUMN_NAME", "DATA_TYPE", "TYPE_NAME", "COLUMN_SIZE", "BUFFER_LENGTH", "DECIMAL_DIGITS", "PSEUDO_COLUMN"};
Object[][] data   = new Object[0][0];
return new SSResultSet( st, Utils.createMemoryCommandSelect( con, colNames, data));
} catch (Exception e) {
throw SmallSQLException.createFromException(e);
}return "SmallSQL Driver";return getDriverMinorVersion();return true;return true;return true;return true;return true;return true;return true;return true;return true;return true;return true;return true;return true;return true;return true;return true;return true;return true;return true;return true;if(!acceptsURL(url)){
return null;
}
return new SSConnection(parse(url, info));Properties props = parse(url, info);
DriverPropertyInfo[] driverInfos = new DriverPropertyInfo[1];
driverInfos[0] = new DriverPropertyInfo("dbpath", props.getProperty("dbpath"));
return driverInfos;return 21;Properties props = (Properties)info.clone();
if(!acceptsURL(url)){
return props;
}
int idx1 = url.indexOf(':', 5);
int idx2 = url.indexOf('?');
if(idx1 > 0){
String dbPath = (idx2 > 0) ? url.substring(idx1 + 1, idx2) : url.substring(idx1 + 1);
props.setProperty("dbpath", dbPath);
}
if(idx2 > 0){
String propsString = url.substring(idx2 + 1).replace('&', ';');
StringTokenizer tok = new StringTokenizer(propsString, ";");
while(tok.hasMoreTokens()){
String keyValue = tok.nextToken().trim();
if(keyValue.length() > 0){
idx1 = keyValue.indexOf('=');
if(idx1 > 0){
String key = keyValue.substring(0, idx1).toLowerCase().trim();
String value = keyValue.substring(idx1 + 1).trim();
props.put(key, value);
}else{
throw SmallSQLException.create(Language.CUSTOM_MESSAGE, "Missing equal in property:" + keyValue);
}
}
}
}
return props;return 0;return url.startsWith(URL_PREFIX);checkStatement();
cmd.setParamValue( parameterIndex, new Integer(x), SQLTokenizer.TINYINT);checkStatement();
cmd.setParamValue( parameterIndex, x, SQLTokenizer.LONGVARCHAR, length);checkStatement();
cmd.setParamValue( parameterIndex, DateTime.valueOf(x), SQLTokenizer.DATE);checkStatement();
cmd.setParamValue( parameterIndex, x, SQLTokenizer.BINARY);checkStatement();
if(cmd instanceof CommandSelect){
try{
((CommandSelect)cmd).compile(con);
SSResultSetMetaData metaData = new SSResultSetMetaData();
metaData.columns = cmd.columnExpressions;
return metaData;
}catch(Exception e){
throw SmallSQLException.createFromException(e);
}
}
return null;checkStatement();
cmd.setParamValue( parameterIndex, new Float(x), SQLTokenizer.REAL);checkStatement();
cmd.setParamValue( parameterIndex, x, SQLTokenizer.LONGVARBINARY, length);checkStatement();
cmd.verifyParams();
if(getMaxRows() != 0 && (top == -1 || top > getMaxRows()))
cmd.setMaxRows(getMaxRows());
cmd.execute( con, this);checkStatement();
cmd.setParamValue( parameterIndex, new Integer(x), SQLTokenizer.INT);checkStatement();
cmd.setParamValue( parameterIndex, DateTime.valueOf(x), SQLTokenizer.TIMESTAMP);executeImp();
return cmd.getQueryResult();checkStatement();
cmd.setParamValue( parameterIndex, x ? Boolean.TRUE : Boolean.FALSE, SQLTokenizer.BOOLEAN);checkStatement();
cmd.setParamValue( parameterIndex, new Integer(x), SQLTokenizer.SMALLINT);checkStatement();
throw new java.lang.UnsupportedOperationException("Method getParameterMetaData() not yet implemented.");checkStatement();
cmd.setParamValue( parameterIndex, x, -1);checkStatement();
throw new java.lang.UnsupportedOperationException("Method setRef() not yet implemented.");checkStatement();
throw new java.lang.UnsupportedOperationException("Method setBlob() not yet implemented.");checkStatement();
throw new java.lang.UnsupportedOperationException("Method setArray() not yet implemented.");checkStatement();
cmd.setParamValue( parameterIndex, DateTime.valueOf(x), SQLTokenizer.TIME);checkStatement();
cmd.setParamValue( parameterIndex, x, -1);checkStatement();
cmd.setParamValue( parameterIndex, x, SQLTokenizer.VARCHAR);checkStatement();
cmd.setParamValue( parameterIndex, new Double(x), SQLTokenizer.DOUBLE);checkStatement();
cmd.setParamValue( parameterIndex, null, SQLTokenizer.NULL);checkStatement();
cmd.clearParams();checkStatement();
if(batches != null) batches.clear();executeImp();
return cmd.getUpdateCount();checkStatement();
throw new java.lang.UnsupportedOperationException("Method setClob() not yet implemented.");checkStatement();
throw new java.lang.UnsupportedOperationException("Method setURL() not yet implemented.");checkStatement();
throw new java.lang.UnsupportedOperationException("Method setCharacterStream() not yet implemented.");checkStatement();
throw new java.lang.UnsupportedOperationException("Method setUnicodeStream() not yet implemented.");checkStatement();
throw new java.lang.UnsupportedOperationException("Method setTimestamp() not yet implemented.");checkStatement();
throw new java.lang.UnsupportedOperationException("Method setNull() not yet implemented.");checkStatement();
throw new java.lang.UnsupportedOperationException("Method setTime() not yet implemented.");executeImp();
return cmd.getResultSet() != null;checkStatement();
throw new java.lang.UnsupportedOperationException("Method setDate() not yet implemented.");checkStatement();
cmd.setParamValue( parameterIndex, x, -1);checkStatement();
cmd.setParamValue( parameterIndex, x, SQLTokenizer.DECIMAL);if(batches == null || batches.size() == 0) return new int[0];
int[] result = new int[batches.size()];
BatchUpdateException failed = null;
for(int b=0; b<batches.size(); b++){
try{
checkStatement();
ExpressionValue[] values = (ExpressionValue[])batches.get(b);
for(int i=0; i<values.length; i++){
((ExpressionValue)cmd.params.get(i)).set( values[i] );
}
result[b] = executeUpdate();
} catch (SQLException ex) {
result[b] = EXECUTE_FAILED;
if(failed == null){
failed = new BatchUpdateException(ex.getMessage(), ex.getSQLState(), ex.getErrorCode(), result);
failed.initCause(ex);
}
failed.setNextException(ex);
}
}
batches.clear();
if(failed != null)
throw failed;
return result;checkStatement();
cmd.setParamValue( parameterIndex, new Long(x), SQLTokenizer.BIGINT);checkStatement();
try{
final Expressions params = cmd.params;
final int size = params.size();
ExpressionValue[] values = new ExpressionValue[size];
for(int i=0; i<size; i++){
values[i] = (ExpressionValue)params.get(i).clone();
}
if(batches == null) batches = new ArrayList();
batches.add(values);
}catch(Exception e){
throw SmallSQLException.createFromException(e);
}updateBoolean( findColumn( columnName ), x );try{
MutableNumeric obj = getValue(columnIndex).getNumeric();
wasNull = obj == null;
if(wasNull) return null;
return obj.toBigDecimal(scale);
}catch(Exception e){
throw SmallSQLException.createFromException( e );
}return false;updateInt( findColumn( columnName ), x );try{
if(cal == null){
return getTimestamp(columnIndex);
}
Expression expr = getValue(columnIndex);
wasNull = expr.isNull();
if(wasNull) return null;
return new Timestamp(DateTime.addDateTimeOffset( expr.getLong(), cal.getTimeZone() ));
}catch(Exception e){
throw SmallSQLException.createFromException( e );
}try{
if(cal == null){
return getTime(columnIndex);
}
Expression expr = getValue(columnIndex);
wasNull = expr.isNull();
if(wasNull) return null;
return new Time(DateTime.addDateTimeOffset( expr.getLong(), cal.getTimeZone() ));
}catch(Exception e){
throw SmallSQLException.createFromException( e );
}updateClob( findColumn( columnName ), x );updateValue( columnIndex, null, SQLTokenizer.NULL);try{
if(cal == null){
return getDate(columnIndex);
}
Expression expr = getValue(columnIndex);
wasNull = expr.isNull();
if(wasNull) return null;
return new Date(DateTime.addDateTimeOffset( expr.getLong(), cal.getTimeZone() ));
}catch(Exception e){
throw SmallSQLException.createFromException( e );
}try{
Expression expr = getValue(columnIndex);
wasNull = expr.isNull();
return expr.getBoolean();
}catch(Exception e){
throw SmallSQLException.createFromException( e );
}return fetchSize;try{
return getCmd().isAfterLast();
}catch(Exception e){
throw SmallSQLException.createFromException(e);
}return getString( findColumn( columnName ) );return getClob( findColumn( columnName ) );return getShort( findColumn( columnName ) );updateBytes( findColumn( columnName ), x );return getRef( findColumn( columnName ) );return getBytes( findColumn( columnName ) );updateTimestamp( findColumn( columnName ), x );updateValue( columnIndex, x, SQLTokenizer.DECIMAL);try{
moveToCurrentRow();
return getCmd().next();
}catch(Exception e){
throw SmallSQLException.createFromException(e);
}updateValue( columnIndex, x, SQLTokenizer.LONGVARBINARY, length);if(cmd == null){
throw SmallSQLException.create(Language.RSET_CLOSED);
}
st.con.testClosedConnection();
return cmd;return null;return getTimestamp( findColumn( columnName ), cal );try{
Object obj = getValue(columnIndex).getApiObject();
wasNull = obj == null;
return obj;
}catch(Exception e){
throw SmallSQLException.createFromException( e );
}updateTime( findColumn( columnName ), x );throw SmallSQLException.create(Language.UNSUPPORTED_OPERATION, "getAsciiStream");return null;throw SmallSQLException.create(Language.UNSUPPORTED_OPERATION, "getUnicodeStream");return getBigDecimal( findColumn( columnName ), scale );throw SmallSQLException.create(Language.UNSUPPORTED_OPERATION, "getCharacterStream");fetchDirection = direction;try {
if(values == null){
return;
}
st.con.log.println("updateRow()");
testNotInsertRow();
final CommandSelect command = getCmd();
command.updateRow( st.con, values);
command.relative(0);
clearRowBuffer();
} catch (Exception e) {
throw SmallSQLException.createFromException(e);
}try{
Expression expr = getValue(columnIndex);
wasNull = expr.isNull();
return expr.getDouble();
}catch(Exception e){
throw SmallSQLException.createFromException( e );
}try{
Expression expr = getValue(columnIndex);
wasNull = expr.isNull();
return expr.getFloat();
}catch(Exception e){
throw SmallSQLException.createFromException( e );
}return metaData;try{
Expression expr = getValue(columnIndex);
wasNull = expr.isNull();
return expr.getLong();
}catch(Exception e){
throw SmallSQLException.createFromException( e );
}return getCmd().from.isScrollable() ? ResultSet.TYPE_SCROLL_SENSITIVE : ResultSet.TYPE_FORWARD_ONLY;return isUpdatable ? ResultSet.CONCUR_UPDATABLE : ResultSet.CONCUR_READ_ONLY;return getTime( findColumn( columnName ), cal );testNotInsertRow();
clearRowBuffer();try{
moveToCurrentRow();
return getCmd().relative(rows);
}catch(Exception e){
throw SmallSQLException.createFromException(e);
}return fetchDirection;return getDate( findColumn( columnName ), cal );try{
moveToCurrentRow();
return getCmd().previous();
}catch(Exception e){
throw SmallSQLException.createFromException(e);
}return getObject( findColumn( columnName ) );updateValue( columnIndex, Utils.getShort(x), SQLTokenizer.TINYINT);updateShort( findColumn( columnName ), x );getUpdateValue( columnIndex ).set( x, dataType, length );
if(st.con.log.isLogging()){
st.con.log.println("parameter '"+metaData.getColumnName(columnIndex)+"' = "+x+"; type="+dataType+"; length="+length);
}updateByte( findColumn( columnName ), x );updateValue( columnIndex, x, -1);try{
moveToCurrentRow();
getCmd().beforeFirst();
}catch(Exception e){
throw SmallSQLException.createFromException(e);
}return wasNull;if(isInsertRow){
throw SmallSQLException.create(Language.RSET_ON_INSERT_ROW);
}try{
if(st.rsType == ResultSet.TYPE_FORWARD_ONLY) throw SmallSQLException.create(Language.RSET_FWDONLY);
moveToCurrentRow();
getCmd().afterLast();
}catch(Exception e){
throw SmallSQLException.createFromException(e);
}return getInt( findColumn( columnName ) );try{
byte[] obj = getValue(columnIndex).getBytes();
wasNull = obj == null;
return obj;
}catch(Exception e){
throw SmallSQLException.createFromException( e );
}testNotInsertRow();
relative(0);updateObject( findColumn( columnName ), x );throw SmallSQLException.create(Language.UNSUPPORTED_OPERATION, "Array");throw SmallSQLException.create(Language.UNSUPPORTED_OPERATION, "Array");updateArray( findColumn( columnName ), x );return (byte)getInt( columnIndex );throw SmallSQLException.create(Language.UNSUPPORTED_OPERATION, "Reader object");return getCmd().from.rowInserted();updateFloat( findColumn( columnName ), x );try{
Expression expr = getValue(columnIndex);
wasNull = expr.isNull();
if(wasNull) return null;
return DateTime.getTime( expr.getLong() );
}catch(Exception e){
throw SmallSQLException.createFromException( e );
}return st;updateValue( columnIndex, Utils.getShort(x), SQLTokenizer.SMALLINT);throw SmallSQLException.create(Language.UNSUPPORTED_OPERATION, "Blob");return getCmd().isFirst();updateValue( columnIndex, x ? Boolean.TRUE : Boolean.FALSE, SQLTokenizer.BOOLEAN);return getCmd().isBeforeFirst();updateLong( findColumn( columnName ), x );return getTimestamp( findColumn( columnName ) );try{
Expression expr = getValue(columnIndex);
wasNull = expr.isNull();
return expr.getInt();
}catch(Exception e){
throw SmallSQLException.createFromException( e );
}updateValue( columnIndex, new Double(x), SQLTokenizer.DOUBLE);try{
if(st.rsType == ResultSet.TYPE_FORWARD_ONLY) throw SmallSQLException.create(Language.RSET_FWDONLY);
moveToCurrentRow();
return getCmd().first();
}catch(Exception e){
throw SmallSQLException.createFromException(e);
}updateValue( columnIndex, DateTime.valueOf(x), SQLTokenizer.TIMESTAMP);try{
Object obj = getObject(columnIndex);
if(obj instanceof String || obj == null){
return (String)obj;
}
if(obj instanceof byte[]){
return "0x" + Utils.bytes2hex( (byte[])obj );
}
return getValue(columnIndex).getString();
}catch(Exception e){
throw SmallSQLException.createFromException( e );
}try{
return getCmd().isLast();
}catch(Exception e){
throw SmallSQLException.createFromException(e);
}st.con.log.println("insertRow()");
if(!isInsertRow){
throw SmallSQLException.create(Language.RSET_NOT_INSERT_ROW);
}
getCmd().insertRow( st.con, values);
clearRowBuffer();try{
Expression expr = getValue(columnIndex);
wasNull = expr.isNull();
if(wasNull) return null;
return DateTime.getTimestamp( expr.getLong() );
}catch(Exception e){
throw SmallSQLException.createFromException( e );
}try{
moveToCurrentRow();
return getCmd().last();
}catch(Exception e){
throw SmallSQLException.createFromException(e);
}updateValue( columnIndex, x, SQLTokenizer.LONGVARCHAR, length);updateValue( columnIndex, DateTime.valueOf(x), SQLTokenizer.TIME);try{
return getCmd().getRow();
}catch(Exception e){
throw SmallSQLException.createFromException(e);
}updateValue( columnIndex, x, SQLTokenizer.VARCHAR);updateValue( columnIndex, new Float(x), SQLTokenizer.REAL);if(values == null){
int count = metaData.getColumnCount();
values = new ExpressionValue[count];
while(count-- > 0){
values[count] = new ExpressionValue();
}
}
return values[ metaData.getColumnIdx( columnIndex ) ];try{
moveToCurrentRow();
return getCmd().absolute(row);
}catch(Exception e){
throw SmallSQLException.createFromException(e);
}return getTime( findColumn( columnName ) );return getCmd().findColumn(columnName) + 1;return getBigDecimal( findColumn( columnName ) );if(isUpdatable){
isInsertRow = true;
clearRowBuffer();
}else{
throw SmallSQLException.create(Language.RSET_READONLY);
}return getDate( findColumn( columnName ) );updateNull( findColumn( columnName ) );updateBigDecimal( findColumn( columnName ), x );updateValue( columnIndex, new Long(x), SQLTokenizer.BIGINT);return getCmd().from.rowDeleted();throw SmallSQLException.create(Language.UNSUPPORTED_OPERATION, "Ref");updateValue( columnIndex, DateTime.valueOf(x), SQLTokenizer.DATE);getUpdateValue( columnIndex ).set( x, dataType );
if(st.con.log.isLogging()){
st.con.log.println("parameter '"+metaData.getColumnName(columnIndex)+"' = "+x+"; type="+dataType);
}isInsertRow = false;
clearRowBuffer();
if(values == null){
getUpdateValue(1);
}updateString( findColumn( columnName ), x );updateBlob( findColumn( columnName ), x );return (short)getInt( columnIndex );updateRef( findColumn( columnName ), x );updateCharacterStream( findColumn( columnName ), x, length );updateDate( findColumn( columnName ), x );st.con.log.println("ResultSet.close");
cmd = null;return new ByteArrayInputStream(getBytes(columnIndex));updateBinaryStream( findColumn( columnName ), x, length );updateAsciiStream( findColumn( columnName ), x, length );return getObject( columnName );try{
MutableNumeric obj = getValue(columnIndex).getNumeric();
wasNull = obj == null;
if(wasNull) return null;
return obj.toBigDecimal();
}catch(Exception e){
throw SmallSQLException.createFromException( e );
}return getURL( findColumn( columnName ) );return getBlob( findColumn( columnName ) );return getBoolean( findColumn( columnName ) );throw SmallSQLException.create(Language.UNSUPPORTED_OPERATION, "Clob");return getObject( i );return getArray( findColumn( columnName ) );try{
Expression expr = getValue(columnIndex);
wasNull = expr.isNull();
if(wasNull) return null;
return new URL( expr.getString() );
}catch(Exception e){
throw SmallSQLException.createFromException( e );
}updateValue( columnIndex, x, SQLTokenizer.VARBINARY);updateObject( findColumn( columnName ), x, scale );updateValue( columnIndex, Utils.getInteger(x), SQLTokenizer.INT);return getAsciiStream( findColumn( columnName ) );try{
Expression expr = getValue(columnIndex);
wasNull = expr.isNull();
if(wasNull) return null;
return DateTime.getDate( expr.getLong() );
}catch(Exception e){
throw SmallSQLException.createFromException( e );
}st.con.log.println("deleteRow()");
testNotInsertRow();
getCmd().deleteRow(st.con);
clearRowBuffer();updateDouble( findColumn( columnName ), x );return getCharacterStream( findColumn( columnName ) );if(values != null){
ExpressionValue value = values[ metaData.getColumnIdx( columnIndex ) ];
if(!value.isEmpty() || isInsertRow){
return value;
}
}
return metaData.getColumnExpression(columnIndex);fetchSize = rows;return getBinaryStream( findColumn( columnName ) );return getUnicodeStream( findColumn( columnName ) );updateValue( columnIndex, x, -1);throw SmallSQLException.create(Language.UNSUPPORTED_OPERATION, "Clob object");throw SmallSQLException.create(Language.UNSUPPORTED_OPERATION, "Ref object");throw SmallSQLException.create(Language.UNSUPPORTED_OPERATION, "Blob object");return getDouble( findColumn( columnName ) );return getFloat( findColumn( columnName ) );if(values != null){
for(int i=values.length-1; i>=0; i--){
values[i].clear();
}
}return getByte( findColumn( columnName ) );return getLong( findColumn( columnName ) );switch(getColumnType(column)){
case Types.TINYINT:
case Types.SMALLINT:
case Types.INTEGER:
return "java.lang.Integer";
case Types.BIT:
case Types.BOOLEAN:
return "java.lang.Boolean";
case Types.BINARY:
case Types.VARBINARY:
case Types.LONGVARBINARY:
return "[B";
case Types.BLOB:
return "java.sql.Blob";
case Types.BIGINT:
return "java.lang.Long";
case Types.DECIMAL:
case Types.NUMERIC:
return "java.math.BigDecimal";
case Types.REAL:
return "java.lang.Float";
case Types.FLOAT:
case Types.DOUBLE:
return "java.lang.Double";
case Types.DATE:
return "java.sql.Date";
case Types.TIME:
return "java.sql.Time";
case Types.TIMESTAMP:
return "java.sql.Timestamp";
case Types.CHAR:
case Types.VARCHAR:
case Types.LONGVARCHAR:
case -11:
return "java.lang.String";
case Types.CLOB:
return "java.sql.Clob";
default: return "java.lang.Object";
}return SQLTokenizer.getKeyWord( getColumnExpression( column ).getDataType() );return columns.get( getColumnIdx( column ) );switch(dataType){
case SQLTokenizer.SMALLINT:
case SQLTokenizer.INT:
case SQLTokenizer.BIGINT:
case SQLTokenizer.SMALLMONEY:
case SQLTokenizer.MONEY:
case SQLTokenizer.DECIMAL:
case SQLTokenizer.NUMERIC:
case SQLTokenizer.REAL:
case SQLTokenizer.FLOAT:
case SQLTokenizer.DOUBLE:
return true;
}
return false;switch(getColumnExpression( column ).getDataType()){
case SQLTokenizer.MONEY:
case SQLTokenizer.SMALLMONEY:
return true;
}
return false;switch(dataType){
case SQLTokenizer.NULL:
return 0;
case SQLTokenizer.BIT:
case SQLTokenizer.BOOLEAN:
return 1;
case SQLTokenizer.TINYINT:
return 3;
case SQLTokenizer.SMALLINT:
return 5;
case SQLTokenizer.INT:
case SQLTokenizer.SMALLMONEY:
return 10;
case SQLTokenizer.BIGINT:
case SQLTokenizer.MONEY:
return 19;
case SQLTokenizer.REAL:
return 7;
case SQLTokenizer.FLOAT:
case SQLTokenizer.DOUBLE:
return 15;
case SQLTokenizer.CHAR:
case SQLTokenizer.NCHAR:
case SQLTokenizer.VARCHAR:
case SQLTokenizer.NVARCHAR:
case SQLTokenizer.BINARY:
case SQLTokenizer.VARBINARY:
if(defaultValue == -1)
return 0xFFFF;
return defaultValue;
case SQLTokenizer.NUMERIC:
case SQLTokenizer.DECIMAL:
if(defaultValue == -1)
return 38;
return defaultValue;
case SQLTokenizer.TIMESTAMP:
return 23;
case SQLTokenizer.TIME:
return 8;
case SQLTokenizer.DATE:
return 10;
case SQLTokenizer.SMALLDATETIME:
return 16;
case SQLTokenizer.UNIQUEIDENTIFIER:
return 36;
case SQLTokenizer.LONGVARCHAR:
case SQLTokenizer.LONGNVARCHAR:
case SQLTokenizer.LONGVARBINARY:
return Integer.MAX_VALUE;
}
if(defaultValue == -1)
throw new Error("Precision:"+SQLTokenizer.getKeyWord(dataType));
return defaultValue;return getColumnExpression( column ).getPrecision();switch(dataType){
case SQLTokenizer.BINARY:
case SQLTokenizer.VARBINARY:
case SQLTokenizer.LONGVARBINARY:
case SQLTokenizer.BLOB:
return true;
}
return false;return getColumnExpression( column ).isAutoIncrement();return getColumnExpression( column ).isNullable() ? columnNullable : columnNoNulls;switch(dataType){
case SQLTokenizer.BIT:
return 1;
case SQLTokenizer.BOOLEAN:
return 5;
case SQLTokenizer.TINYINT:
return 3;
case SQLTokenizer.SMALLINT:
return 6;
case SQLTokenizer.INT:
return 10;
case SQLTokenizer.BIGINT:
case SQLTokenizer.MONEY:
return 19;
case SQLTokenizer.REAL:
return 13;
case SQLTokenizer.FLOAT:
case SQLTokenizer.DOUBLE:
return 17;
case SQLTokenizer.LONGVARCHAR:
case SQLTokenizer.LONGNVARCHAR:
case SQLTokenizer.LONGVARBINARY:
case SQLTokenizer.JAVA_OBJECT:
case SQLTokenizer.BLOB:
case SQLTokenizer.CLOB:
case SQLTokenizer.NCLOB:
return Integer.MAX_VALUE;
case SQLTokenizer.NUMERIC:
return precision + (scale>0 ? 2 : 1);
case SQLTokenizer.VARBINARY:
case SQLTokenizer.BINARY:
return 2 + precision*2;
case SQLTokenizer.SMALLDATETIME:
return 21;
default:
return precision;
}return !getColumnExpression( column ).isDefinitelyWritable();return SQLTokenizer.getSQLDataType(getColumnExpression( column ).getDataType() );if(column < 1 || column > columns.size())
throw SmallSQLException.create( Language.COL_IDX_OUT_RANGE, String.valueOf(column));
return column-1;return getColumnExpression( column ).getTableName();return isSignedDataType(getColumnExpression( column ).getDataType());return getColumnExpression( column ).getScale();return getColumnExpression( column ).isCaseSensitive();return getColumnExpression( column ).isDefinitelyWritable();return getColumnExpression( column ).isDefinitelyWritable();return null;return null;int type = getColumnExpression( column ).getType();
return type == Expression.NAME || type == Expression.FUNCTION;return isSignedDataType(dataType) || dataType == SQLTokenizer.TINYINT;return getColumnExpression( column ).getAlias();return getColumnExpression( column ).getAlias();return getColumnExpression( column ).getDisplaySize();return columns.size();return name;return id;checkStatement();
fetchDirection = direction;checkStatement();setNeedGeneratedKeys(columnNames);
return execute(sql);checkStatement();
return rsType;return needGeneratedKeys;throw SmallSQLException.create(Language.UNSUPPORTED_OPERATION, "setCursorName");setNeedGeneratedKeys(columnIndexes);
return executeUpdate(sql);checkStatement();
generatedKeys = null;
try{
con.log.println(sql);
SQLParser parser = new SQLParser();
cmd = parser.parse(con, sql);
if(maxRows != 0 && (cmd.getMaxRows() == -1 || cmd.getMaxRows() > maxRows))
cmd.setMaxRows(maxRows);
cmd.execute(con, this);
}catch(Exception e){
throw SmallSQLException.createFromException(e);
}
needGeneratedKeys = false;
generatedKeyIndexes = null;
generatedKeyNames = null;executeImpl(sql);
return cmd.getQueryResult();return generatedKeyNames;return maxRows;checkStatement();
return fetchDirection;setNeedGeneratedKeys(columnIndexes);
return execute(sql);setNeedGeneratedKeys(autoGeneratedKeys);
return execute(sql);return null;checkStatement();
if(batches == null)
return;
batches.clear();return maxFieldSize;if(isClosed){
throw SmallSQLException.create(Language.STMT_IS_CLOSED);
}throw new java.lang.UnsupportedOperationException("Method getResultSetHoldability() not yet implemented.");return con;checkStatement();
queryTimeout = seconds;switch(autoGeneratedKeys){
case NO_GENERATED_KEYS:
break;
case RETURN_GENERATED_KEYS:
needGeneratedKeys = true;
break;
default:
throw SmallSQLException.create(Language.ARGUMENT_INVALID, String.valueOf(autoGeneratedKeys));
}if(generatedKeys == null)
throw SmallSQLException.create(Language.GENER_KEYS_UNREQUIRED);
return generatedKeys;checkStatement();
return fetchSize;return generatedKeyIndexes;checkStatement();
return queryTimeout;needGeneratedKeys = columnNames != null;
generatedKeyNames = columnNames;if(batches == null)
return new int[0];
final int[] result = new int[batches.size()];
BatchUpdateException failed = null;
for(int i = 0; i < result.length; i++){
try{
result[i] = executeUpdate((String)batches.get(i));
}catch(SQLException ex){
result[i] = EXECUTE_FAILED;
if(failed == null){
failed = new BatchUpdateException(ex.getMessage(), ex.getSQLState(), ex.getErrorCode(), result);
failed.initCause(ex);
}
failed.setNextException(ex);
}
}
batches.clear();
if(failed != null)
throw failed;
return result;checkStatement();
return rsConcurrency;switch(current){
case CLOSE_ALL_RESULTS:
case CLOSE_CURRENT_RESULT:
ResultSet rs = cmd.getResultSet();
cmd.rs = null;
if(rs != null)
rs.close();
break;
case KEEP_CURRENT_RESULT:
break;
default:
throw SmallSQLException.create(Language.FLAGVALUE_INVALID, String.valueOf(current));
}
return cmd.getMoreResults();executeImpl(sql);
return cmd.getResultSet() != null;maxFieldSize = max;needGeneratedKeys = columnIndexes != null;
generatedKeyIndexes = columnIndexes;if(batches == null)
batches = new ArrayList();
batches.add(sql);setNeedGeneratedKeys(autoGeneratedKeys);
return executeUpdate(sql);checkStatement();checkStatement();
fetchSize = rows;checkStatement();
return cmd.getResultSet();setNeedGeneratedKeys(columnNames);
return executeUpdate(sql);generatedKeys = rs;checkStatement();
return cmd.getUpdateCount();if(max < 0)
throw SmallSQLException.create(Language.ROWS_WRONG_MAX, String.valueOf(max));
maxRows = max;con.log.println("Statement.close");
isClosed = true;
cmd = null;executeImpl(sql);
return cmd.getUpdateCount();checkStatement();
return getMoreResults(CLOSE_CURRENT_RESULT);return rowIdx == 0 && rowList.size()>0;return rowIdx;rowIdx = -1;
rowSource.beforeFirst();rowSource.noRow();
rowIdx = -1;if(rowIdx >= rowList.size()) return true;
if(isBeforeFirst() && rowList.size() == 0){
next();
previous();
if(rowList.size() == 0) return true;
}
return false;rowIdx = (int)rowPosition;return rowSource.rowDeleted();if(rowIdx+1 != rowList.size()){
return false;
}
boolean isNext = next();
previous();
return !isNext && (rowIdx+1 == rowList.size() && rowList.size()>0);rowSource.nullRow();
rowIdx = -1;return rowSource.rowInserted();if(rowIdx > -1){
rowIdx--;
if(rowIdx > -1 && rowIdx < rowList.size()){
rowSource.setRowPosition( rowList.get(rowIdx) );
return true;
}
}
rowSource.beforeFirst();
return false;return true;rowSource.execute();
rowList.clear();
rowIdx = -1;if(row == 0)
throw SmallSQLException.create(Language.ROW_0_ABSOLUTE);
if(row < 0){
afterLast();
rowIdx = rowList.size() + row;
if(rowIdx < 0){
beforeFirst();
return false;
}else{
rowSource.setRowPosition( rowList.get(rowIdx) );
return true;
}
}
if(row <= rowList.size()){
rowIdx = row-1;
rowSource.setRowPosition( rowList.get(rowIdx) );
return true;
}
rowIdx = rowList.size()-1;
if(rowIdx >= 0)
rowSource.setRowPosition( rowList.get(rowIdx) );
boolean result;
while((result = next()) && row-1 > rowIdx){}
return result;if(rowIdx+1 < rowList.size()){
rowIdx = rowList.size()-1;
rowSource.setRowPosition( rowList.get(rowIdx) );
}
while(next()){}if(rowIdx >= rowList.size()) return 0;
return rowIdx + 1;int newRow = rows + rowIdx + 1;
if(newRow <= 0){
beforeFirst();
return false;
}else{
return absolute(newRow);
}if(++rowIdx < rowList.size()){
rowSource.setRowPosition( rowList.get(rowIdx) );
return true;
}
final boolean result = rowSource.next();
if(result){
rowList.add( rowSource.getRowPosition());
return true;
}
rowIdx = rowList.size();
return false;return rowIdx == -1 || rowList.size() == 0;return rowSource.isExpressionsFromThisRowSource(columns);rowIdx = -1;
return next();afterLast();
return previous();if(!isInit) return;
super.printStackTrace(ps);if(!isInit) return;
super.printStackTrace(pw);if(!isInit) return;
super.printStackTrace();String message = translateMsg(messageCode, new Object[] { param0 });
String sqlState = language.getSqlState(messageCode);
return new SmallSQLException(e, message, sqlState);String message = translateMsg(messageCode, params);
String sqlState = language.getSqlState(messageCode);
return new SmallSQLException(message, sqlState);if(e instanceof SQLException) {
return (SQLException)e;
}
else {
String message = stripMsg(e);
String sqlState = language.getSqlState(Language.CUSTOM_MESSAGE);
return new SmallSQLException(e, message, sqlState);
}this.isInit = true;
PrintWriter pw = DriverManager.getLogWriter();
if(pw != null) this.printStackTrace(pw);assert (messageCode != null): "Fill parameters";
String message = translateMsg(messageCode, null);
String sqlState = language.getSqlState(messageCode);
return new SmallSQLException(message, sqlState);assert ( messageCode != null && params != null ): "Fill parameters. msgCode=" + messageCode + " params=" + params;
String localized = language.getMessage(messageCode);
return MessageFormat.format(localized, params);String message = translateMsg(messageCode, new Object[] { param0 });
String sqlState = language.getSqlState(messageCode);
return new SmallSQLException(message, sqlState);String msg = throwable.getMessage();
if(msg == null || msg.length() < 30){
String msg2 = throwable.getClass().getName();
msg2 = msg2.substring(msg2.lastIndexOf('.')+1);
if(msg != null)
msg2 = msg2 + ':' + msg;
return msg2;
}
return throwable.getMessage();if (language != null && localeObj == null) return;
if (localeObj == null) {
language = Language.getDefaultLanguage();
}
else {
language = Language.getLanguage(localeObj.toString());
}return true;int rowCount = getRowCount();
return row > rowCount || rowCount == 0;beforeFirst();
return next();useSetRowPosition = false;
if(sortedRowCount > 0){
scrollStatus.afterLast();
scrollStatus.getRowOffset(false);
}else{
rowSource.beforeFirst();
}
row = sortedRowCount;
while(next()){
}return rowSource.getRowPosition();rowSource.nullRow();
row = 0;return row > getRowCount() ? 0 : row;return rowSource.isExpressionsFromThisRowSource(columns);afterLast();
return previous();if(useSetRowPosition) throw SmallSQLException.create(Language.ORDERBY_INTERNAL);
if(currentInsertedRow() == 0){
scrollStatus.afterLast();
}
row--;
if(currentInsertedRow() >= 0){
rowSource.setRowPosition( insertedRows.get( currentInsertedRow() ) );
return true;
}
long rowPosition = scrollStatus.getRowOffset(false);
if(rowPosition >= 0){
rowSource.setRowPosition( rowPosition );
return true;
}else{
rowSource.noRow();
row = 0;
return false;
}return rowSource.rowDeleted();return rowSource.rowInserted();return row - sortedRowCount - 1;return row == 1;if(rows == 0) return (row != 0);
if(rows > 0){
while(rows-- > 0){
if(!next()){
return false;
}
}
}else{
while(rows++ < 0){
if(!previous()){
return false;
}
}
}
return true;if(row == 0){
return false;
}
if(row > getRowCount()){
return false;
}
boolean isNext = next();
previous();
return !isNext;if(useSetRowPosition) throw SmallSQLException.create(Language.ORDERBY_INTERNAL);
if(currentInsertedRow() < 0){
long rowPosition = scrollStatus.getRowOffset(true);
if(rowPosition >= 0){
row++;
rowSource.setRowPosition( rowPosition );
return true;
}
}
if(currentInsertedRow() < insertedRows.size()-1){
row++;
rowSource.setRowPosition( insertedRows.get( currentInsertedRow() ) );
return true;
}
if(lastRowOffset >= 0){
rowSource.setRowPosition( lastRowOffset );
}else{
rowSource.beforeFirst();
}
if(rowSource.next()){
row++;
lastRowOffset = rowSource.getRowPosition();
insertedRows.add( lastRowOffset );
return true;
}
rowSource.noRow();
row = (getRowCount() > 0) ? getRowCount() + 1 : 0;
return false;if(newRow == 0) throw SmallSQLException.create(Language.ROW_0_ABSOLUTE);
if(newRow > 0){
beforeFirst();
while(newRow-- > 0){
if(!next()){
return false;
}
}
}else{
afterLast();
while(newRow++ < 0){
if(!previous()){
return false;
}
}
}
return true;rowSource.execute();
Index index = new Index(false);
lastRowOffset = -1;
while(rowSource.next()){
lastRowOffset = rowSource.getRowPosition();
index.addValues( lastRowOffset, orderBy);
sortedRowCount++;
}
scrollStatus = index.createScrollStatus(orderBy);
useSetRowPosition = false;rowSource.setRowPosition(rowPosition);
useSetRowPosition = true;return sortedRowCount + insertedRows.size();scrollStatus.reset();
row = 0;
useSetRowPosition = false;return row == 0;rowSource.noRow();
row = 0;return false;long lobFilePos = readLong();
StoreImpl store = table.getLobStore( ((TableStorePage)storePage).con, lobFilePos, SQLTokenizer.SELECT );
return store.readBytes( store.readInt() );return ((TableStorePageInsert)storePage).getLink();this.offset = valueOffset;
if(readBoolean()) return 0;
switch(dataType){
case SQLTokenizer.BIT:
case SQLTokenizer.BOOLEAN:
return readBoolean() ? 10000 : 0;
case SQLTokenizer.BINARY:
case SQLTokenizer.VARBINARY:
return (long)(Utils.bytes2double( readBinary() ) * 10000L);
case SQLTokenizer.TINYINT:
return readUnsignedByte() * 10000L;
case SQLTokenizer.SMALLINT:
return readShort() * 10000L;
case SQLTokenizer.INT:
return readInt() * 10000L;
case SQLTokenizer.BIGINT:
return readLong() * 10000L;
case SQLTokenizer.REAL:
return (long)(readFloat() * 10000L);
case SQLTokenizer.FLOAT:
case SQLTokenizer.DOUBLE:
return (long)(readDouble() * 10000L);
case SQLTokenizer.MONEY:
return readLong();
case SQLTokenizer.SMALLMONEY:
return readInt();
case SQLTokenizer.NUMERIC:
case SQLTokenizer.DECIMAL:
return (long)(readNumeric().doubleValue() * 10000L);
case SQLTokenizer.CHAR:
case SQLTokenizer.NCHAR:
case SQLTokenizer.VARCHAR:
case SQLTokenizer.NVARCHAR:
return Money.parseMoney( readString() );
case SQLTokenizer.CLOB:
case SQLTokenizer.NCLOB:
case SQLTokenizer.LONGNVARCHAR:
case SQLTokenizer.LONGVARCHAR:
return Money.parseMoney( readLongString() );
case SQLTokenizer.JAVA_OBJECT:
ByteArrayInputStream bais = new ByteArrayInputStream(readLongBinary());
ObjectInputStream ois = new ObjectInputStream(bais);
return Money.parseMoney( ois.readObject().toString() );
case SQLTokenizer.LONGVARBINARY:
case SQLTokenizer.BLOB:
return (long)(Utils.bytes2double( readLongBinary() ) * 10000L);
case SQLTokenizer.TIMESTAMP:
case SQLTokenizer.TIME:
case SQLTokenizer.DATE:
case SQLTokenizer.SMALLDATETIME:
throw SmallSQLException.create(Language.VALUE_CANT_CONVERT, new Object[] { SQLTokenizer.getKeyWord(dataType), "MONEY" });
default: throw new Error();
}System.arraycopy( store.page, valueOffset, this.page, this.offset, length);
this.offset += length;return sizeUsed;writeInt( (int)(datetime / 60000));this.offset = valueOffset;
if(readBoolean()) return 0;
switch(dataType){
case SQLTokenizer.BIT:
case SQLTokenizer.BOOLEAN:
return readBoolean() ? 1 : 0;
case SQLTokenizer.BINARY:
case SQLTokenizer.VARBINARY:
return Utils.bytes2long( readBinary() );
case SQLTokenizer.TINYINT:
return readUnsignedByte();
case SQLTokenizer.SMALLINT:
return readShort();
case SQLTokenizer.INT:
return readInt();
case SQLTokenizer.BIGINT:
return readLong();
case SQLTokenizer.REAL:
return (long)readFloat();
case SQLTokenizer.FLOAT:
case SQLTokenizer.DOUBLE:
return (long)readDouble();
case SQLTokenizer.MONEY:
return readLong() / 10000;
case SQLTokenizer.SMALLMONEY:
return readInt() / 10000;
case SQLTokenizer.NUMERIC:
case SQLTokenizer.DECIMAL:
return readNumeric().longValue();
case SQLTokenizer.CHAR:
case SQLTokenizer.NCHAR:
case SQLTokenizer.VARCHAR:
case SQLTokenizer.NVARCHAR:
return Long.parseLong( readString() );
case SQLTokenizer.CLOB:
case SQLTokenizer.NCLOB:
case SQLTokenizer.LONGNVARCHAR:
case SQLTokenizer.LONGVARCHAR:
return Long.parseLong( readLongString() );
case SQLTokenizer.JAVA_OBJECT:
ByteArrayInputStream bais = new ByteArrayInputStream(readLongBinary());
ObjectInputStream ois = new ObjectInputStream(bais);
return ExpressionValue.getLong( ois.readObject().toString(), SQLTokenizer.VARCHAR );
case SQLTokenizer.LONGVARBINARY:
case SQLTokenizer.BLOB:
return Utils.bytes2long( readLongBinary() );
case SQLTokenizer.TIMESTAMP:
return readTimestamp();
case SQLTokenizer.TIME:
return readTime();
case SQLTokenizer.DATE:
return readDate();
case SQLTokenizer.SMALLDATETIME:
return readSmallDateTime();
default:
throw SmallSQLException.create(Language.VALUE_CANT_CONVERT, new Object[] { SQLTokenizer.getKeyWord(dataType), "BIGINT" });
}if(status != UPDATE_POINTER) return this;
StoreImpl storeTemp = table.getStore( ((TableStorePage)storePage).con, filePosUpdated, type);
storeTemp.updatePointer = this;
return storeTemp;byte[] daten = new byte[length];
System.arraycopy( page, offset, daten, 0, length);
offset += length;
return daten;return (page[ offset++ ] << 8) | (page[ offset++ ] & 0xFF);type = SQLTokenizer.UPDATE;
if(newData.offset <= sizePhysical || filePos == -1){
page = newData.page;
offset = newData.offset;
if(sizePhysical < offset) sizePhysical = offset;
writeFinsh(con);
}else{
newData.status = UPDATED_PAGE;
if(updatePointer == null){
((TableStorePage)newData.storePage).lockType = TableView.LOCK_INSERT;
filePosUpdated = newData.writeFinsh(null);
status = UPDATE_POINTER;
}else{
((TableStorePage)newData.storePage).lockType = TableView.LOCK_INSERT;
updatePointer.filePosUpdated = newData.writeFinsh(null);
updatePointer.status = UPDATE_POINTER;
updatePointer.type = SQLTokenizer.UPDATE;
updatePointer.createWriteLock();
if(updatePointer.sharedPageData){
updatePointer.page = new byte[PAGE_CONTROL_SIZE];
}
updatePointer.writeFinsh(con);
status = DELETED;
if(sharedPageData){
page = new byte[PAGE_CONTROL_SIZE];
}
}
writeFinsh(con);
}char[] chars = daten.toCharArray();
StoreImpl store = table.getLobStore( ((TableStorePage)storePage).con, chars.length * 2L + 4, SQLTokenizer.LONGVARBINARY);
store.writeInt( chars.length );
store.writeChars( chars );
writeLong( store.writeFinsh(null) );int[] value = new int[ readByte() ];
int scale   = readByte();
int signum  = readByte();
for(int i=0; i<value.length; i++){
value[i] = readInt();
}
return new MutableNumeric( signum, value, scale );writeInt( (int)(date / 86400000));return  ((page[ offset++ ]) << 24) |
((page[ offset++ ] & 0xFF) << 16) |
((page[ offset++ ] & 0xFF) << 8) |
((page[ offset++ ] & 0xFF));writeString( strDaten, Short.MAX_VALUE, true );return Float.intBitsToFloat( readInt() );char[] daten = new char[length];
for(int i=0; i<length; i++){
daten[i] = (char)((page[ offset++ ] & 0xFF) | (page[ offset++ ] << 8));
}
return daten;int length = daten.length;
if(lengthColumn < length){
Object params = new Object[] { new Integer(length), new Integer(lengthColumn) };
throw SmallSQLException.create(Language.VALUE_BIN_TOOLARGE, params);
}
if(varBinary) lengthColumn = length;
int newSize = offset + 2 + lengthColumn;
if(newSize > page.length) resizePage(newSize);
page[ offset++ ] = (byte)(lengthColumn >> 8);
page[ offset++ ] = (byte)(lengthColumn);
writeBytes( daten );
if(!varBinary){
for(int i=length; i<lengthColumn; i++){
page[ offset++ ] = 0;
}
}return page[ offset++ ] != 0;TableStorePage storePageWrite = table.requestWriteLock( ((TableStorePage)storePage).con, (TableStorePage)storePage );
if(storePageWrite == null)
throw SmallSQLException.create(Language.ROW_LOCKED);
storePage = storePageWrite;StoreImpl store = new StoreImpl(table, storePage, type, -1);
store.page = storePage.page;
store.sharedPageData = true;
store.readPageHeader();
store = store.loadUpdatedStore();
store.offset = PAGE_CONTROL_SIZE;
return store;this.offset = newOffset;char[] daten = strDaten.toCharArray();
int length = daten.length;
if(lengthColumn < length){
throw SmallSQLException.create(Language.VALUE_STR_TOOLARGE);
}
if(varchar) lengthColumn = length;
int newSize = offset + 2 + 2*lengthColumn;
if(newSize > page.length) resizePage(newSize);
writeShort( lengthColumn );
writeChars( daten );
for(int i=length; i<lengthColumn; i++){
page[ offset++ ] = ' ';
page[ offset++ ] = 0;
}long lobFilePos = readLong();
StoreImpl store = table.getLobStore( ((TableStorePage)storePage).con, lobFilePos, SQLTokenizer.SELECT );
if(store == null) throw SmallSQLException.create(Language.LOB_DELETED);
return new String(store.readChars( store.readInt() ) );int length = readShort() & 0xFFFF;
return new String( readChars(length) );return status == NORMAL || (status == UPDATED_PAGE && updatePointer != null);return readInt() * 86400000L;int length = daten.length;
int newSize = offset + 2*length;
if(newSize > page.length) resizePage(newSize );
for(int i=0; i<length; i++){
char c = daten[i];
page[ offset++ ] = (byte)(c);
page[ offset++ ] = (byte)(c >> 8);
}return readInt() * 60000L;return page[ offset++ ] & 0xFF;int length = readShort() & 0xFFFF;
return readBytes(length);this.offset = valueOffset;
if(readBoolean()) return 0;
switch(dataType){
case SQLTokenizer.BIT:
case SQLTokenizer.BOOLEAN:
return readBoolean() ? 1 : 0;
case SQLTokenizer.BINARY:
case SQLTokenizer.VARBINARY:
return Utils.bytes2float( readBinary() );
case SQLTokenizer.TINYINT:
return readUnsignedByte();
case SQLTokenizer.SMALLINT:
return readShort();
case SQLTokenizer.INT:
return readInt();
case SQLTokenizer.BIGINT:
return readLong();
case SQLTokenizer.REAL:
return readFloat();
case SQLTokenizer.FLOAT:
case SQLTokenizer.DOUBLE:
return (float)readDouble();
case SQLTokenizer.MONEY:
return readLong() / (float)10000.0;
case SQLTokenizer.SMALLMONEY:
return readInt() / (float)10000.0;
case SQLTokenizer.NUMERIC:
case SQLTokenizer.DECIMAL:
return readNumeric().floatValue();
case SQLTokenizer.CHAR:
case SQLTokenizer.NCHAR:
case SQLTokenizer.VARCHAR:
case SQLTokenizer.NVARCHAR:
return Float.parseFloat( readString() );
case SQLTokenizer.CLOB:
case SQLTokenizer.NCLOB:
case SQLTokenizer.LONGNVARCHAR:
case SQLTokenizer.LONGVARCHAR:
return Float.parseFloat( readLongString() );
case SQLTokenizer.JAVA_OBJECT:
ByteArrayInputStream bais = new ByteArrayInputStream(readLongBinary());
ObjectInputStream ois = new ObjectInputStream(bais);
return Float.parseFloat( ois.readObject().toString() );
case SQLTokenizer.LONGVARBINARY:
case SQLTokenizer.BLOB:
return Utils.bytes2float( readLongBinary() );
case SQLTokenizer.TIMESTAMP:
return readTimestamp();
case SQLTokenizer.TIME:
return readTime();
case SQLTokenizer.DATE:
return readDate();
case SQLTokenizer.SMALLDATETIME:
return readSmallDateTime();
default:
throw SmallSQLException.create(Language.VALUE_CANT_CONVERT, new Object[] { SQLTokenizer.getKeyWord(dataType), "REAL" });
}int newSize = Math.max(minNewSize, page.length*2);
byte[] newPage = new byte[newSize];
System.arraycopy( page, 0, newPage, 0, page.length);
page = newPage;return page[ valueOffset ] != 0;return Double.longBitsToDouble( readLong() );if(updatePointer != null) return updatePointer.getNextPagePos();
if(nextPageOffset <= 0){
nextPageOffset = sizePhysical;
}
return filePos + nextPageOffset;return offset;StoreImpl store = table.getLobStore( ((TableStorePage)storePage).con, daten.length + 4, SQLTokenizer.LONGVARBINARY);
store.writeInt( daten.length );
store.writeBytes( daten );
writeLong( store.writeFinsh(null) );writeLong( Double.doubleToLongBits(value) );int newSize = offset + daten.length;
if(newSize > page.length) resizePage(newSize );
System.arraycopy( daten, 0, page, offset, daten.length);
offset += daten.length;this.offset = valueOffset;
if(readBoolean()) return null;
switch(dataType){
case SQLTokenizer.BINARY:
case SQLTokenizer.VARBINARY:
return readBinary();
case SQLTokenizer.TINYINT:
case SQLTokenizer.BIT:
case SQLTokenizer.BOOLEAN:
byte[] bytes = new byte[1];
System.arraycopy( page, valueOffset, bytes, 0, bytes.length);
return bytes;
case SQLTokenizer.SMALLINT:
bytes = new byte[2];
System.arraycopy( page, valueOffset, bytes, 0, bytes.length);
return bytes;
case SQLTokenizer.INT:
case SQLTokenizer.REAL:
case SQLTokenizer.SMALLMONEY:
case SQLTokenizer.TIME:
case SQLTokenizer.DATE:
case SQLTokenizer.SMALLDATETIME:
bytes = new byte[4];
System.arraycopy( page, valueOffset, bytes, 0, bytes.length);
return bytes;
case SQLTokenizer.BIGINT:
case SQLTokenizer.FLOAT:
case SQLTokenizer.DOUBLE:
case SQLTokenizer.MONEY:
case SQLTokenizer.TIMESTAMP:
bytes = new byte[8];
System.arraycopy( page, valueOffset, bytes, 0, bytes.length);
return bytes;
case SQLTokenizer.NUMERIC:
case SQLTokenizer.DECIMAL:
return readNumeric().toByteArray();
case SQLTokenizer.CHAR:
case SQLTokenizer.NCHAR:
case SQLTokenizer.VARCHAR:
case SQLTokenizer.NVARCHAR:
return readString().getBytes();
case SQLTokenizer.CLOB:
case SQLTokenizer.NCLOB:
case SQLTokenizer.LONGNVARCHAR:
case SQLTokenizer.LONGVARCHAR:
return readLongString().getBytes();
case SQLTokenizer.JAVA_OBJECT:
case SQLTokenizer.LONGVARBINARY:
case SQLTokenizer.BLOB:
return readLongBinary();
case SQLTokenizer.UNIQUEIDENTIFIER:
bytes = new byte[16];
System.arraycopy( page, valueOffset, bytes, 0, bytes.length);
return bytes;
default: throw new Error();
}writeInt( (int)((time / 1000) % 86400) );return readInt() * 1000L;this.offset = valueOffset;
if(readBoolean()) return 0;
switch(dataType){
case SQLTokenizer.BIT:
case SQLTokenizer.BOOLEAN:
return readBoolean() ? 1 : 0;
case SQLTokenizer.BINARY:
case SQLTokenizer.VARBINARY:
return Utils.bytes2int( readBinary() );
case SQLTokenizer.TINYINT:
return readUnsignedByte();
case SQLTokenizer.SMALLINT:
return readShort();
case SQLTokenizer.INT:
return readInt();
case SQLTokenizer.BIGINT:
return (int)readLong();
case SQLTokenizer.REAL:
return (int)readFloat();
case SQLTokenizer.FLOAT:
case SQLTokenizer.DOUBLE:
return (int)readDouble();
case SQLTokenizer.MONEY:
long longValue = readLong() / 10000;
return Utils.money2int(longValue);
case SQLTokenizer.SMALLMONEY:
return readInt() / 10000;
case SQLTokenizer.NUMERIC:
case SQLTokenizer.DECIMAL:
return readNumeric().intValue();
case SQLTokenizer.CHAR:
case SQLTokenizer.NCHAR:
case SQLTokenizer.VARCHAR:
case SQLTokenizer.NVARCHAR:
return Integer.parseInt( readString() );
case SQLTokenizer.CLOB:
case SQLTokenizer.NCLOB:
case SQLTokenizer.LONGNVARCHAR:
case SQLTokenizer.LONGVARCHAR:
return Integer.parseInt( readLongString() );
case SQLTokenizer.JAVA_OBJECT:
ByteArrayInputStream bais = new ByteArrayInputStream(readLongBinary());
ObjectInputStream ois = new ObjectInputStream(bais);
return ExpressionValue.getInt(ois.readObject().toString(), SQLTokenizer.VARCHAR);
case SQLTokenizer.LONGVARBINARY:
case SQLTokenizer.BLOB:
return Utils.bytes2int( readLongBinary() );
case SQLTokenizer.TIMESTAMP:
return (int)readTimestamp();
case SQLTokenizer.TIME:
return (int)readTime();
case SQLTokenizer.DATE:
return (int)readDate();
case SQLTokenizer.SMALLDATETIME:
return (int)readSmallDateTime();
default:
throw SmallSQLException.create(Language.VALUE_CANT_CONVERT, new Object[] { SQLTokenizer.getKeyWord(dataType), "INT" });
}this.offset = valueOffset;
if(readBoolean()) return 0;
switch(dataType){
case SQLTokenizer.BIT:
case SQLTokenizer.BOOLEAN:
return readBoolean() ? 1 : 0;
case SQLTokenizer.BINARY:
case SQLTokenizer.VARBINARY:
return Utils.bytes2double( readBinary() );
case SQLTokenizer.TINYINT:
return readUnsignedByte();
case SQLTokenizer.SMALLINT:
return readShort();
case SQLTokenizer.INT:
return readInt();
case SQLTokenizer.BIGINT:
return readLong();
case SQLTokenizer.REAL:
return readFloat();
case SQLTokenizer.FLOAT:
case SQLTokenizer.DOUBLE:
return readDouble();
case SQLTokenizer.MONEY:
return readLong() / 10000.0;
case SQLTokenizer.SMALLMONEY:
return readInt() / 10000.0;
case SQLTokenizer.NUMERIC:
case SQLTokenizer.DECIMAL:
return readNumeric().doubleValue();
case SQLTokenizer.CHAR:
case SQLTokenizer.NCHAR:
case SQLTokenizer.VARCHAR:
case SQLTokenizer.NVARCHAR:
return Double.parseDouble( readString() );
case SQLTokenizer.CLOB:
case SQLTokenizer.NCLOB:
case SQLTokenizer.LONGNVARCHAR:
case SQLTokenizer.LONGVARCHAR:
return Double.parseDouble( readLongString() );
case SQLTokenizer.JAVA_OBJECT:
ByteArrayInputStream bais = new ByteArrayInputStream(readLongBinary());
ObjectInputStream ois = new ObjectInputStream(bais);
return Double.parseDouble( ois.readObject().toString() );
case SQLTokenizer.LONGVARBINARY:
case SQLTokenizer.BLOB:
return Utils.bytes2double( readLongBinary() );
case SQLTokenizer.TIMESTAMP:
return readTimestamp();
case SQLTokenizer.TIME:
return readTime();
case SQLTokenizer.DATE:
return readDate();
case SQLTokenizer.SMALLDATETIME:
return readSmallDateTime();
default:
throw SmallSQLException.create(Language.VALUE_CANT_CONVERT, new Object[] { SQLTokenizer.getKeyWord(dataType), "NUMERIC" });
}switch(type){
case SQLTokenizer.LONGVARBINARY:
case SQLTokenizer.INSERT:
case SQLTokenizer.CREATE:
sizeUsed = sizePhysical = offset;
break;
case SQLTokenizer.UPDATE:
if(status != UPDATE_POINTER) {
sizeUsed = offset;
break;
}
case SQLTokenizer.DELETE:
sizeUsed = PAGE_CONTROL_SIZE;
break;
default: throw new Error(""+type);
}
offset = 0;
writeInt( PAGE_MAGIC );
writeInt( status);
writeInt( sizeUsed );
writeInt( sizePhysical );
writeInt( 0 );
writeLong( filePosUpdated );
storePage.setPageData( page, sizeUsed );
if(con == null){
return storePage.commit();
}else{
return 0;
}int newSize = offset + 25;
if(newSize > page.length) resizePage(newSize);
writeByte   ( column.getFlag() );
writeString ( column.getName() );
writeShort  ( column.getDataType() );
writeInt    ( column.getPrecision() );
writeByte   ( column.getScale() );
offset += column.initAutoIncrement(storePage.raFile, filePos+offset);
String def = column.getDefaultDefinition();
writeBoolean( def == null );
if(def != null)
writeString ( column.getDefaultDefinition() );return readLong();this.offset = valueOffset;
if(readBoolean()) return false;
switch(dataType){
case SQLTokenizer.BIT:
case SQLTokenizer.BOOLEAN:
return readBoolean();
case SQLTokenizer.BINARY:
case SQLTokenizer.VARBINARY:
return Utils.bytes2int( readBinary() ) != 0;
case SQLTokenizer.TINYINT:
return readUnsignedByte() != 0;
case SQLTokenizer.SMALLINT:
return readShort() != 0;
case SQLTokenizer.INT:
return readInt() != 0;
case SQLTokenizer.BIGINT:
return readLong() != 0;
case SQLTokenizer.REAL:
return readFloat() != 0;
case SQLTokenizer.FLOAT:
case SQLTokenizer.DOUBLE:
return readDouble() != 0;
case SQLTokenizer.MONEY:
return readLong() != 0;
case SQLTokenizer.SMALLMONEY:
return readInt() != 0;
case SQLTokenizer.NUMERIC:
case SQLTokenizer.DECIMAL:
return readNumeric().getSignum() != 0;
case SQLTokenizer.CHAR:
case SQLTokenizer.NCHAR:
case SQLTokenizer.VARCHAR:
case SQLTokenizer.NVARCHAR:
return Utils.string2boolean( readString() );
case SQLTokenizer.CLOB:
case SQLTokenizer.NCLOB:
case SQLTokenizer.LONGNVARCHAR:
case SQLTokenizer.LONGVARCHAR:
return Utils.string2boolean( readLongString() );
case SQLTokenizer.JAVA_OBJECT:
ByteArrayInputStream bais = new ByteArrayInputStream(readLongBinary());
ObjectInputStream ois = new ObjectInputStream(bais);
return Utils.string2boolean( ois.readObject().toString() );
case SQLTokenizer.LONGVARBINARY:
case SQLTokenizer.BLOB:
return Utils.bytes2int( readLongBinary() ) != 0;
case SQLTokenizer.TIMESTAMP:
return readTimestamp() != 0;
case SQLTokenizer.TIME:
return readTime() != 0;
case SQLTokenizer.DATE:
return readDate() != 0;
case SQLTokenizer.SMALLDATETIME:
return readSmallDateTime() != 0;
case SQLTokenizer.UNIQUEIDENTIFIER:
return false;
default:
throw SmallSQLException.create(Language.VALUE_CANT_CONVERT, new Object[] { SQLTokenizer.getKeyWord(dataType), "BOOLEAN" });
}int newSize = offset + 2;
if(newSize > page.length) resizePage(newSize);
page[ offset++ ] = (byte)(value >> 8);
page[ offset++ ] = (byte)(value);int newSize = offset + 1;
if(newSize > page.length) resizePage(newSize);
page[ offset++ ] = (byte)(value ? 1 : 0);return  ((long)(page[ offset++ ]) << 56) |
((long)(page[ offset++ ] & 0xFF) << 48) |
((long)(page[ offset++ ] & 0xFF) << 40) |
((long)(page[ offset++ ] & 0xFF) << 32) |
((long)(page[ offset++ ] & 0xFF) << 24) |
((page[ offset++ ] & 0xFF) << 16) |
((page[ offset++ ] & 0xFF) << 8) |
((page[ offset++ ] & 0xFF));int newSize = offset + 8;
if(newSize > page.length) resizePage(newSize);
page[ offset++ ] = (byte)(value >> 56);
page[ offset++ ] = (byte)(value >> 48);
page[ offset++ ] = (byte)(value >> 40);
page[ offset++ ] = (byte)(value >> 32);
page[ offset++ ] = (byte)(value >> 24);
page[ offset++ ] = (byte)(value >> 16);
page[ offset++ ] = (byte)(value >> 8);
page[ offset++ ] = (byte)(value);int newSize = offset + 4;
if(newSize > page.length) resizePage(newSize);
page[ offset++ ] = (byte)(value >> 24);
page[ offset++ ] = (byte)(value >> 16);
page[ offset++ ] = (byte)(value >> 8);
page[ offset++ ] = (byte)(value);try {
StoreImpl store = new StoreImpl(table, storePage, type, filePos);
switch(type){
case SQLTokenizer.LONGVARBINARY:
store.page = new byte[(int)filePos + PAGE_CONTROL_SIZE];
store.filePos = -1;
break;
case SQLTokenizer.INSERT:
case SQLTokenizer.CREATE:
store.page = new byte[DEFAULT_PAGE_SIZE];
break;
case SQLTokenizer.SELECT:
case SQLTokenizer.UPDATE:
case SQLTokenizer.DELETE:
if(storePage.page == null){
FileChannel raFile = storePage.raFile;
synchronized(raFile){
if(filePos >= raFile.size() - PAGE_CONTROL_SIZE){
return null;
}
raFile.position(filePos);
synchronized(page_control){
pageControlBuffer.position(0);
raFile.read(pageControlBuffer);
store.page = page_control;
store.readPageHeader();
}
store.page = new byte[store.sizeUsed];
raFile.position(filePos);
ByteBuffer buffer = ByteBuffer.wrap(store.page);
raFile.read(buffer);
}
}else{
store.page = storePage.page;
store.sharedPageData = true;
store.readPageHeader();
}
store = store.loadUpdatedStore();
break;
default: throw new Error();
}
store.offset = PAGE_CONTROL_SIZE;
return store;
} catch (Throwable th) {
throw SmallSQLException.createFromException(th);
}return page[ offset++ ];writeInt( Float.floatToIntBits(value) );offset = PAGE_CONTROL_SIZE;
for(int i=0; i<offsets.length; i++){
offsets[i] = offset;
boolean isNull = readBoolean();
switch(dataTypes[i]){
case SQLTokenizer.BIT:
case SQLTokenizer.BOOLEAN:
case SQLTokenizer.TINYINT:
offset++;
break;
case SQLTokenizer.SMALLINT:
offset += 2;
break;
case SQLTokenizer.INT:
case SQLTokenizer.REAL:
case SQLTokenizer.SMALLMONEY:
case SQLTokenizer.TIME:
case SQLTokenizer.DATE:
case SQLTokenizer.SMALLDATETIME:
offset += 4;
break;
case SQLTokenizer.BIGINT:
case SQLTokenizer.FLOAT:
case SQLTokenizer.DOUBLE:
case SQLTokenizer.MONEY:
case SQLTokenizer.JAVA_OBJECT:
case SQLTokenizer.LONGVARBINARY:
case SQLTokenizer.BLOB:
case SQLTokenizer.CLOB:
case SQLTokenizer.NCLOB:
case SQLTokenizer.LONGNVARCHAR:
case SQLTokenizer.LONGVARCHAR:
case SQLTokenizer.TIMESTAMP:
offset += 8;
break;
case SQLTokenizer.BINARY:
case SQLTokenizer.VARBINARY:
int count = readShort() & 0xFFFF;
if(!isNull) offset += count;
break;
case SQLTokenizer.NUMERIC:
case SQLTokenizer.DECIMAL:
count = readByte();
offset += 2;
if(!isNull) offset += count*4;
break;
case SQLTokenizer.CHAR:
case SQLTokenizer.NCHAR:
case SQLTokenizer.VARCHAR:
case SQLTokenizer.NVARCHAR:
count = readShort() & 0xFFFF;
if(!isNull) offset += count << 1;
break;
case SQLTokenizer.UNIQUEIDENTIFIER:
offset += 16;
break;
default: throw new Error(String.valueOf( dataTypes[i] ) );
}
}int newSize = offset + length;
if(newSize > page.length) resizePage(newSize );
System.arraycopy( daten, off, page, offset, length);
offset += length;if(readInt() != PAGE_MAGIC){
throw SmallSQLException.create(Language.TABLE_CORRUPT_PAGE, new Object[] { new Long(filePos) });
}
status = readInt();
sizeUsed  = readInt();
sizePhysical = readInt();
nextPageOffset = readInt();
filePosUpdated = readLong();writeLong( ts );Column column = new Column();
column.setFlag( readByte() );
column.setName( readString() );
column.setDataType( readShort() );
int precision;
if(tableFormatVersion == TableView.TABLE_VIEW_OLD_VERSION)
precision = readByte();
else
precision = readInt();
column.setPrecision( precision );
column.setScale( readByte() );
offset += column.initAutoIncrement(storePage.raFile, filePos+offset);
if(!readBoolean()){
String def = readString();
column.setDefaultValue( new SQLParser().parseExpression(def), def);
}
return column;status = DELETED;
type   = SQLTokenizer.DELETE;
createWriteLock();
writeFinsh(con);boolean isNull = expr.isNull();
if(isNull && !column.isNullable()){
throw SmallSQLException.create(Language.VALUE_NULL_INVALID, column.getName());
}
int dataType = column.getDataType();
if(isNull){
writeBoolean(true);
switch(dataType){
case SQLTokenizer.BIT:
case SQLTokenizer.BOOLEAN:
case SQLTokenizer.TINYINT:
offset++;
break;
case SQLTokenizer.SMALLINT:
case SQLTokenizer.BINARY:
case SQLTokenizer.VARBINARY:
case SQLTokenizer.CHAR:
case SQLTokenizer.NCHAR:
case SQLTokenizer.VARCHAR:
case SQLTokenizer.NVARCHAR:
offset += 2;
break;
case SQLTokenizer.INT:
case SQLTokenizer.REAL:
case SQLTokenizer.SMALLMONEY:
case SQLTokenizer.TIME:
case SQLTokenizer.DATE:
case SQLTokenizer.SMALLDATETIME:
offset += 4;
break;
case SQLTokenizer.BIGINT:
case SQLTokenizer.FLOAT:
case SQLTokenizer.DOUBLE:
case SQLTokenizer.MONEY:
case SQLTokenizer.JAVA_OBJECT:
case SQLTokenizer.LONGVARBINARY:
case SQLTokenizer.BLOB:
case SQLTokenizer.CLOB:
case SQLTokenizer.NCLOB:
case SQLTokenizer.LONGNVARCHAR:
case SQLTokenizer.LONGVARCHAR:
case SQLTokenizer.TIMESTAMP:
offset += 8;
break;
case SQLTokenizer.UNIQUEIDENTIFIER:
offset += 16;
break;
case SQLTokenizer.NUMERIC:
case SQLTokenizer.DECIMAL:
offset += 3;
break;
default: throw new Error();
}
return;
}
writeBoolean(false);
column.setNewAutoIncrementValue(expr);
switch(dataType){
case SQLTokenizer.BIT:
case SQLTokenizer.BOOLEAN:
writeBoolean( expr.getBoolean() );
break;
case SQLTokenizer.BINARY:
case SQLTokenizer.VARBINARY:
writeBinary( expr.getBytes(), column.getPrecision(), dataType != SQLTokenizer.BINARY );
break;
case SQLTokenizer.TINYINT:
writeByte( expr.getInt() );
break;
case SQLTokenizer.SMALLINT:
writeShort( expr.getInt() );
break;
case SQLTokenizer.INT:
writeInt( expr.getInt() );
break;
case SQLTokenizer.BIGINT:
writeLong( expr.getLong() );
break;
case SQLTokenizer.REAL:
writeFloat( expr.getFloat() );
break;
case SQLTokenizer.FLOAT:
case SQLTokenizer.DOUBLE:
writeDouble( expr.getDouble() );
break;
case SQLTokenizer.MONEY:
writeLong( expr.getMoney() );
break;
case SQLTokenizer.SMALLMONEY:
writeInt( (int)expr.getMoney() );
break;
case SQLTokenizer.NUMERIC:
case SQLTokenizer.DECIMAL:
MutableNumeric numeric = expr.getNumeric();
numeric.setScale( column.getScale() );
writeNumeric( numeric );
break;
case SQLTokenizer.CHAR:
case SQLTokenizer.NCHAR:
writeString( expr.getString(), column.getDisplaySize(), false );
break;
case SQLTokenizer.VARCHAR:
case SQLTokenizer.NVARCHAR:
writeString( expr.getString(), column.getDisplaySize(), true );
break;
case SQLTokenizer.CLOB:
case SQLTokenizer.NCLOB:
case SQLTokenizer.LONGNVARCHAR:
case SQLTokenizer.LONGVARCHAR:
writeLongString( expr.getString() );
break;
case SQLTokenizer.JAVA_OBJECT:
ByteArrayOutputStream baos = new ByteArrayOutputStream();
ObjectOutputStream oos = new ObjectOutputStream(baos);
oos.writeObject( expr.getObject() );
writeLongBinary( baos.toByteArray() );
break;
case SQLTokenizer.LONGVARBINARY:
case SQLTokenizer.BLOB:
writeLongBinary( expr.getBytes() );
break;
case SQLTokenizer.TIMESTAMP:
writeTimestamp( expr.getLong() );
break;
case SQLTokenizer.TIME:
writeTime( expr.getLong() );
break;
case SQLTokenizer.DATE:
writeDate( expr.getLong() );
break;
case SQLTokenizer.SMALLDATETIME:
writeSmallDateTime( expr.getLong() );
break;
case SQLTokenizer.UNIQUEIDENTIFIER:
switch(expr.getDataType()){
case SQLTokenizer.UNIQUEIDENTIFIER:
case SQLTokenizer.BINARY:
case SQLTokenizer.VARBINARY:
case SQLTokenizer.LONGVARBINARY:
case SQLTokenizer.BLOB:
byte[] bytes = expr.getBytes();
if(bytes.length != 16) throw SmallSQLException.create(Language.BYTEARR_INVALID_SIZE, String.valueOf(bytes.length));
writeBytes( bytes );
default:
writeBytes( Utils.unique2bytes(expr.getString()) );
}
break;
default: throw new Error(String.valueOf(column.getDataType()));
}this.offset = valueOffset;
if(readBoolean()) return null;
switch(dataType){
case SQLTokenizer.BIT:
return readBoolean() ? "1" : "0";
case SQLTokenizer.BOOLEAN:
return String.valueOf( readBoolean() );
case SQLTokenizer.BINARY:
case SQLTokenizer.VARBINARY:
return Utils.bytes2hex( readBinary() );
case SQLTokenizer.TINYINT:
return String.valueOf( readUnsignedByte() );
case SQLTokenizer.SMALLINT:
return String.valueOf( readShort() );
case SQLTokenizer.INT:
return String.valueOf( readInt() );
case SQLTokenizer.BIGINT:
return String.valueOf( readLong() );
case SQLTokenizer.REAL:
return String.valueOf( readFloat() );
case SQLTokenizer.FLOAT:
case SQLTokenizer.DOUBLE:
return String.valueOf( readDouble() );
case SQLTokenizer.MONEY:
return Money.createFromUnscaledValue( readLong() ).toString();
case SQLTokenizer.SMALLMONEY:
return Money.createFromUnscaledValue( readInt() ).toString();
case SQLTokenizer.NUMERIC:
case SQLTokenizer.DECIMAL:
return readNumeric().toString();
case SQLTokenizer.CHAR:
case SQLTokenizer.NCHAR:
case SQLTokenizer.VARCHAR:
case SQLTokenizer.NVARCHAR:
return readString();
case SQLTokenizer.CLOB:
case SQLTokenizer.NCLOB:
case SQLTokenizer.LONGNVARCHAR:
case SQLTokenizer.LONGVARCHAR:
return readLongString();
case SQLTokenizer.JAVA_OBJECT:
ByteArrayInputStream bais = new ByteArrayInputStream(readLongBinary());
ObjectInputStream ois = new ObjectInputStream(bais);
return ois.readObject().toString();
case SQLTokenizer.LONGVARBINARY:
case SQLTokenizer.BLOB:
return Utils.bytes2hex( readLongBinary() );
case SQLTokenizer.TIMESTAMP:
return new DateTime( readTimestamp(), SQLTokenizer.TIMESTAMP ).toString();
case SQLTokenizer.TIME:
return new DateTime( readTime(), SQLTokenizer.TIME ).toString();
case SQLTokenizer.DATE:
return new DateTime( readDate(), SQLTokenizer.DATE ).toString();
case SQLTokenizer.SMALLDATETIME:
return new DateTime( readSmallDateTime(), SQLTokenizer.TIMESTAMP ).toString();
case SQLTokenizer.UNIQUEIDENTIFIER:
return Utils.bytes2unique( page, this.offset);
default: throw new Error();
}this.offset = valueOffset;
if(readBoolean()) return null;
switch(dataType){
case SQLTokenizer.BIT:
case SQLTokenizer.BOOLEAN:
return readBoolean() ? Boolean.TRUE : Boolean.FALSE;
case SQLTokenizer.BINARY:
case SQLTokenizer.VARBINARY:
return readBinary();
case SQLTokenizer.TINYINT:
return Utils.getInteger( readUnsignedByte() );
case SQLTokenizer.SMALLINT:
return Utils.getInteger( readShort() );
case SQLTokenizer.INT:
return Utils.getInteger(readInt());
case SQLTokenizer.BIGINT:
return new Long(readLong());
case SQLTokenizer.REAL:
return new Float( readFloat() );
case SQLTokenizer.FLOAT:
case SQLTokenizer.DOUBLE:
return new Double( readDouble() );
case SQLTokenizer.MONEY:
return Money.createFromUnscaledValue(readLong());
case SQLTokenizer.SMALLMONEY:
return Money.createFromUnscaledValue(readInt());
case SQLTokenizer.NUMERIC:
case SQLTokenizer.DECIMAL:
return readNumeric();
case SQLTokenizer.CHAR:
case SQLTokenizer.NCHAR:
case SQLTokenizer.VARCHAR:
case SQLTokenizer.NVARCHAR:
return readString();
case SQLTokenizer.CLOB:
case SQLTokenizer.NCLOB:
case SQLTokenizer.LONGNVARCHAR:
case SQLTokenizer.LONGVARCHAR:
return readLongString();
case SQLTokenizer.JAVA_OBJECT:
ByteArrayInputStream bais = new ByteArrayInputStream(readLongBinary());
ObjectInputStream ois = new ObjectInputStream(bais);
return ois.readObject();
case SQLTokenizer.LONGVARBINARY:
case SQLTokenizer.BLOB:
return readLongBinary();
case SQLTokenizer.TIMESTAMP:
return new DateTime( readTimestamp(), SQLTokenizer.TIMESTAMP );
case SQLTokenizer.TIME:
return new DateTime( readTime(), SQLTokenizer.TIME );
case SQLTokenizer.DATE:
return new DateTime( readDate(), SQLTokenizer.DATE );
case SQLTokenizer.SMALLDATETIME:
return new DateTime( readSmallDateTime(), SQLTokenizer.TIMESTAMP );
case SQLTokenizer.UNIQUEIDENTIFIER:
return Utils.bytes2unique( page, this.offset);
default: throw new Error();
}this.offset = valueOffset;
if(readBoolean()) return null;
switch(dataType){
case SQLTokenizer.BIT:
case SQLTokenizer.BOOLEAN:
return readBoolean() ? new MutableNumeric(1) : new MutableNumeric(0);
case SQLTokenizer.BINARY:
case SQLTokenizer.VARBINARY:
return new MutableNumeric(Utils.bytes2double( readBinary() ));
case SQLTokenizer.TINYINT:
return new MutableNumeric(readUnsignedByte());
case SQLTokenizer.SMALLINT:
return new MutableNumeric(readShort());
case SQLTokenizer.INT:
return new MutableNumeric(readInt());
case SQLTokenizer.BIGINT:
return new MutableNumeric(readLong());
case SQLTokenizer.REAL:
return new MutableNumeric(readFloat());
case SQLTokenizer.FLOAT:
case SQLTokenizer.DOUBLE:
return new MutableNumeric(readDouble());
case SQLTokenizer.MONEY:
return new MutableNumeric( readLong(), 4);
case SQLTokenizer.SMALLMONEY:
return new MutableNumeric( readInt(), 4);
case SQLTokenizer.NUMERIC:
case SQLTokenizer.DECIMAL:
return readNumeric();
case SQLTokenizer.CHAR:
case SQLTokenizer.NCHAR:
case SQLTokenizer.VARCHAR:
case SQLTokenizer.NVARCHAR:
return new MutableNumeric( readString() );
case SQLTokenizer.CLOB:
case SQLTokenizer.NCLOB:
case SQLTokenizer.LONGNVARCHAR:
case SQLTokenizer.LONGVARCHAR:
return new MutableNumeric( readLongString() );
case SQLTokenizer.JAVA_OBJECT:
ByteArrayInputStream bais = new ByteArrayInputStream(readLongBinary());
ObjectInputStream ois = new ObjectInputStream(bais);
return new MutableNumeric( ois.readObject().toString() );
case SQLTokenizer.LONGVARBINARY:
case SQLTokenizer.BLOB:
return new MutableNumeric( Utils.bytes2double( readLongBinary() ) );
case SQLTokenizer.TIMESTAMP:
case SQLTokenizer.TIME:
case SQLTokenizer.DATE:
case SQLTokenizer.SMALLDATETIME:
throw SmallSQLException.create(Language.VALUE_CANT_CONVERT, new Object[] { SQLTokenizer.getKeyWord(dataType), "NUMERIC" });
default: throw new Error();
}int newSize = offset + 1;
if(newSize > page.length) resizePage(newSize);
page[ offset++ ] = (byte)(value);return storePage.raFile == null;writeByte( num.getInternalValue().length );
writeByte( num.getScale() );
writeByte( num.getSignum() );
for(int i=0; i<num.getInternalValue().length; i++){
writeInt( num.getInternalValue()[i] );
}throw noCurrentRow();throw noCurrentRow();return -1;return 0;throw noCurrentRow();throw noCurrentRow();throw noCurrentRow();throw noCurrentRow();throw noCurrentRow();throw noCurrentRow();throw noCurrentRow();throw noCurrentRow();throw noCurrentRow();throw noCurrentRow();return SmallSQLException.create(Language.ROW_NOCURRENT);return nextPagePos;return false;return 0;return true;if(nextPagePos >= 0){
throw SmallSQLException.create(Language.ROW_DELETED);
}
throw new Error();return 0;return 0;return 0;return 0;return 0;return null;return null;return null;return null;try{
if(raFile != null && page != null){
ByteBuffer buffer = ByteBuffer.wrap( page, 0, pageSize );
synchronized(raFile){
if(fileOffset < 0){
fileOffset = raFile.size();
}
raFile.position(fileOffset);
raFile.write(buffer);
}
}
return fileOffset;
}catch(Exception e){
throw SmallSQLException.createFromException(e);
}raFile = null;page = data;
pageSize = size;TableStorePage page = this.page;
if(page == null)
return table.getStore( con, filePos, lock );
while(page.nextLock != null) page = page.nextLock;
return table.getStore( page, lock);Entry[] newTable = new Entry[newCapacity];
transfer(newTable);
table = newTable;
threshold = (int)(newCapacity * 0.75f);int i = (int)(key % table.length);
Entry e = table[i];
while (true) {
if (e == null)
return null;
if (e.key == key)
return e.value;
e = e.next;
}int i = (int)(key % table.length);
table[i] = new Entry(key, value, table[i]);
if (size++ >= threshold)
resize(2 * table.length);
return null;return size;return (get(key) != null);int i = (int)(key % table.length);
Entry prev = table[i];
Entry e = prev;
while (e != null) {
Entry next = e.next;
if (e.key == key) {
size--;
if (prev == e)
table[i] = next;
else
prev.next = next;
return e.value;
}
prev = e;
e = next;
}
return null;Entry tab[] = table;
for (int i = 0; i < tab.length; i++)
tab[i] = null;
size = 0;return size == 0;Entry[] src = table;
int newCapacity = newTable.length;
for (int j = 0; j < src.length; j++) {
Entry e = src[j];
if (e != null) {
src[j] = null;
do {
Entry next = e.next;
e.next = null;
int i = (int)(e.key % newCapacity);
if(newTable[i] == null){
newTable[i] = e;
}else{
Entry entry = newTable[i];
while(entry.next != null) entry = entry.next;
entry.next = e;
}
e = next;
} while (e != null);
}
}Entry tab[] = table;
for (int i = 0; i < tab.length ; i++)
for (Entry e = tab[i] ; e != null ; e = e.next)
if (value.equals(e.value))
return true;
return false;if (idx >= size)
throw new IndexOutOfBoundsException("Column index: "+idx+", Size: "+size);
return data[idx];String[] array = new String[size];
System.arraycopy(data, 0, array, 0, size);
return array;String[] dataNew = new String[newSize];
System.arraycopy(data, 0, dataNew, 0, size);
data = dataNew;return size;if(size >= data.length ){
resize(size << 1);
}
data[size++] = descr;raFile = createFile( con, database );
firstPage = 8;
StoreImpl store = getStore( con, firstPage, SQLTokenizer.CREATE);
int count = columns.size();
store.writeInt( count );
for(int i=0; i<count; i++){
store.writeColumn(columns.get(i));
}
for(int i=0; i<indexes.size(); i++){
IndexDescription indexDesc = indexes.get(i);
store.writeInt( INDEX );
int offsetStart = store.getCurrentOffsetInPage();
store.setCurrentOffsetInPage( offsetStart + 4 );
indexDesc.save(store);
int offsetEnd = store.getCurrentOffsetInPage();
store.setCurrentOffsetInPage( offsetStart );
store.writeInt( offsetEnd - offsetStart);
store.setCurrentOffsetInPage( offsetEnd );
}
store.writeInt( 0 );
store.writeFinsh(null);
firstPage = store.getNextPagePos();synchronized(locks){
if(tabLockConnection != null && tabLockConnection != con) return null;
switch(con.isolationLevel){
case Connection.TRANSACTION_SERIALIZABLE:
serializeConnections.put( con, con);
break;
}
switch(pageOperation){
case SQLTokenizer.CREATE:{
if(locks.size() > 0){
Iterator values = locks.values().iterator();
while(values.hasNext()){
TableStorePage lock = (TableStorePage)values.next();
if(lock.con != con) return null;
}
}
for(int i=0; i<locksInsert.size(); i++){
TableStorePageInsert lock = (TableStorePageInsert)locksInsert.get(i);
if(lock.con != con) return null;
}
if(serializeConnections.size() > 0){
Iterator values = locks.values().iterator();
while(values.hasNext()){
TableStorePage lock = (TableStorePage)values.next();
if(lock.con != con) return null;
}
}
tabLockConnection = con;
tabLockCount++;
TableStorePage lock = new TableStorePage(con, this, LOCK_TAB, page);
con.add(lock);
return lock;
}
case SQLTokenizer.ALTER:{
if(locks.size() > 0 || locksInsert.size() > 0){
return null;
}
if(serializeConnections.size() > 0){
Iterator values = locks.values().iterator();
while(values.hasNext()){
TableStorePage lock = (TableStorePage)values.next();
if(lock.con != con) return null;
}
}
tabLockConnection = con;
tabLockCount++;
TableStorePage lock = new TableStorePage(con, this, LOCK_TAB, page);
lock.rollback();
return lock;
}
case SQLTokenizer.INSERT:{
if(serializeConnections.size() > 1) return null;
if(serializeConnections.size() == 1 && serializeConnections.get(con) == null) return null;
TableStorePageInsert lock = new TableStorePageInsert(con, this, LOCK_INSERT);
locksInsert.add( lock );
con.add(lock);
return lock;
}
case SQLTokenizer.SELECT:
case SQLTokenizer.UPDATE:{
Long pageKey = new Long(page);
TableStorePage prevLock = null;
TableStorePage lock = (TableStorePage)locks.get( pageKey );
TableStorePage usableLock = null;
while(lock != null){
if(lock.con == con ||
con.isolationLevel <= Connection.TRANSACTION_READ_UNCOMMITTED){
usableLock = lock;
} else {
if(lock.lockType == LOCK_WRITE){
return null;
}
}
prevLock = lock;
lock = lock.nextLock;
}
if(usableLock != null){
return usableLock;
}
lock = new TableStorePage( con, this, LOCK_NONE, page);
if(con.isolationLevel >= Connection.TRANSACTION_REPEATABLE_READ || pageOperation == SQLTokenizer.UPDATE){
lock.lockType = pageOperation == SQLTokenizer.UPDATE ? LOCK_WRITE : LOCK_READ;
if(prevLock != null){
prevLock.nextLock = lock.nextLock;
}else{
locks.put( pageKey, lock );
}
con.add(lock);
}
return lock;
}
case SQLTokenizer.LONGVARBINARY:
return new TableStorePage( con, this, LOCK_INSERT, -1);
default:
throw new Error("pageOperation:"+pageOperation);
}
}return firstPage;if(readlock.lockType == LOCK_INSERT){
TableStorePage lock = new TableStorePage( con, this, LOCK_INSERT, -1);
readlock.nextLock = lock;
con.add(lock);
return lock;
}
Long pageKey = new Long(readlock.fileOffset);
TableStorePage prevLock = null;
TableStorePage lock = (TableStorePage)locks.get( pageKey );
while(lock != null){
if(lock.con != con) return null;
if(lock.lockType < LOCK_WRITE){
lock.lockType = LOCK_WRITE;
return lock;
}
prevLock = lock;
lock = lock.nextLock;
}
lock = new TableStorePage( con, this, LOCK_WRITE, readlock.fileOffset);
if(prevLock != null){
prevLock.nextLock = lock;
} else {
locks.put( pageKey, lock );
}
con.add(lock);
return lock;TableStorePage storePage = new TableStorePage( con, this, LOCK_NONE, -2);
return StoreImpl.createStore( this, storePage, SQLTokenizer.INSERT, -2 );ByteBuffer buffer = ByteBuffer.allocate(8);
buffer.putInt(MAGIC_TABLE);
buffer.putInt(TABLE_VIEW_VERSION);
buffer.position(0);
raFile.write(buffer);if(indexes != null)
indexes.close();
raFile.close();
raFile = null;
if( lobs != null ){
lobs.close();
lobs = null;
}TableStorePage storePage = requestLock( con, SQLTokenizer.CREATE, -1 );
if(storePage == null){
throw SmallSQLException.create(Language.TABLE_CANT_DROP_LOCKED, name);
}
con.rollbackFile(raFile);
close();
if(lobs != null)
lobs.drop(con);
if(indexes != null)
indexes.drop(database);
boolean ok = getFile(database).delete();
if(!ok) throw SmallSQLException.create(Language.TABLE_CANT_DROP, name);boolean ok = new File( Utils.createTableViewFileName( database, name ) ).delete();
if(!ok) throw SmallSQLException.create(Language.TABLE_CANT_DROP, name);TableStorePage storePage = requestLock( con, pageOperation, filePos );
return StoreImpl.createStore( this, storePage, pageOperation, filePos );TableStorePage storePage = requestLock( con, SQLTokenizer.INSERT, -1 );
return StoreImpl.createStore( this, storePage, SQLTokenizer.INSERT, -1 );if(lobs == null){
lobs = new Lobs( this );
}
return lobs.getStore( con, filePos, pageOperation );synchronized(locks){
if(raFile == null){
throw SmallSQLException.create(Language.TABLE_MODIFIED, name);
}
long endTime = 0;
while(true){
TableStorePage storePage = requestLockImpl( con, pageOperation, page);
if(storePage != null)
return storePage;
if(endTime == 0)
endTime = System.currentTimeMillis() + 5000;
long waitTime = endTime - System.currentTimeMillis();
if(waitTime <= 0)
throw SmallSQLException.create(Language.TABLE_DEADLOCK, name);
locks.wait(waitTime);
}
}synchronized(locks){
ArrayList inserts = new ArrayList();
if(con.isolationLevel <= Connection.TRANSACTION_READ_UNCOMMITTED){
for(int i=0; i<locksInsert.size(); i++){
TableStorePageInsert lock = (TableStorePageInsert)locksInsert.get(i);
inserts.add(lock.getLink());
}
}else{
for(int i=0; i<locksInsert.size(); i++){
TableStorePageInsert lock = (TableStorePageInsert)locksInsert.get(i);
if(lock.con == con)
inserts.add(lock.getLink());
}
}
return inserts;
}final int lockType = storePage.lockType;
final long fileOffset = storePage.fileOffset;
synchronized(locks){
try{
TableStorePage lock;
TableStorePage prev;
switch(lockType){
case LOCK_INSERT:
for(int i=0; i<locksInsert.size(); i++){
prev = lock = (TableStorePage)locksInsert.get(i);
while(lock != null){
if(lock == storePage){
if(lock == prev){
if(lock.nextLock == null){
locksInsert.remove(i--);
}else{
locksInsert.set( i, lock.nextLock );
}
}else{
prev.nextLock = lock.nextLock;
}
return;
}
prev = lock;
lock = lock.nextLock;
}
}
break;
case LOCK_READ:
case LOCK_WRITE:
Long pageKey = new Long(fileOffset);
lock = (TableStorePage)locks.get( pageKey );
prev = lock;
while(lock != null){
if(lock == storePage){
if(lock == prev){
if(lock.nextLock == null){
locks.remove(pageKey);
}else{
locks.put( pageKey, lock.nextLock );
}
}else{
prev.nextLock = lock.nextLock;
}
return;
}
prev = lock;
lock = lock.nextLock;
}
break;
case LOCK_TAB:
assert storePage.con == tabLockConnection : "Internal Error with TabLock";
if(--tabLockCount == 0) tabLockConnection = null;
break;
default:
throw new Error();
}
}finally{
locks.notifyAll();
}
}return StoreImpl.recreateStore( this, storePage, pageOperation );return table;return store.getString( offsets[colIdx], dataTypes[colIdx] );return filePos;if(store instanceof StoreNull && store != Store.NULL){
return true;
}
if(store instanceof StoreImpl &&
((StoreImpl)store).isRollback()){
return true;
}
return false;int offset = offsets[colIdx++];
int length = (colIdx < offsets.length ? offsets[colIdx] : store.getUsedSize()) - offset;
dst.copyValueFrom( (StoreImpl)store, offset, length);return row;return store.getBoolean( offsets[colIdx], dataTypes[colIdx] );insertStorePages = table.getInserts(con);
firstOwnInsert = 0x4000000000000000L | insertStorePages.size();
maxFileOffset = table.raFile.size();
beforeFirst();return store.getMoney( offsets[colIdx], dataTypes[colIdx] );filePos = -1;
noRow();return store.getInt( offsets[colIdx], dataTypes[colIdx] );filePos = table.getFirstPage();
row = 1;
return moveToValidRow();if(filePos < 0) return;
if(store == Store.NOROW)
filePos = table.getFirstPage();
else
if(filePos >= 0x4000000000000000L){
filePos++;
if((filePos & 0x3FFFFFFFFFFFFFFFL) >= insertStorePages.size()){
filePos = -1;
noRow();
}
}else
filePos = store.getNextPagePos();return store.isNull( offsets[colIdx] );if(super.init(con)){
Columns columns = table.columns;
offsets     = new int[columns.size()];
dataTypes   = new int[columns.size()];
for(int i=0; i<columns.size(); i++){
dataTypes[i] = columns.get(i).getDataType();
}
return true;
}
return false;Columns tableColumns = table.columns;
int count = tableColumns.size();
StoreImpl newStore = table.getStoreTemp(con);
synchronized(con.getMonitor()){
((StoreImpl)this.store).createWriteLock();
for(int i=0; i<count; i++){
Expression src = updateValues[i];
if(src != null){
newStore.writeExpression( src, tableColumns.get(i) );
}else{
copyValueInto( i, newStore );
}
}
((StoreImpl)this.store).updateFinsh(con, newStore);
}return dataTypes[colIdx];return store.getObject( offsets[colIdx], dataTypes[colIdx] );store.deleteRow(con);
store = new StoreNull(store.getNextPagePos());return store.getBytes( offsets[colIdx], dataTypes[colIdx] );filePos = 0;
store = Store.NOROW;
row = 0;if(filePos >= 0x4000000000000000L){
store = ((StorePageLink)insertStorePages.get( (int)(filePos & 0x3FFFFFFFFFFFFFFFL) )).getStore( table, con, lock);
}else{
store = (filePos < maxFileOffset) ? table.getStore( con, filePos, lock ) : null;
if(store == null){
if(insertStorePages.size() > 0){
filePos = 0x4000000000000000L;
store = ((StorePageLink)insertStorePages.get( (int)(filePos & 0x3FFFFFFFFFFFFFFFL) )).getStore( table, con, lock);
}
}
}
if(store != null){
if(!store.isValidPage()){
return false;
}
store.scanObjectOffsets( offsets, dataTypes );
afterLastValidFilePos = store.getNextPagePos();
return true;
}else{
filePos = -1;
noRow();
return false;
}return store.getDouble( offsets[colIdx], dataTypes[colIdx] );while(filePos >= 0){
if(moveToRow())
return true;
setNextFilePos();
}
row = 0;
return false;return store.getLong( offsets[colIdx], dataTypes[colIdx] );return store.getFloat( offsets[colIdx], dataTypes[colIdx] );filePos = rowPosition;
if(filePos < 0 || !moveToRow()){
store = new StoreNull(store.getNextPagePos());
}Columns tableColumns = table.columns;
int count = tableColumns.size();
StoreImpl store = table.getStoreInsert(con);
for(int i=0; i<count; i++){
Column tableColumn = tableColumns.get(i);
Expression src = updateValues[i];
if(src == null) src = tableColumn.getDefaultValue(con);
store.writeExpression( src, tableColumn );
}
store.writeFinsh( con );
insertStorePages.add(store.getLink());return store.getNumeric( offsets[colIdx], dataTypes[colIdx] );row = 0;
store = Store.NOROW;if(filePos < 0) return false;
setNextFilePos();
row++;
return moveToValidRow();row = 0;
store = Store.NULL;return filePos >= firstOwnInsert;if(nextLock != null){
fileOffset = nextLock.commit();
nextLock = null;
rollback();
return fileOffset;
}
if(lockType == TableView.LOCK_READ)
return fileOffset;
return super.commit();return page;table.freeLock(this);return link;long result = super.commit();
link.filePos = fileOffset;
link.page = null;
return result;return name;for(int i=0; i<columns.size(); i++){
if( columns.get(i).getName().equalsIgnoreCase(columnName) ) return i;
}
return -1;if( database.isReadOnly() ){
throw SmallSQLException.create(Language.DB_READONLY);
}
File file = getFile( database );
boolean ok = file.createNewFile();
if(!ok) throw SmallSQLException.create(Language.TABLE_EXISTENT, name);
FileChannel raFile = Utils.openRaFile( file, database.isReadOnly() );
con.add(new CreateFile(file, raFile, con, database));
writeMagic(raFile);
return raFile;return new File( Utils.createTableViewFileName( database, name ) );return timestamp;FileChannel raFile = null;
try{
String fileName = Utils.createTableViewFileName( database, name );
File file = new File( fileName );
if(!file.exists())
throw SmallSQLException.create(Language.TABLE_OR_VIEW_MISSING, name);
raFile = Utils.openRaFile( file, database.isReadOnly() );
ByteBuffer buffer = ByteBuffer.allocate(8);
raFile.read(buffer);
buffer.position(0);
int magic   = buffer.getInt();
int version = buffer.getInt();
switch(magic){
case MAGIC_TABLE:
case MAGIC_VIEW:
break;
default:
throw SmallSQLException.create(Language.TABLE_OR_VIEW_FILE_INVALID, fileName);
}
if(version > TABLE_VIEW_VERSION)
throw SmallSQLException.create(Language.FILE_TOONEW, new Object[] { new Integer(version), fileName });
if(version < TABLE_VIEW_OLD_VERSION)
throw SmallSQLException.create(Language.FILE_TOOOLD, new Object[] { new Integer(version), fileName });
if(magic == MAGIC_TABLE)
return new Table( database, con, name, raFile, raFile.position(), version);
return new View ( con, name, raFile, raFile.position());
}catch(Throwable e){
if(raFile != null)
try{
raFile.close();
}catch(Exception e2){
DriverManager.println(e2.toString());
}
throw SmallSQLException.createFromException(e);
}for(int i=0; i<columns.size(); i++){
Column column = columns.get(i);
if( column.getName().equalsIgnoreCase(columnName) ) return column;
}
return null;return map.values();return name.toUpperCase(Locale.US);map.put(getUniqueKey(name), tableView);return (TableView)map.get(getUniqueKey(name));return (TableView)map.remove(getUniqueKey(name));return (alias != null) ? alias : getTableView().name;TableView tableView = getTableView();
if(tableTimestamp != tableView.getTimestamp()){
this.con = con;
tableTimestamp = tableView.getTimestamp();
return true;
}
return false;return false;if(tableView instanceof Table)
return new TableResult((Table)tableView);
return new ViewResult( (View)tableView );return alias != null;this.alias = alias;if(from instanceof Where){
from = ((Where)from).getFrom();
}
if(from instanceof TableViewResult){
return (TableViewResult)from;
}
throw SmallSQLException.create(Language.ROWSOURCE_READONLY);int size = dataSources.size();
int bitCount = 0;
while(size>0){
bitCount++;
size >>= 1;
}
return bitCount;currentDS.noRow();
row = 0;for(int i=0; i<dataSources.size(); i++){
dataSources.get(i).execute();
}return currentDS.getInt(colIdx);return currentDS.getString(colIdx);int bitCount = getBitCount();
int mask = 0xFFFFFFFF >>> (32 - bitCount);
dataSourceIdx = (int)rowPosition & mask;
currentDS = dataSources.get(dataSourceIdx);
currentDS.setRowPosition( rowPosition >> bitCount );dataSourceIdx = dataSources.size()-1;
currentDS = dataSources.get(dataSourceIdx);
currentDS.afterLast();
row = 0;boolean result = false;
int colCount = -1;
for(int i=0; i<dataSources.size(); i++){
DataSource ds = dataSources.get(i);
result |= ds.init(con);
int nextColCount = ds.getTableView().columns.size();
if(colCount == -1)
colCount = nextColCount;
else
if(colCount != nextColCount)
throw SmallSQLException.create(Language.UNION_DIFFERENT_COLS, new Object[] { new Integer(colCount), new Integer(nextColCount)});
}
return result;return currentDS.rowDeleted();dataSources.add(ds);
currentDS = dataSources.get(0);return false;return currentDS.getBoolean(colIdx);return currentDS.rowInserted();boolean n = currentDS.next();
row++;
if(n) return true;
while(dataSources.size() > dataSourceIdx+1){
currentDS = dataSources.get(++dataSourceIdx);
currentDS.beforeFirst();
n = currentDS.next();
if(n) return true;
}
row = 0;
return false;return currentDS.getObject(colIdx);return currentDS.getTableView();return currentDS.getDataType(colIdx);return currentDS.isNull(colIdx);return currentDS.getBytes(colIdx);return currentDS.getDouble(colIdx);return currentDS.getLong(colIdx);return currentDS.getFloat(colIdx);return currentDS.getMoney(colIdx);dataSourceIdx = 0;
currentDS = dataSources.get(0);
boolean b = currentDS.first();
row = b ? 1 : 0;
return b;return row;currentDS.nullRow();
row = 0;dataSourceIdx = 0;
currentDS = dataSources.get(0);
currentDS.beforeFirst();
row = 0;return currentDS.getNumeric(colIdx);int bitCount = getBitCount();
return dataSourceIdx | currentDS.getRowPosition() << bitCount;return database.getName() + '/' + name + LOB_EXTENTION;if(digit >= '0' && digit <= '9') return digit - '0';
digit |= 0x20;
if(digit >= 'a' && digit <= 'f') return digit - 'W';
throw new RuntimeException();RandomAccessFile raFile = new RandomAccessFile(file, readonly ? "r" : "rw" );
FileChannel channel = raFile.getChannel();
if( !readonly ){
try{
FileLock lock = channel.tryLock();
if(lock == null){
throw SmallSQLException.create(Language.CANT_LOCK_FILE, file);
}
}catch(SQLException sqlex){
throw sqlex;
}catch(Throwable th){
throw SmallSQLException.createFromException(Language.CANT_LOCK_FILE, file, th);
}
}
return channel;if(daten.length-offset < 16){
byte[] temp = new byte[16];
System.arraycopy(daten, offset, temp, 0, daten.length-offset);
daten = temp;
}
char[] chars = new char[36];
chars[8] = chars[13] = chars[18] = chars[23] = '-';
chars[0] = digits[ (daten[offset+3] >> 4) & 0x0F ];
chars[1] = digits[ (daten[offset+3]     ) & 0x0F ];
chars[2] = digits[ (daten[offset+2] >> 4) & 0x0F ];
chars[3] = digits[ (daten[offset+2]     ) & 0x0F ];
chars[4] = digits[ (daten[offset+1] >> 4) & 0x0F ];
chars[5] = digits[ (daten[offset+1]     ) & 0x0F ];
chars[6] = digits[ (daten[offset+0] >> 4) & 0x0F ];
chars[7] = digits[ (daten[offset+0]     ) & 0x0F ];
chars[ 9] = digits[ (daten[offset+5] >> 4) & 0x0F ];
chars[10] = digits[ (daten[offset+5]     ) & 0x0F ];
chars[11] = digits[ (daten[offset+4] >> 4) & 0x0F ];
chars[12] = digits[ (daten[offset+4]     ) & 0x0F ];
chars[14] = digits[ (daten[offset+7] >> 4) & 0x0F ];
chars[15] = digits[ (daten[offset+7]     ) & 0x0F ];
chars[16] = digits[ (daten[offset+6] >> 4) & 0x0F ];
chars[17] = digits[ (daten[offset+6]     ) & 0x0F ];
chars[19] = digits[ (daten[offset+8] >> 4) & 0x0F ];
chars[20] = digits[ (daten[offset+8]     ) & 0x0F ];
chars[21] = digits[ (daten[offset+9] >> 4) & 0x0F ];
chars[22] = digits[ (daten[offset+9]     ) & 0x0F ];
chars[24] = digits[ (daten[offset+10] >> 4) & 0x0F ];
chars[25] = digits[ (daten[offset+10]     ) & 0x0F ];
chars[26] = digits[ (daten[offset+11] >> 4) & 0x0F ];
chars[27] = digits[ (daten[offset+11]     ) & 0x0F ];
chars[28] = digits[ (daten[offset+12] >> 4) & 0x0F ];
chars[29] = digits[ (daten[offset+12]     ) & 0x0F ];
chars[30] = digits[ (daten[offset+13] >> 4) & 0x0F ];
chars[31] = digits[ (daten[offset+13]     ) & 0x0F ];
chars[32] = digits[ (daten[offset+14] >> 4) & 0x0F ];
chars[33] = digits[ (daten[offset+14]     ) & 0x0F ];
chars[34] = digits[ (daten[offset+15] >> 4) & 0x0F ];
chars[35] = digits[ (daten[offset+15]     ) & 0x0F ];
return new String(chars);int result = 0;
int length = Math.min( 4, bytes.length);
for(int i=0; i<length; i++){
result = (result << 8) | (bytes[i] & 0xFF);
}
return result;int length = Math.min( leftBytes.length, rightBytes.length );
int comp = 0;
for(int i=0; i<length; i++){
if(leftBytes[i] != rightBytes[i]){
comp = leftBytes[i] < rightBytes[i] ? -1 : 1;
break;
}
}
if(comp == 0 && leftBytes.length != rightBytes.length){
comp = leftBytes.length < rightBytes.length ? -1 : 1;
}
return comp;try{
byte[] bytes = new byte[length / 2];
for(int i=0; i<bytes.length; i++){
bytes[i] = (byte)((hexDigit2int( hex[ offset++ ] ) << 4)
| hexDigit2int( hex[ offset++ ] ));
}
return bytes;
}catch(Exception e){
throw SmallSQLException.create(Language.SEQUENCE_HEX_INVALID, String.valueOf(offset));
}Expressions list = new Expressions();
getExpressionNameFromTree( list, tree );
return list;try{
return Double.parseDouble( val ) != 0;
}catch(NumberFormatException e){}
return "true".equalsIgnoreCase( val ) || "yes".equalsIgnoreCase( val ) || "t".equalsIgnoreCase( val );int offset = 0;
for(int end = list.length; offset < end; offset++){
if((list[offset]) == value) return offset;
}
return -1;int length = value.length;
loop1:
for(int end = list.length-length; offset <= end; offset++){
for(int i=0; i<length; i++ ){
if(list[offset+i] != value[i]){
continue loop1;
}
}
return offset;
}
return -1;if(value == null || pattern == null) return false;
if(pattern.length() == 0) return true;
int mIdx = 0;
int sIdx = 0;
boolean range = false;
weiter:
while(pattern.length() > mIdx && value.length() > sIdx) {
char m = Character.toUpperCase(pattern.charAt(mIdx++));
switch(m) {
case '%':
range = true;
break;
case '_':
sIdx++;
break;
default:
if(range) {
for(; sIdx < value.length(); sIdx++) {
if(Character.toUpperCase(value.charAt(sIdx)) == m) break;
}
if(sIdx >= value.length()) return false;
int lastmIdx = mIdx - 1;
sIdx++;
while(pattern.length() > mIdx && value.length() > sIdx) {
m = Character.toUpperCase(pattern.charAt(mIdx++));
if(Character.toUpperCase(value.charAt(sIdx)) != m) {
if(m == '%' || m == '_') {
mIdx--;
break;
}
mIdx = lastmIdx;
continue weiter;
}
sIdx++;
}
range = false;
}else{
if(Character.toUpperCase(value.charAt(sIdx)) != m) return false;
sIdx++;
}
break;
}
}
while(pattern.length() > mIdx) {
if(Character.toUpperCase(pattern.charAt(mIdx++)) != '%') return false;
}
while(value.length() > sIdx && !range) return false;
return true;MemoryResult source = new MemoryResult(data, colNames.length);
CommandSelect cmd = new CommandSelect(con.log);
for(int i=0; i<colNames.length; i++){
ExpressionName expr = new ExpressionName(colNames[i]);
cmd.addColumnExpression( expr );
expr.setFrom( source, i, source.getColumn(i));
}
cmd.setSource(source);
return cmd;long result = 0;
int length = Math.min( 8, bytes.length);
for(int i=0; i<length; i++){
result = (result << 8) | (bytes[i] & 0xFF);
}
return result;return Double.longBitsToDouble( bytes2long( bytes ) );if(value > Integer.MAX_VALUE)
return Integer.MAX_VALUE;
if(value < Integer.MIN_VALUE)
return Integer.MIN_VALUE;
return (int)value;value |= 0x20;
for(int end = offset+length;offset < end; offset++){
if((str[offset] | 0x20) == value) return offset;
}
return -1;StringBuffer buf = new StringBuffer(bytes.length << 1);
for(int i=0; i<bytes.length; i++){
buf.append( digits[ (bytes[i] >> 4) & 0x0F ] );
buf.append( digits[ (bytes[i]     ) & 0x0F ] );
}
return buf.toString();if(value >= -4 && value < 256){
return shortCache[ value+4 ];
}else
return new Short((short)value);if(value >= -4 && value < 256){
return integerCache[ value+4 ];
}else
return new Integer(value);if(value > Long.MAX_VALUE)
return Long.MAX_VALUE;
if(value < Long.MIN_VALUE)
return Long.MIN_VALUE;
return (long)value;if(tree.getType() == Expression.NAME ){
list.add(tree);
}
Expression[] params = tree.getParams();
if(params != null){
for(int i=0; i<params.length; i++){
getExpressionNameFromTree( list, tree );
}
}if(value < 0)
return (long)(value * 10000 - 0.5);
return (long)(value * 10000 + 0.5);return long2bytes(Double.doubleToLongBits(value));if (value < Integer.MIN_VALUE) return Integer.MIN_VALUE;
else if (value > Integer.MAX_VALUE) return Integer.MAX_VALUE;
else return (int) value;return int2bytes(Float.floatToIntBits(value));return Float.intBitsToFloat( bytes2int( bytes ) );return database.getName() + '/' + name + IDX_EXTENTION;return database.getName() + '/' + name + TABLE_VIEW_EXTENTION;char[] chars = unique.toCharArray();
byte[] daten = new byte[16];
daten[3] = hex2byte( chars, 0 );
daten[2] = hex2byte( chars, 2 );
daten[1] = hex2byte( chars, 4 );
daten[0] = hex2byte( chars, 6 );
daten[5] = hex2byte( chars, 9 );
daten[4] = hex2byte( chars, 11 );
daten[7] = hex2byte( chars, 14 );
daten[6] = hex2byte( chars, 16 );
daten[8] = hex2byte( chars, 19 );
daten[9] = hex2byte( chars, 21 );
daten[10] = hex2byte( chars, 24 );
daten[11] = hex2byte( chars, 26 );
daten[12] = hex2byte( chars, 28 );
daten[13] = hex2byte( chars, 30 );
daten[14] = hex2byte( chars, 32 );
daten[15] = hex2byte( chars, 34 );
return daten;byte[] result = new byte[8];
result[0] = (byte)(value >> 56);
result[1] = (byte)(value >> 48);
result[2] = (byte)(value >> 40);
result[3] = (byte)(value >> 32);
result[4] = (byte)(value >> 24);
result[5] = (byte)(value >> 16);
result[6] = (byte)(value >> 8);
result[7] = (byte)(value);
return result;byte[] result = new byte[4];
result[0] = (byte)(value >> 24);
result[1] = (byte)(value >> 16);
result[2] = (byte)(value >> 8);
result[3] = (byte)(value);
return result;try{
return (byte)((hexDigit2int( hex[ offset++ ] ) << 4)
| hexDigit2int( hex[ offset++ ] ));
}catch(Exception e){
throw SmallSQLException.create(Language.SEQUENCE_HEX_INVALID_STR, new Object[] { new Integer(offset), new String(hex) });
}ByteBuffer buffer = ByteBuffer.allocate(8);
buffer.putInt(MAGIC_VIEW);
buffer.putInt(TABLE_VIEW_VERSION);
buffer.position(0);
raFile.write(buffer);File file = new File( Utils.createTableViewFileName( database, name ) );
boolean ok = file.delete();
if(!ok) throw SmallSQLException.create(Language.VIEW_CANTDROP, name);commandSelect.compile(con);
Expressions exprs = commandSelect.columnExpressions;
for(int c=0; c<exprs.size(); c++){
Expression expr = exprs.get(c);
if(expr instanceof ExpressionName){
Column column = ((ExpressionName)expr).getColumn().copy();
column.setName( expr.getAlias() );
columns.add( column );
}else{
columns.add( new ColumnExpression(expr));
}
}FileChannel raFile = createFile( con, database );
StorePage storePage = new StorePage( null, -1, raFile, 8);
StoreImpl store = StoreImpl.createStore( null, storePage, SQLTokenizer.CREATE, 8);
store.writeString(sql);
store.writeInt( 0 );
store.writeFinsh(null);
raFile.close();return columnExpressions.get(colIdx).getDataType();return commandSelect.from.rowInserted();return commandSelect.relative(rows);commandSelect.afterLast();return columnExpressions.get(colIdx).getMoney();commandSelect.from.nullRow();return commandSelect.isBeforeFirst();return columnExpressions.get(colIdx).getObject();commandSelect.beforeFirst();return commandSelect.last();return columnExpressions.get(colIdx).getBoolean();return commandSelect.first();return view;return commandSelect.isLast();return commandSelect.getRow();return commandSelect.from.rowDeleted();if(super.init(con)){
commandSelect.compile(con);
return true;
}
return false;commandSelect.updateRow(con, updateValues);commandSelect.deleteRow(con);return columnExpressions.get(colIdx).getString();return commandSelect.isFirst();commandSelect.from.execute();return columnExpressions.get(colIdx).getInt();return commandSelect.absolute(row);return commandSelect.from.getRowPosition();return columnExpressions.get(colIdx).getNumeric();return commandSelect.isAfterLast();return columnExpressions.get(colIdx).getLong();return columnExpressions.get(colIdx).getDouble();return columnExpressions.get(colIdx).getFloat();return columnExpressions.get(colIdx).getBytes();return columnExpressions.get(colIdx).isNull();return commandSelect.previous();return commandSelect.next();commandSelect.from.setRowPosition(rowPosition);commandSelect.insertRow(con, updateValues);commandSelect.from.noRow();while(next()){}
return previous();return isCurrentRow ? row : 0;return rowSource.rowDeleted();return row == 0;rowSource.beforeFirst();
row = 0;return rowSource.isExpressionsFromThisRowSource(columns);return rowSource.rowInserted();boolean oldIsCurrentRow = isCurrentRow;
do{
isCurrentRow = rowSource.next();
}while(isCurrentRow && !isValidRow());
if(oldIsCurrentRow || isCurrentRow) row++;
return isCurrentRow;boolean oldIsCurrentRow = isCurrentRow;
do{
isCurrentRow = rowSource.previous();
}while(isCurrentRow && !isValidRow());
if(oldIsCurrentRow || isCurrentRow) row--;
return isCurrentRow;if(!isCurrentRow) return false;
long rowPos = rowSource.getRowPosition();
boolean isNext = next();
rowSource.setRowPosition(rowPos);
return !isNext;rowSource.noRow();
row = 0;while(next()){}return rowSource.isScrollable();return row == 1 && isCurrentRow;isCurrentRow = rowSource.first();
while(isCurrentRow && !isValidRow()){
isCurrentRow = rowSource.next();
}
row = 1;
return isCurrentRow;rowSource.nullRow();
row = 0;return row > 0 && !isCurrentRow;return rowSource;rowSource.setRowPosition(rowPosition);return where == null || rowSource.rowInserted() || where.getBoolean();return rowSource.getRowPosition();rowSource.execute();String dfltLocaleStr = Locale.getDefault().toString();
try {
return getFromLocaleTree(dfltLocaleStr);
}
catch (IllegalArgumentException e) {
return new Language();
}String part = localeStr;
while (true) {
String langClassName = Language.class.getName() + '_' + part;
try {
return (Language) Class.forName(langClassName).newInstance();
}
catch (IllegalAccessException e) {
assert(false): "Internal error: must never happen.";
}
catch (ClassNotFoundException e) {
}
catch (InstantiationException e) {
assert(false): "Error during Language instantiation: " + e.getMessage();
}
int lastUndsc = part.lastIndexOf("_");
if (lastUndsc > -1) part = part.substring(0, lastUndsc);
else break;
}
throw new IllegalArgumentException("Locale not found in the tree: " + localeStr);try {
return getFromLocaleTree(localeStr);
}
catch (IllegalArgumentException e) {
return getDefaultLanguage();
}String sqlState = (String) sqlStates.get(key);
assert(sqlState != null): "SQL State code not found: " + key;
return sqlState;String message = (String) messages.get(key);
assert(message != null): "Message code not found: " + key;
return message;Set inserted = new HashSet();
for (int i = 0; i < entries.length; i++) {
String key = entries[i][0];
if (! inserted.add(key)) {
throw new IllegalArgumentException("Duplicate key: " + key);
}
else {
String value = entries[i][1];
messages.put(key, value);
}
}return MESSAGES;Set inserted = new HashSet();
for (int i = 0; i < SQL_STATES.length; i++) {
String key = SQL_STATES[i][0];
if (! inserted.add(key)) {
throw new IllegalArgumentException("Duplicate key: " + key);
}
else {
String value = SQL_STATES[i][1];
sqlStates.put(key, value);
}
}return ENTRIES;return ENTRIES;try{
junit.textui.TestRunner.main(new String[]{AllTests.class.getName()});
}catch(Throwable e){
e.printStackTrace();
}new smallsql.database.SSDriver();
new sun.jdbc.odbc.JdbcOdbcDriver();
if (urlAddition == null) urlAddition = "";
if (info == null) info = new Properties();
String urlComplete = JDBC_URL + urlAddition;
return DriverManager.getConnection(urlComplete, info);new smallsql.database.SSDriver();
new sun.jdbc.odbc.JdbcOdbcDriver();
return DriverManager.getConnection(JDBC_URL + "?create=true;locale=en");TestSuite theSuite = new TestSuite("SmallSQL all Tests");
theSuite.addTestSuite( TestAlterTable.class );
theSuite.addTestSuite( TestAlterTable2.class );
theSuite.addTest    ( TestDataTypes.suite() );
theSuite.addTestSuite(TestDBMetaData.class);
theSuite.addTestSuite(TestExceptionMethods.class);
theSuite.addTest     (TestExceptions.suite());
theSuite.addTestSuite(TestDeleteUpdate.class);
theSuite.addTest     (TestFunctions.suite() );
theSuite.addTestSuite(TestGroupBy.class);
theSuite.addTestSuite(TestIdentifer.class);
theSuite.addTest     (TestJoins.suite());
theSuite.addTestSuite(TestLanguage.class);
theSuite.addTestSuite(TestMoneyRounding.class );
theSuite.addTest     (TestOperatoren.suite() );
theSuite.addTestSuite(TestOrderBy.class);
theSuite.addTestSuite(TestOther.class);
theSuite.addTestSuite(TestResultSet.class);
theSuite.addTestSuite(TestScrollable.class);
theSuite.addTestSuite(TestStatement.class);
theSuite.addTestSuite(TestThreads.class);
theSuite.addTestSuite(TestTokenizer.class);
theSuite.addTestSuite(TestTransactions.class);
return theSuite;if(con == null || con.isClosed()){
con = createConnection();
}
return con;while(rs.next()){
for(int i=1; i<=rs.getMetaData().getColumnCount(); i++){
System.out.print(rs.getObject(i)+"\t");
}
System.out.println();
}int colCount = rs.getMetaData().getColumnCount();
int count = 0;
while(rs.next()){
count++;
for(int i=1; i<=colCount; i++){
rs.getObject(i);
}
}
assertEquals( "Wrong row count", sollCount, count);
for(int i=1; i<=colCount; i++){
try{
fail( "Column:"+i+" Value:"+String.valueOf(rs.getObject(i)));
}catch(SQLException e){
assertSQLException("01000", 0, e);
}
}
assertFalse( "Scroll after last", rs.next() );if(obj1 instanceof byte[]){
if(!java.util.Arrays.equals( (byte[])obj1, (byte[])obj2)){
fail(msg + " expected:" + bytes2hex((byte[])obj1)+ " but was:"+bytes2hex((byte[])obj2));
}
}else{
if(obj1 instanceof BigDecimal)
if(((BigDecimal)obj1).compareTo((BigDecimal)obj2) == 0) return;
assertEquals( msg, obj1, obj2);
}if(needTrim && obj1 != null){
if(obj1 instanceof String) obj1 = ((String)obj1).trim();
if(obj1 instanceof byte[]){
byte[] tmp = (byte[])obj1;
int k=tmp.length-1;
for(; k>= 0; k--) if(tmp[k] != 0) break;
k++;
byte[] tmp2 = new byte[k];
System.arraycopy( tmp, 0, tmp2, 0, k);
obj1 = tmp2;
}
}
if(needTrim && obj2 != null){
if(obj2 instanceof String) obj2 = ((String)obj2).trim();
if(obj2 instanceof byte[]){
byte[] tmp = (byte[])obj2;
int k=tmp.length-1;
for(; k>= 0; k--) if(tmp[k] != 0) break;
k++;
byte[] tmp2 = new byte[k];
System.arraycopy( tmp, 0, tmp2, 0, k);
obj2 = tmp2;
}
}
assertEqualsObject( msg, obj1, obj2);Connection con = AllTests.getConnection();
Statement st = con.createStatement();
ResultSet rs = st.executeQuery(sql);
assertTrue( "No row produce", rs.next());
assertEqualsRsValue(obj,rs,false);try {
Statement st = con.createStatement();
st.execute("drop view "+name);
st.close();
} catch (SQLException e) {}Connection con = AllTests.getConnection();
Statement st = con.createStatement();
ResultSet rs = st.executeQuery(sql);
printRS( rs );ResultSetMetaData rm = rs.getMetaData();
int count = rm.getColumnCount();
assertEquals( "Column count:", colNames.length, count);
for(int i=1; i<=count; i++){
assertEquals("Col "+i+" name", colNames[i-1], rm.getColumnName(i));
assertEquals("Col "+i+" label", colNames[i-1], rm.getColumnLabel(i));
assertEquals("Col "+i+" type", types   [i-1], rm.getColumnType(i));
switch(types[i-1]){
case Types.VARCHAR:
assertTrue  ("Wrong Precision (" + rm.getColumnTypeName(i) + ") for Column "+i+": "+rm.getPrecision(i), rm.getPrecision(i) > 0);
break;
case Types.INTEGER:
assertTrue  ("Wrong Precision (" + rm.getColumnTypeName(i) + ") for Column "+i, rm.getPrecision(i) > 0);
break;
}
}String name = rs.getMetaData().getColumnName(1);
assertEqualsObject( "Values not identical on read:", obj, rs.getObject(name), needTrim);
if(obj instanceof Time){
assertEquals("Time is different:", obj, rs.getTime(name) );
assertEquals("Time String is different:", obj.toString(), rs.getString(name) );
}
if(obj instanceof Timestamp){
assertEquals("Timestamp is different:", obj, rs.getTimestamp(name) );
assertEquals("Timestamp String is different:", obj.toString(), rs.getString(name) );
}
if(obj instanceof Date){
assertEquals("Date is different:", obj, rs.getDate(name) );
assertEquals("Date String is different:", obj.toString(), rs.getString(name) );
}
if(obj instanceof String){
String str = (String)obj;
assertEqualsObject("String is different:", str, rs.getString(name), needTrim );
assertEquals("String Boolean is different:", string2boolean(str), rs.getBoolean(name) );
try{
assertEquals("String Long is different:", Long.parseLong(str), rs.getLong(name) );
}catch(NumberFormatException ex){}
try{
assertEquals("String Integer is different:", Integer.parseInt(str), rs.getInt(name) );
}catch(NumberFormatException ex){}
try{
assertEquals("String Float is different:", Float.parseFloat(str), rs.getFloat(name), 0.0 );
}catch(NumberFormatException ex){}
try{
assertEquals("String Double is different:", Double.parseDouble(str), rs.getDouble(name), 0.0 );
}catch(NumberFormatException ex){}
}
if(obj instanceof BigDecimal){
if(!needTrim){
assertEquals("BigDecimal is different:", obj, rs.getBigDecimal(name) );
assertEquals("Scale is different:", ((BigDecimal)obj).scale(), rs.getMetaData().getScale(1));
}
assertEquals("Scale Meta is different:", rs.getBigDecimal(name).scale(), rs.getMetaData().getScale(1));
BigDecimal big2 = ((BigDecimal)obj).setScale(2,BigDecimal.ROUND_HALF_EVEN);
assertEquals("BigDecimal mit scale is different:", big2, rs.getBigDecimal(name, 2) );
}
if(obj instanceof Integer){
assertEquals("Scale is different:", 0, rs.getMetaData().getScale(1));
}
if(obj instanceof Number){
long longValue = ((Number)obj).longValue();
int intValue = ((Number)obj).intValue();
if(longValue >= Integer.MAX_VALUE)
intValue = Integer.MAX_VALUE;
if(longValue <= Integer.MIN_VALUE)
intValue = Integer.MIN_VALUE;
assertEquals("int is different:", intValue, rs.getInt(name) );
assertEquals("long is different:", longValue, rs.getLong(name) );
if(intValue >= Short.MIN_VALUE && intValue <= Short.MAX_VALUE)
assertEquals("short is different:", (short)intValue, rs.getShort(name) );
if(intValue >= Byte.MIN_VALUE && intValue <= Byte.MAX_VALUE)
assertEquals("byte is different:", (byte)intValue, rs.getByte(name) );
double value = ((Number)obj).doubleValue();
assertEquals("Double is different:", value, rs.getDouble(name),0.0 );
assertEquals("Float is different:", (float)value, rs.getFloat(name),0.0 );
String valueStr = obj.toString();
if(!needTrim){
assertEquals("Number String is different:", valueStr, rs.getString(name) );
}
BigDecimal decimal = Double.isInfinite(value) || Double.isNaN(value) ? null : new BigDecimal(valueStr);
assertEqualsObject("Number BigDecimal is different:", decimal, rs.getBigDecimal(name) );
assertEquals("Number boolean is different:", value != 0, rs.getBoolean(name) );
}
if(obj == null){
assertNull("String is different:", rs.getString(name) );
assertNull("Date is different:", rs.getDate(name) );
assertNull("Time is different:", rs.getTime(name) );
assertNull("Timestamp is different:", rs.getTimestamp(name) );
assertNull("BigDecimal is different:", rs.getBigDecimal(name) );
assertNull("BigDecimal with scale is different:", rs.getBigDecimal(name, 2) );
assertNull("Bytes with scale is different:", rs.getBytes(name) );
assertEquals("Double is different:", 0, rs.getDouble(name),0 );
assertEquals("Float is different:", 0, rs.getFloat(name),0 );
assertEquals("Long is different:", 0, rs.getLong(name) );
assertEquals("Int is different:", 0, rs.getInt(name) );
assertEquals("SmallInt is different:", 0, rs.getShort(name) );
assertEquals("TinyInt is different:", 0, rs.getByte(name) );
assertEquals("Boolean is different:", false, rs.getBoolean(name) );
}
if(obj instanceof byte[]){
assertTrue("Binary should start with 0x", rs.getString(name).startsWith("0x"));
}
ResultSetMetaData metaData = rs.getMetaData();
String className = metaData.getColumnClassName(1);
assertNotNull( "ClassName:", className);
if(obj != null){
Class gotClass = Class.forName(className);
Class objClass = obj.getClass();
String objClassName = objClass.getName();
int expectedLen = metaData.getColumnDisplaySize(1);
if (gotClass.equals(java.sql.Blob.class)) {
assertTrue(
"ClassName assignable: "+className+"<->"+objClassName,
objClass.equals(new byte[0].getClass()));
String message = "Check DisplaySize: " + expectedLen + "!=" + Integer.MAX_VALUE + ")";
assertTrue( message, expectedLen == Integer.MAX_VALUE );
}
else if (gotClass.equals(java.sql.Clob.class)) {
assertTrue(
"ClassName assignable: "+className+"<->"+objClassName,
objClass.equals(String.class));
String message = "Check DisplaySize: " + expectedLen + "!=" + Integer.MAX_VALUE + ")";
assertTrue( message, expectedLen == Integer.MAX_VALUE );
}
else {
String foundStr = rs.getString(name);
assertTrue("ClassName assignable: "+className+"<->"+objClassName, gotClass.isAssignableFrom(objClass));
assertTrue( "DisplaySize to small "+ expectedLen +"<"+foundStr.length()+" (" + foundStr + ")", expectedLen >= foundStr.length() );
}
}return name.replace(',' , ';').replace('(','{');return MONTHS[ordinal - 1];StringBuffer buf = new StringBuffer(bytes.length << 1);
for(int i=0; i<bytes.length; i++){
buf.append( digits[ (bytes[i] >> 4) & 0x0F ] );
buf.append( digits[ (bytes[i]     ) & 0x0F ] );
}
return buf.toString();Connection con = AllTests.getConnection();
Statement st = con.createStatement();
ResultSet rs = st.executeQuery(sql);
assertRowCount(sollCount,rs);try {
Statement st = con.createStatement();
st.execute("drop table "+name);
st.close();
} catch (SQLException e) {
String msg = e.getMessage();
if(msg.indexOf("[SmallSQL]Table")==0 && msg.indexOf(name)>0 && msg.indexOf("can't be dropped.")>0 ){
return;
}
throw e;
}try{
return Double.parseDouble( val ) != 0;
}catch(NumberFormatException e){}
return "true".equalsIgnoreCase( val ) || "yes".equalsIgnoreCase( val ) || "t".equalsIgnoreCase( val );StringWriter sw = new StringWriter();
ex.printStackTrace(new PrintWriter(sw));
assertEquals( "Vendor Errorcode:"+sw, vendorCode, ex.getErrorCode() );
assertEquals( "SQL State:"+sw, sqlstate, ex.getSQLState());int count = rs.getMetaData().getColumnCount();
while(rs.next()){
for(int i=1; i<=count; i++){
System.out.print(rs.getString(i) + '\t');
}
System.out.println();
}System.out.println();
System.out.println( "Test scroll and call the getXXX methods for every columns: " + rowCount + " rows");
try{
Statement st = con.createStatement();
long time = -System.currentTimeMillis();
ResultSet rs = st.executeQuery("SELECT * FROM " + tableName);
for (int i=0; i<rowCount; i++){
rs.next();
rs.getInt   (  1 );
rs.getBytes (  2 );
rs.getString(  3 );
rs.getDate  (  4 );
rs.getFloat (  5 );
rs.getFloat (  6 );
rs.getBytes (  7 );
rs.getInt   (  8 );
rs.getDouble(  9 );
rs.getDouble(  10 );
rs.getFloat (  11 );
rs.getTime  (  12 );
rs.getShort (  13 );
rs.getFloat (  14 );
rs.getString(  15 );
rs.getString(  16 );
rs.getByte  (  17 );
rs.getBytes (  18 );
rs.getString(  19 );
}
time += System.currentTimeMillis();
System.out.println( "  Test time: " + time + " ms");
st.close();
}catch(Exception e){
System.out.println("  Failed:"+e);
}finally{
System.out.println();
System.out.println("===================================================================");
}int pages = 100;
int rows  = rowCount / pages;
System.out.println();
System.out.println( "Test request row pages : " + pages + " pages, " +rows + " rows per page");
try{
Statement st1 = con.createStatement();
ResultSet rs = st1.executeQuery( "SELECT count(*) FROM " + tableName);
rs.next();
int count = rs.getInt(1);
if (count != rowCount){
if (count == 0){
createTestDataWithClassicInsert( con );
rs = st1.executeQuery( "SELECT count(*) FROM " + tableName);
rs.next();
count = rs.getInt(1);
}
if (count != rowCount){
System.out.println( "  Failed: Only " + (rowCount-count) + " rows were found.");
return;
}
}
st1.close();
long time = -System.currentTimeMillis();
Statement st = con.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_READ_ONLY);
st.setFetchSize( rows );
for (int i=0; i<pages; i++){
rs = st.executeQuery("SELECT * FROM " + tableName);
rs.absolute( i*rows+1 );
for (int r=1; r<rows; r++){
if (!rs.next()){
System.out.println( "  Failed: No rows were found at page " + i + " page and row " + r);
return;
}
int col_i = rs.getInt("i");
if (col_i != (i*rows+r)){
System.out.println( "  Failed: Wrong row " + col_i + ", it should be row " + (i*rows+r));
return;
}
}
}
time += System.currentTimeMillis();
System.out.println( "  Test time: " + time + " ms");
st.close();
}catch(Exception e){
System.out.println("  Failed:"+e);
}finally{
System.out.println();
System.out.println("===================================================================");
}String sql = "INSERT INTO " + tableName + "(bi,c,d,de,f,im,i,m,n,r,si,sd,sm,sy,t,ti,vb,vc) VALUES(0x172243,'Test','20010101',1234.56789,9876.54321,0x";
for(int i=0; i<largeByteArray.length; i++){
sql += "00";
}
Statement st = con.createStatement();
for (int i=0; i<rowCount; i++){
st.execute(sql + ","+i+",23.45,567.45,78.89,"+i+",'11:11:11',34.56,'sysname (30) NULL','ntext NULL, sample to save in the field',"+(i & 0xFF)+",0x172243,'nvarchar (255) NULL')"  );
}
st.close();try{
Statement st = con.createStatement();
st.execute("drop table " + tableName);
st.close();
}catch(Exception e){}int batchSize = 10;
int batches = rowCount / batchSize;
System.out.println();
System.out.println( "Test update rows with PreparedStatement and Batches: " + batches + " batches, " + batchSize + " batch size");
try{
PreparedStatement pr = con.prepareStatement( "UPDATE " + tableName + " SET bi=?,c=?,d=?,de=?,f=?,im=?,i=?,m=?,n=?,r=?,sd=?,si=?,sm=?,sy=?,t=?,ti=?,vb=?,vc=? WHERE i=?" );
long time = -System.currentTimeMillis();
for (int i=0; i<batches; i++){
for (int r=0; r<batchSize; r++){
pr.setBytes (  1, byteArray );
pr.setString(  2 , "Test" );
pr.setDate  (  3 , new Date( System.currentTimeMillis() ) );
pr.setFloat (  4, (float)1234.56789 );
pr.setFloat (  5 , (float)9876.54321 );
pr.setBytes (  6, largeByteArray );
pr.setInt   (  7 , i*batchSize + r );
pr.setDouble(  8 , 23.45 );
pr.setDouble(  9 , 567.45 );
pr.setFloat (  10 , (float)78.89 );
pr.setTime  (  11, new Time( System.currentTimeMillis() ) );
pr.setShort (  12, (short)23456 );
pr.setFloat (  13, (float)34.56 );
pr.setString(  14, "sysname (30) NULL" );
pr.setString(  15 , "text NULL" );
pr.setByte  (  16, (byte)28 );
pr.setBytes (  17, byteArray );
pr.setString(  18, "varchar (255) NULL" );
pr.setInt   (  19 , i );
pr.addBatch();
}
int[] updateCount = pr.executeBatch();
if (updateCount.length != batchSize){
System.out.println( "  Failed: Update count size should be " + batchSize + " but it is " + updateCount.length + ".");
return;
}
}
time += System.currentTimeMillis();
System.out.println( "  Test time: " + time + " ms");
pr.close();
}catch(Exception e){
System.out.println("  Failed:"+e);
}finally{
System.out.println();
System.out.println("===================================================================");
}for(int i=0; i<args.length;){
String option = args[i++];
if      (option.equals("-driver")  ) driverClassName = args[i++];
else if (option.equals("-user")    ) userName = args[i++];
else if (option.equals("-password")) password = args[i++];
else if (option.equals("-url")     ) jdbcUrl  = args[i++];
else if (option.equals("-rowcount")) rowCount = Integer.parseInt(args[i++]);
else if (option.equals("-?") | option.equals("-help")){
System.out.println( "Valid options are :\n\t-driver\n\t-url\n\t-user\n\t-password\n\t-rowcount");
System.exit(0);
}
else {System.out.println("Option " + option + " is ignored");i++;}
}
System.out.println( "Driver:  \t" + driverClassName);
System.out.println( "Username:\t" + userName);
System.out.println( "Password:\t" + password);
System.out.println( "JDBC URL:\t" + jdbcUrl);
System.out.println( "Row Count:\t" + rowCount);
System.out.println();
try{
Class.forName(driverClassName).newInstance();
con = DriverManager.getConnection( jdbcUrl, userName,password);
System.out.println( con.getMetaData().getDriverName() + " " + con.getMetaData().getDriverVersion());
System.out.println();
createTestTable( con );
test_InsertClassic( con );
test_DeleteAll( con );
test_InsertEmptyRows( con );
test_DeleteRows( con );
test_InsertRows( con );
test_RowRequestPages( con );
test_UpdateRows( con );
test_UpdateRowsPrepare( con );
test_UpdateRowsPrepareSP( con );
test_UpdateRowsPrepareBatch( con );
test_Scroll_getXXX( con );
test_UpdateLargeBinary( con );
test_UpdateLargeBinaryWithSP( con );
}catch(Exception e){
e.printStackTrace();
}finally{
if (con != null){
con.close();
}
}try{
Statement st = con.createStatement();
st.execute("DELETE FROM " + tableName);
st.close();
}catch(Exception e){}System.out.println();
System.out.println( "Test update large binary data with a SP: " + rowCount + "KB bytes");
try{
java.io.FileOutputStream fos = new java.io.FileOutputStream(tableName+".bin");
byte bytes[] = new byte[1024];
for(int i=0; i<rowCount; i++){
fos.write(bytes);
}
fos.close();
java.io.FileInputStream fis = new java.io.FileInputStream(tableName+".bin");
long time = -System.currentTimeMillis();
Statement st = con.createStatement();
st.execute("CREATE PROCEDURE #UpdateLargeBinary(@im image) as Update " + tableName + " set im=@im WHERE pr=2");
PreparedStatement pr = con.prepareStatement("exec #UpdateLargeBinary ?");
pr.setBinaryStream( 1, fis, rowCount*1024 );
pr.execute();
st.execute("DROP PROCEDURE #UpdateLargeBinary");
st.close();
pr.close();
time += System.currentTimeMillis();
System.out.println( "  Test time: " + time + " ms");
fis.close();
java.io.File file = new java.io.File(tableName+".bin");
file.delete();
}catch(Exception e){
System.out.println("  Failed:"+e);
}finally{
System.out.println();
System.out.println("===================================================================");
}Statement st;
st = con.createStatement();
dropTestTable( con );
st.execute(
"CREATE TABLE " + tableName + " ("+
"    pr  numeric IDENTITY,"+
"    bi  binary (255) NULL ,"+
"    c   nchar (255) NULL ,"+
"    d   datetime NULL ,"+
"    de  decimal(18, 0) NULL ,"+
"    f   float NULL ,"+
"    im  image NULL ,"+
"    i   int NULL ,"+
"    m   money NULL ,"+
"    n   numeric(18, 0) NULL ,"+
"    r   real NULL ,"+
"    sd  smalldatetime NULL ,"+
"    si  smallint NULL ,"+
"    sm  smallmoney NULL ,"+
"    sy  sysname NULL ,"+
"    t   ntext NULL ,"+
"    ti  tinyint NULL ,"+
"    vb  varbinary (255) NULL ,"+
"    vc  nvarchar (255) NULL, "+
"CONSTRAINT PK_BenchTest2 PRIMARY KEY CLUSTERED (pr) "+
")");
st.close();System.out.println();
System.out.println( "Test update large binary data: " + rowCount + "KB bytes");
try{
java.io.FileOutputStream fos = new java.io.FileOutputStream(tableName+".bin");
byte bytes[] = new byte[1024];
for(int i=0; i<rowCount; i++){
fos.write(bytes);
}
fos.close();
java.io.FileInputStream fis = new java.io.FileInputStream(tableName+".bin");
long time = -System.currentTimeMillis();
PreparedStatement pr = con.prepareStatement("Update " + tableName + " set im=? WHERE pr=1");
pr.setBinaryStream( 1, fis, rowCount*1024 );
pr.execute();
pr.close();
time += System.currentTimeMillis();
System.out.println( "  Test time: " + time + " ms");
fis.close();
java.io.File file = new java.io.File(tableName+".bin");
file.delete();
}catch(Exception e){
System.out.println("  Failed:"+e);
}finally{
System.out.println();
System.out.println("===================================================================");
}System.out.println();
System.out.println( "Test insert rows with default values with a classic insert statement: " + rowCount + " rows");
try{
Statement st = con.createStatement( ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_UPDATABLE );
long time = -System.currentTimeMillis();
for (int i=0; i<rowCount; i++){
st.execute("INSERT INTO " + tableName + "(i) VALUES(" + i +")");
}
time += System.currentTimeMillis();
ResultSet rs = st.executeQuery( "SELECT count(*) FROM " + tableName);
rs.next();
int count = rs.getInt(1);
if (count != rowCount)
System.out.println( "  Failed: Only " + count + " rows were inserted.");
else System.out.println( "  Test time: " + time + " ms");
st.close();
}catch(Exception e){
System.out.println("  Failed:"+e);
}finally{
System.out.println();
System.out.println("===================================================================");
}System.out.println();
System.out.println( "Test update rows with a PreparedStatement: " + rowCount + " rows");
try{
PreparedStatement pr = con.prepareStatement( "UPDATE " + tableName + " SET bi=?,c=?,d=?,de=?,f=?,im=?,i=?,m=?,n=?,r=?,sd=?,si=?,sm=?,sy=?,t=?,ti=?,vb=?,vc=? WHERE i=?" );
long time = -System.currentTimeMillis();
for (int i=0; i<rowCount; i++){
pr.setBytes (  1, byteArray );
pr.setString(  2 , "Test" );
pr.setDate  (  3 , new Date( System.currentTimeMillis() ) );
pr.setFloat (  4, (float)1234.56789 );
pr.setFloat (  5 , (float)9876.54321 );
pr.setBytes (  6, largeByteArray );
pr.setInt   (  7 , i );
pr.setDouble(  8 , 23.45 );
pr.setDouble(  9 , 567.45 );
pr.setFloat (  10 , (float)78.89 );
pr.setTime  (  11, new Time( System.currentTimeMillis() ) );
pr.setShort (  12, (short)23456 );
pr.setFloat (  13, (float)34.56 );
pr.setString(  14, "sysname (30) NULL" );
pr.setString(  15 , "text NULL" );
pr.setByte  (  16, (byte)28 );
pr.setBytes (  17, byteArray );
pr.setString(  18, "varchar (255) NULL" );
pr.setInt   (  19 , i );
int updateCount = pr.executeUpdate();
if (updateCount != 1){
System.out.println( "  Failed: Update count should be 1 but it is " + updateCount + ".");
return;
}
}
time += System.currentTimeMillis();
System.out.println( "  Test time: " + time + " ms");
pr.close();
}catch(Exception e){
System.out.println("  Failed:"+e);
}finally{
System.out.println();
System.out.println("===================================================================");
}System.out.println();
System.out.println( "Test delete rows with deleteRow(): " + rowCount + " rows");
try{
Statement st1 = con.createStatement();
ResultSet rs = st1.executeQuery( "SELECT count(*) FROM " + tableName);
rs.next();
int count = rs.getInt(1);
if (count != rowCount){
if (count == 0){
createTestDataWithClassicInsert( con );
rs = st1.executeQuery( "SELECT count(*) FROM " + tableName);
rs.next();
count = rs.getInt(1);
}
if (count != rowCount){
System.out.println( "  Failed: Only " + (rowCount-count) + " rows were deleted.");
return;
}
}
st1.close();
Statement st = con.createStatement( ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_UPDATABLE );
rs = st.executeQuery("SELECT * FROM "+tableName);
long time = -System.currentTimeMillis();
for (int i=0; i<rowCount; i++){
rs.next();
rs.deleteRow();
}
time += System.currentTimeMillis();
rs = st.executeQuery( "SELECT count(*) FROM " + tableName);
rs.next();
count = rs.getInt(1);
if (count != 0)
System.out.println( "  Failed: Only " + (rowCount-count) + " rows were deleted.");
else System.out.println( "  Test time: " + time + " ms");
st.close();
}catch(Exception e){
System.out.println("  Failed:"+e);
}finally{
System.out.println();
System.out.println("===================================================================");
}System.out.println();
System.out.println( "Test insert empty rows with insertRow(): " + rowCount + " rows");
try{
Statement st = con.createStatement( ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_UPDATABLE );
ResultSet rs = st.executeQuery("SELECT * FROM "+tableName);
long time = -System.currentTimeMillis();
for (int i=0; i<rowCount; i++){
rs.moveToInsertRow();
rs.insertRow();
}
time += System.currentTimeMillis();
rs = st.executeQuery( "SELECT count(*) FROM " + tableName);
rs.next();
int count = rs.getInt(1);
if (count != rowCount)
System.out.println( "  Failed: Only " + count + " rows were inserted.");
else System.out.println( "  Test time: " + time + " ms");
st.close();
}catch(Exception e){
System.out.println("  Failed:"+e);
}finally{
System.out.println();
System.out.println("===================================================================");
}System.out.println();
System.out.println( "Test delete all rows: " + rowCount + " rows");
try{
long time = -System.currentTimeMillis();
Statement st = con.createStatement();
st.execute("DELETE FROM " + tableName);
time += System.currentTimeMillis();
System.out.println( "  Test time: " + time + " ms");
st.close();
}catch(Exception e){
System.out.println("  Failed:"+e);
}finally{
System.out.println();
System.out.println("===================================================================");
}System.out.println();
System.out.println( "Test update rows with updateRow(): " + rowCount + " rows");
try{
Statement st = con.createStatement( ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_UPDATABLE );
ResultSet rs = st.executeQuery("SELECT * FROM " + tableName);
int colCount = rs.getMetaData().getColumnCount();
long time = -System.currentTimeMillis();
int count = 0;
while(rs.next()){
for (int i=2; i<=colCount; i++){
rs.updateObject( i, rs.getObject(i) );
}
rs.updateRow();
count++;
}
time += System.currentTimeMillis();
if (count != rowCount)
System.out.println( "  Failed: Only " + count + " rows were updated.");
else System.out.println( "  Test time: " + time + " ms");
st.close();
}catch(Exception e){
System.out.println("  Failed:" + e);
}finally{
System.out.println();
System.out.println("===================================================================");
}System.out.println();
System.out.println( "Test update rows with a PreparedStatement and a stored procedure: " + rowCount + " rows");
try{
Statement st = con.createStatement();
try{st.execute("drop procedure sp_"+tableName);}catch(Exception e){}
st.execute("create procedure sp_"+tableName+" (@bi binary,@c nchar(255),@d datetime,@de decimal,@f float,@im image,@i int,@m money,@n numeric(18, 0),@r real,@sd smalldatetime,@si smallint,@sm smallmoney,@sy sysname,@t ntext,@ti tinyint,@vb varbinary(255),@vc nvarchar(255)) as UPDATE " + tableName + " SET bi=@bi,c=@c,d=@d,de=@de,f=@f,im=@im,i=@i,m=@m,n=@n,r=@r,sd=@sd,si=@si,sm=@sm,sy=@sy,t=@t,ti=@ti,vb=@vb,vc=@vc WHERE i=@i");
PreparedStatement pr = con.prepareStatement( "exec sp_" + tableName + " ?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?" );
long time = -System.currentTimeMillis();
for (int i=0; i<rowCount; i++){
pr.setBytes (  1, byteArray );
pr.setString(  2 , "Test" );
pr.setDate  (  3 , new Date( System.currentTimeMillis() ) );
pr.setFloat (  4, (float)1234.56789 );
pr.setFloat (  5 , (float)9876.54321 );
pr.setBytes (  6, largeByteArray );
pr.setInt   (  7 , i );
pr.setDouble(  8 , 23.45 );
pr.setDouble(  9 , 567.45 );
pr.setFloat (  10 , (float)78.89 );
pr.setTime  (  11, new Time( System.currentTimeMillis() ) );
pr.setShort (  12, (short)23456 );
pr.setFloat (  13, (float)34.56 );
pr.setString(  14, "sysname (30) NULL" );
pr.setString(  15 , "text NULL" );
pr.setByte  (  16, (byte)28 );
pr.setBytes (  17, byteArray );
pr.setString(  18, "varchar (255) NULL" );
int updateCount = pr.executeUpdate();
if (updateCount != 1){
System.out.println( "  Failed: Update count should be 1 but it is " + updateCount + ".");
return;
}
}
time += System.currentTimeMillis();
System.out.println( "  Test time: " + time + " ms");
st.execute("drop procedure sp_"+tableName);
st.close();
pr.close();
}catch(Exception e){
System.out.println("  Failed:"+e);
}finally{
System.out.println();
System.out.println("===================================================================");
}System.out.println();
System.out.println( "Test insert rows with insertRow(): " + rowCount + " rows");
try{
Statement st = con.createStatement( ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_UPDATABLE );
ResultSet rs = st.executeQuery("SELECT * FROM " + tableName);
long time = -System.currentTimeMillis();
for (int i=0; i<rowCount; i++){
rs.moveToInsertRow();
rs.updateBytes (  "bi", byteArray );
rs.updateString(  "c" , "Test" );
rs.updateDate  (  "d" , new Date( System.currentTimeMillis() ) );
rs.updateFloat (  "de", (float)1234.56789 );
rs.updateFloat (  "f" , (float)9876.54321 );
rs.updateBytes (  "im", largeByteArray );
rs.updateInt   (  "i" , i );
rs.updateDouble(  "m" , 23.45 );
rs.updateDouble(  "n" , 567.45 );
rs.updateFloat (  "r" , (float)78.89 );
rs.updateTime  (  "sd", new Time( System.currentTimeMillis() ) );
rs.updateShort (  "si", (short)i );
rs.updateFloat (  "sm", (float)34.56 );
rs.updateString(  "sy", "sysname (30) NULL" );
rs.updateString(  "t" , "ntext NULL, sample to save in the field" );
rs.updateByte  (  "ti", (byte)i );
rs.updateBytes (  "vb", byteArray );
rs.updateString(  "vc", "nvarchar (255) NULL" );
rs.insertRow();
}
time += System.currentTimeMillis();
rs = st.executeQuery( "SELECT count(*) FROM " + tableName);
rs.next();
int count = rs.getInt(1);
if (count != rowCount){
st.execute("DELETE FROM " + tableName);
System.out.println( "  Failed: Only " + count + " rows were inserted.");
}else System.out.println( "  Test time: " + time + " ms");
st.close();
}catch(Exception e){
e.printStackTrace();
try{
Statement st = con.createStatement();
st.execute("DELETE FROM " + tableName);
st.close();
}catch(Exception ee){}
System.out.println("  Failed:"+e);
}finally{
System.out.println();
System.out.println("===================================================================");
}Connection con = AllTests.getConnection();
Statement st = con.createStatement();
st.execute("Alter Table " + table + " Add a Varchar(20), b int DEFAULT 25");
ResultSet rs = st.executeQuery("Select * From " + table);
assertRSMetaData( rs, new String[]{"i", "v", "a", "b"},  new int[]{Types.INTEGER, Types.VARCHAR, Types.VARCHAR, Types.INTEGER} );
int count = 0;
while(rs.next()){
assertEquals( "default value", 25, rs.getInt("b") );
count++;
}
assertEquals( "RowCount", rowCount, count );try {
dropTable( AllTests.getConnection(), table );
} catch (SQLException ex) {
ex.printStackTrace();
}Connection con = AllTests.getConnection();
Statement st = con.createStatement();
st.execute("Alter Table " + table + " Add a Varchar(20)");
ResultSet rs = st.executeQuery("Select * From " + table);
assertRSMetaData( rs, new String[]{"i", "v", "a"},  new int[]{Types.INTEGER, Types.VARCHAR, Types.VARCHAR} );tearDown();
try{
Connection con = AllTests.getConnection();
Statement st = con.createStatement();
st.execute("create table " + table + "(i int, v varchar(100))");
st.execute("Insert into " + table + " Values(1,'abc')");
st.execute("Insert into " + table + " Values(2,'bcd')");
st.execute("Insert into " + table + " Values(3,'cde')");
st.execute("Insert into " + table + " Values(4,'def')");
st.execute("Insert into " + table + " Values(5,'efg')");
st.execute("Insert into " + table + " Values(6,'fgh')");
st.execute("Insert into " + table + " Values(7,'ghi')");
st.execute("Insert into " + table + " Values(8,'hij')");
st.execute("Insert into " + table + " Values(9,'ijk')");
st.execute("Insert into " + table + " Values(10,'jkl')");
st.close();
}catch(Throwable e){
e.printStackTrace();
}Connection con = AllTests.getConnection();
Statement st = con.createStatement();
int isolation = con.getTransactionIsolation();
con.setAutoCommit(false);
try{
con.setTransactionIsolation( Connection.TRANSACTION_REPEATABLE_READ );
ResultSet rs = st.executeQuery("Select * From " + table);
rs.next();
try {
st.execute("Alter Table " + table + " Add a Varchar(20)");
fail("Alter Table should not work on a table with a lock.");
} catch (SQLException ex) {
assertSQLException( "01000", 0, ex );
}
rs.next();
}finally{
con.setTransactionIsolation(isolation);
con.setAutoCommit(true);
}Connection con = AllTests.getConnection();
Statement st = con.createStatement();
int isolation = con.getTransactionIsolation();
con.setAutoCommit(false);
try{
con.setTransactionIsolation( Connection.TRANSACTION_READ_COMMITTED );
ResultSet rs = st.executeQuery("Select * From " + table);
rs.next();
st.execute("Alter Table " + table + " Add a Varchar(20)");
try {
rs.next();
fail("Alter Table should not work on a table with a lock.");
} catch (SQLException ex) {
assertSQLException( "01000", 0, ex );
}
}finally{
con.setTransactionIsolation(isolation);
con.setAutoCommit(true);
}try {
dropTable( AllTests.getConnection(), table );
} catch (SQLException ex) {
ex.printStackTrace();
}Connection con = AllTests.getConnection();
Statement st = con.createStatement();
st.execute("create table "+table+" (a varchar(2) unique)");
st.execute("alter table "+table+" add b varchar(4) primary key");
ResultSet rs = st.executeQuery("Select * From " + table);
assertRSMetaData( rs, new String[]{"a", "b"},  new int[]{Types.VARCHAR, Types.VARCHAR} );
rs = con.getMetaData().getIndexInfo( null, null, table, false, false );
assertRowCount( 2, rs );tearDown();Connection con = AllTests.getConnection();
Statement st = con.createStatement();
st.execute("create table "+table+" (a varchar(2) primary key)");
try {
st.execute("alter table "+table+" add b varchar(4) primary key");
fail("2 primary keys are invalid");
} catch (SQLException ex) {
assertSQLException("01000",0, ex);
}
ResultSet rs = st.executeQuery("Select * From " + table);
assertRSMetaData( rs, new String[]{"a"},  new int[]{Types.VARCHAR} );
rs = con.getMetaData().getIndexInfo( null, null, table, false, false );
assertRowCount( 1, rs );Connection con = AllTests.getConnection();
Statement st = con.createStatement();
st.execute("create table "+table+" (keyField varchar(2) primary key)");
st.execute("alter table "+table+" add anotherField varchar(4)");
ResultSet rs = st.executeQuery("Select * From " + table);
assertRSMetaData( rs, new String[]{"keyField", "anotherField"},  new int[]{Types.VARCHAR, Types.VARCHAR} );
rs = con.getMetaData().getIndexInfo( null, null, table, false, false );
assertRowCount( 1, rs );Connection con = AllTests.getConnection();
Statement st = con.createStatement();
st.execute("create table "+table+" (a varchar(2))");
st.execute("alter table "+table+" add b varchar(4) primary key");
ResultSet rs = st.executeQuery("Select * From " + table);
assertRSMetaData( rs, new String[]{"a", "b"},  new int[]{Types.VARCHAR, Types.VARCHAR} );
rs = con.getMetaData().getIndexInfo( null, null, table, false, false );
assertRowCount( 1, rs );Connection con = AllTests.getConnection();
DatabaseMetaData md = con.getMetaData();
ResultSet rs = md.getTableTypes();
String[] colNames = {"TABLE_TYPE"};
int[] colTypes = {Types.VARCHAR};
assertRSMetaData( rs, colNames, colTypes);
String type = "";
int count = 0;
while(rs.next()){
String type2 = rs.getString("TABLE_TYPE");
assertTrue( type+"-"+type2, type.compareTo(type2)<0);
type = type2;
count++;
}
assertEquals("Table Type Count", 3, count);Connection con = AllTests.getConnection();
DatabaseMetaData md = con.getMetaData();
assertEquals( "getNumericFunctions", "ABS,ACOS,ASIN,ATAN,ATAN2,CEILING,COS,COT,DEGREES,EXP,FLOOR,LOG,LOG10,MOD,PI,POWER,RADIANS,RAND,ROUND,SIGN,SIN,SQRT,TAN,TRUNCATE",
md.getNumericFunctions());
assertEquals( "getStringFunctions", "ASCII,BIT_LENGTH,CHAR_LENGTH,CHARACTER_LENGTH,CHAR,CONCAT,DIFFERENCE,INSERT,LCASE,LEFT,LENGTH,LOCATE,LTRIM,OCTET_LENGTH,REPEAT,REPLACE,RIGHT,RTRIM,SOUNDEX,SPACE,SUBSTRING,TRIM,UCASE",
md.getStringFunctions());
assertEquals( "getStringFunctions", "IFNULL,USER,CONVERT,CAST,IIF",
md.getSystemFunctions());
assertEquals( "getStringFunctions", "CURDATE,CURRENT_DATE,CURTIME,DAYNAME,DAYOFMONTH,DAYOFWEEK,DAYOFYEAR,DAY,HOUR,MILLISECOND,MINUTE,MONTH,MONTHNAME,NOW,QUARTER,SECOND,TIMESTAMPADD,TIMESTAMPDIFF,WEEK,YEAR",
md.getTimeDateFunctions());String[] colNames = {"TABLE_CAT","TABLE_SCHEM","TABLE_NAME","TABLE_TYPE","REMARKS","TYPE_CAT","TYPE_SCHEM","TYPE_NAME","SELF_REFERENCING_COL_NAME","REF_GENERATION"};
int[] types = {Types.VARCHAR, Types.NULL, Types.VARCHAR, Types.VARCHAR, Types.NULL, Types.NULL, Types.NULL, Types.NULL, Types.NULL, Types.NULL};
Connection con = DriverManager.getConnection("jdbc:smallsql?");
DatabaseMetaData md = con.getMetaData();
ResultSet rs = md.getTables(null, null, null, null);
super.assertRSMetaData(rs, colNames, new int[colNames.length]);
assertFalse(rs.next());
con.close();
con = AllTests.getConnection();
md = con.getMetaData();
rs = md.getTables(null, null, null, null);
super.assertRSMetaData(rs, colNames, types);Connection con = AllTests.getConnection();
dropTable(con,"tableColumns");
dropView( con, "viewColumns");
con.createStatement().execute("create table tableColumns(a int default 5)");
DatabaseMetaData md = con.getMetaData();
ResultSet rs = md.getColumns(null, null, "tableColumns", null);
String[] colNames = {"TABLE_CAT", "TABLE_SCHEM", "TABLE_NAME", "COLUMN_NAME", "DATA_TYPE", "TYPE_NAME", "COLUMN_SIZE", "BUFFER_LENGTH", "DECIMAL_DIGITS", "NUM_PREC_RADIX", "NULLABLE", "REMARKS", "COLUMN_DEF", "SQL_DATA_TYPE", "SQL_DATETIME_SUB", "CHAR_OCTET_LENGTH", "ORDINAL_POSITION", "IS_NULLABLE"};
int[] colTypes = {Types.VARCHAR, Types.NULL, Types.VARCHAR, Types.VARCHAR, Types.SMALLINT, Types.VARCHAR, Types.INTEGER, Types.NULL, Types.INTEGER, Types.INTEGER, Types.INTEGER, Types.NULL, Types.VARCHAR, Types.NULL, Types.NULL, Types.INTEGER, Types.INTEGER, Types.VARCHAR};
assertRSMetaData( rs, colNames, colTypes);
assertTrue( "No row", rs.next() );
assertEquals( "a", rs.getObject("COLUMN_NAME") );
assertEquals( "INT", rs.getObject("TYPE_NAME") );
assertEquals( "5", rs.getObject("COLUMN_Def") );
con.createStatement().execute("create view viewColumns as Select * from tableColumns");
rs = md.getColumns(null, null, "viewColumns", null);
assertRSMetaData( rs, colNames, colTypes);
assertTrue( "No row", rs.next() );
assertEquals( "a", rs.getObject("COLUMN_NAME") );
assertEquals( "INT", rs.getObject("TYPE_NAME") );
assertEquals( "5", rs.getObject("COLUMN_Def") );
dropView( con, "viewColumns");
dropTable( con, "tableColumns");Connection con = AllTests.getConnection();
DatabaseMetaData md = con.getMetaData();
assertEquals(con, md.getConnection());Connection con = AllTests.getConnection();
DatabaseMetaData md = con.getMetaData();
ResultSet rs = md.getSchemas();
String[] colNames = {"TABLE_SCHEM"};
int[] colTypes = {Types.NULL};
assertRSMetaData( rs, colNames, colTypes);
assertFalse(rs.next());Connection con = AllTests.getConnection();
DatabaseMetaData md = con.getMetaData();
ResultSet rs = md.getTypeInfo();
String[] colNames = {"TYPE_NAME", "DATA_TYPE", "PRECISION", "LITERAL_PREFIX", "LITERAL_SUFFIX", "CREATE_PARAMS", "NULLABLE", "CASE_SENSITIVE", "SEARCHABLE", "UNSIGNED_ATTRIBUTE", "FIXED_PREC_SCALE", "AUTO_INCREMENT", "LOCAL_TYPE_NAME", "MINIMUM_SCALE", "MAXIMUM_SCALE", "SQL_DATA_TYPE", "SQL_DATETIME_SUB", "NUM_PREC_RADIX"};
int[] colTypes = {Types.VARCHAR, Types.SMALLINT, Types.INTEGER, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.SMALLINT, Types.BOOLEAN, Types.SMALLINT, Types.BOOLEAN, Types.BOOLEAN, Types.BOOLEAN, Types.NULL, Types.INTEGER, Types.INTEGER, Types.NULL, Types.NULL, Types.NULL };
assertRSMetaData(rs, colNames, colTypes);
assertTrue(rs.next());
int lastDataType = rs.getInt("data_type");
while(rs.next()){
int dataType = rs.getInt("data_type");
assertTrue("Wrong sorting order", dataType>=lastDataType );
lastDataType = dataType;
}Connection con = AllTests.getConnection();
dropTable(con,"tblBestRow1");
DatabaseMetaData md = con.getMetaData();
Statement st = con.createStatement();
st.execute("Create Table tblBestRow1(id1 counter primary key, v nvarchar(100))");
String[] colNames = {"SCOPE", "COLUMN_NAME", "DATA_TYPE", "TYPE_NAME", "COLUMN_SIZE", "BUFFER_LENGTH", "DECIMAL_DIGITS", "PSEUDO_COLUMN"};
int[] colTypes = {Types.SMALLINT, Types.VARCHAR, Types.INTEGER, Types.VARCHAR, Types.INTEGER, Types.NULL, Types.SMALLINT, Types.SMALLINT};
ResultSet rs = md.getBestRowIdentifier(null, null, "tblBestRow1", DatabaseMetaData.bestRowSession, true);
assertRSMetaData(rs, colNames, colTypes);
assertTrue(rs.next());
assertEquals("Columnname:", "id1", rs.getString("COLUMN_NAME"));
assertFalse(rs.next());
String[] colNames2 = {"TABLE_CAT", "TABLE_SCHEM", "TABLE_NAME", "COLUMN_NAME", "KEY_SEQ", "PK_NAME"};
int[] colTypes2 = {Types.VARCHAR, Types.NULL, Types.VARCHAR, Types.VARCHAR, Types.SMALLINT, Types.VARCHAR};
rs = md.getPrimaryKeys(null, null, "tblBestRow1");
assertRSMetaData(rs, colNames2, colTypes2);
assertTrue(rs.next());
assertEquals("Columnname:", "id1", rs.getString("COLUMN_NAME"));
assertFalse(rs.next());
String[] colNames3 = {"TABLE_CAT", "TABLE_SCHEM", "TABLE_NAME", "NON_UNIQUE", "INDEX_QUALIFIER", "INDEX_NAME", "TYPE", "ORDINAL_POSITION", "COLUMN_NAME", "ASC_OR_DESC", "CARDINALITY", "PAGES", "FILTER_CONDITION"};
int[] colTypes3 = {Types.VARCHAR, Types.NULL, Types.VARCHAR, Types.BOOLEAN, Types.NULL, Types.VARCHAR, Types.SMALLINT, Types.SMALLINT, Types.VARCHAR, Types.NULL, Types.NULL, Types.NULL, Types.NULL};
rs = md.getIndexInfo(null, null, "tblBestRow1", true, true);
assertRSMetaData(rs, colNames3, colTypes3);
assertTrue(rs.next());
assertEquals("Columnname:", "id1", rs.getString("COLUMN_NAME"));
assertFalse(rs.next());
dropTable(con,"tblBestRow1");Connection con = AllTests.getConnection();
DatabaseMetaData md = con.getMetaData();
assertEquals( "URL", AllTests.JDBC_URL, md.getURL());Connection con = AllTests.getConnection();
dropTable(con,"tblCross1");
dropTable(con,"tblCross2");
DatabaseMetaData md = con.getMetaData();
Statement st = con.createStatement();
st.execute("Create Table tblCross1(id1 counter primary key, v nvarchar(100))");
st.execute("Create Table tblCross2(id2 int , v nvarchar(100), foreign key (id2) REFERENCES tblCross1(id1))");
String[] colNames = {"PKTABLE_CAT", "PKTABLE_SCHEM", "PKTABLE_NAME", "PKCOLUMN_NAME", "FKTABLE_CAT", "FKTABLE_SCHEM", "FKTABLE_NAME", "FKCOLUMN_NAME", "KEY_SEQ", "UPDATE_RULE", "DELETE_RULE", "FK_NAME", "PK_NAME", "DEFERRABILITY"};
int[] colTypes = {Types.VARCHAR, Types.NULL, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.NULL, Types.VARCHAR, Types.VARCHAR, Types.SMALLINT, Types.SMALLINT, Types.SMALLINT, Types.VARCHAR, Types.VARCHAR, Types.SMALLINT };
ResultSet rs = md.getCrossReference(null,null,"tblCross1",null,null,"tblCross2");
assertRSMetaData(rs, colNames, colTypes);
assertTrue(rs.next());
assertFalse(rs.next());
rs = md.getImportedKeys(null,null,"tblCross2");
assertRSMetaData(rs, colNames, colTypes);
assertTrue(rs.next());
assertFalse(rs.next());
rs = md.getExportedKeys(null,null,"tblCross1");
assertRSMetaData(rs, colNames, colTypes);
assertTrue(rs.next());
assertFalse(rs.next());
dropTable(con,"tblCross1");
dropTable(con,"tblCross2");Connection con = AllTests.getConnection();
DatabaseMetaData md = con.getMetaData();
ResultSet rs = md.getUDTs(null, null, null, null);
String[] colNames = {"TYPE_CAT", "TYPE_SCHEM", "TYPE_NAME", "CLASS_NAME", "DATA_TYPE", "REMARKS"};
int[] colTypes = new int[colNames.length];
assertRSMetaData( rs, colNames, colTypes);
assertFalse(rs.next());Connection con = AllTests.getConnection();
try{
con.createStatement().execute("drop database test2\n\r\t");
}catch(SQLException e){}
con.createStatement().execute("create database test2");
DatabaseMetaData md = con.getMetaData();
ResultSet rs = md.getCatalogs();
assertRSMetaData( rs, new String[]{"TABLE_CAT"}, new int[]{Types.VARCHAR});
while(rs.next()){
System.out.println( "testCatalogs:"+rs.getObject(1) );
}Connection con = AllTests.getConnection();
DatabaseMetaData md = con.getMetaData();
assertEquals( "DriverVersion", md.getDriverVersion(), md.getDatabaseProductVersion());
Driver driver = DriverManager.getDriver(AllTests.JDBC_URL);
assertEquals( "MajorVersion", driver.getMajorVersion(), md.getDatabaseMajorVersion());
assertEquals( "MajorVersion", driver.getMajorVersion(), md.getDriverMajorVersion());
assertEquals( "MinorVersion", driver.getMinorVersion(), md.getDatabaseMinorVersion());
assertEquals( "MinorVersion", driver.getMinorVersion(), md.getDriverMinorVersion());
assertEquals( "Version", new DecimalFormat("###0.00", new DecimalFormatSymbols(Locale.US)).format(driver.getMajorVersion()+driver.getMinorVersion()/100.0), md.getDriverVersion());
assertTrue( "jdbcCompliant", driver.jdbcCompliant() );Connection con = AllTests.getConnection();
DatabaseMetaData md = con.getMetaData();
ResultSet rs = md.getProcedureColumns( null, null, "*", null);
String[] colNames = {"PROCEDURE_CAT", "PROCEDURE_SCHEM", "PROCEDURE_NAME", "COLUMN_NAME", "COLUMN_TYPE", "DATA_TYPE", "TYPE_NAME", "PRECISION", "LENGTH", "SCALE", "RADIX", "NULLABLE", "REMARKS" };
int[] colTypes = {Types.NULL, Types.NULL, Types.NULL, Types.NULL, Types.NULL, Types.NULL, Types.NULL, Types.NULL, Types.NULL, Types.NULL, Types.NULL, Types.NULL, Types.NULL };
assertRSMetaData( rs, colNames, colTypes);Connection con = AllTests.getConnection();
DatabaseMetaData md = con.getMetaData();
ResultSet rs = md.getProcedures( null, null, "*");
String[] colNames = {"PROCEDURE_CAT", "PROCEDURE_SCHEM", "PROCEDURE_NAME", "", "", "", "REMARKS", "PROCEDURE_TYPE"};
int[] colTypes = {Types.NULL, Types.NULL, Types.NULL, Types.NULL, Types.NULL, Types.NULL, Types.NULL, Types.NULL };
assertRSMetaData( rs, colNames, colTypes);TestSuite theSuite = new TestSuite("Data Types");
for(int i=0; i<DATATYPES.length; i++){
theSuite.addTest(new TestDataTypes( DATATYPES[i] ) );
}
return theSuite;junit.swingui.TestRunner.main(new String[]{TestDataTypes.class.getName()});Connection con = AllTests.getConnection();
Statement st = con.createStatement();
st.execute("Create Table " + table +"(abc " + datatype + ")");
String name = "abc";
Object[] values = null;
String   quote = "";
String escape1 = "";
String escape2 = "";
boolean needTrim = false;
ResultSet rs = st.executeQuery("SELECT * From " + table);
ResultSetMetaData md = rs.getMetaData();
switch(md.getColumnType(1)){
case Types.CHAR:
needTrim = true;
case Types.VARCHAR:
case Types.LONGVARCHAR:
case Types.CLOB:
values = new Object[]{null,"qwert", "asdfg", "hjhjhj", "1234567890 qwertzuiop 1234567890 asdfghjklö 1234567890 yxcvbnm,.- 1234567890 "};
quote  = "\'";
break;
case Types.BIGINT:
values = new Object[]{null,new Long(123), new Long(-2123), new Long(392839283)};
break;
case Types.INTEGER:
values = new Object[]{null,new Integer(123), new Integer(-2123), new Integer(392839283)};
break;
case Types.SMALLINT:
values = new Object[]{null,new Integer(123), new Integer(-2123), new Integer(32000)};
break;
case Types.TINYINT:
values = new Object[]{null,new Integer(0), new Integer(12), new Integer(228)};
break;
case Types.REAL:
values = new Object[]{null,new Float(0.0), new Float(-12.123), new Float(22812345234.9)};
break;
case Types.FLOAT:
case Types.DOUBLE:
values = new Object[]{null,new Double(0.0), new Double(-12.123), new Double(22812345234.9)};
break;
case Types.NUMERIC:
case Types.DECIMAL:
needTrim = true;
if(md.getPrecision(1)<16){
values = new Object[]{null,new BigDecimal("0.0"), new BigDecimal("-2"), new BigDecimal("-12.123")};
}else{
values = new Object[]{null,new BigDecimal("0.0"), new BigDecimal("-2"), new BigDecimal("-12.123"), new BigDecimal("22812345234.9")};
}
break;
case Types.BIT:
case Types.BOOLEAN:
values = new Object[]{null, Boolean.TRUE, Boolean.FALSE};
break;
case Types.TIME:
values = new Object[]{null, new Time(10,17,56), new Time(0,0,0),new Time(23,59,59)};
escape1 = "{t '";
escape2 = "'}";
break;
case Types.DATE:
values = new Object[]{null, new java.sql.Date(10,10,1), new java.sql.Date(0,0,1),new java.sql.Date(70,0,1)};
escape1 = "{d '";
escape2 = "'}";
break;
case Types.TIMESTAMP:
if(md.getPrecision(1) >16)
values = new Object[]{null, new Timestamp(10,10,1, 10,17,56, 0), new Timestamp(0,0,1, 0,0,0, 0),new Timestamp( 120,1,1, 23,59,59, 500000000),new Timestamp(0),new Timestamp( -120,1,1, 23,59,59, 500000000)};
else
values = new Object[]{null, new Timestamp(10,10,1, 10,17,0, 0), new Timestamp(0,0,1, 0,0,0, 0),new Timestamp(0)};
escape1 = "{ts '";
escape2 = "'}";
break;
case Types.BINARY:
needTrim = true;
case Types.VARBINARY:
case Types.LONGVARBINARY:
case Types.BLOB:
values = new Object[]{null, new byte[]{1, 127, -23}};
break;
case Types.JAVA_OBJECT:
values = new Object[]{null, new Integer(-123), new Double(1.2), new byte[]{1, 127, -23}};
break;
case -11:
values = new Object[]{null, "342734E3-D9AC-408F-8724-B7A257C4529E", "342734E3-D9AC-408F-8724-B7A257C4529E"};
quote  = "\'";
break;
default: fail("Unknown column type: " + rs.getMetaData().getColumnType(1));
}
rs.close();
con.close();
con = AllTests.getConnection();
st = con.createStatement();
for(int i=0; i<values.length; i++){
Object val = values[i];
String q = (val == null) ? "" : quote;
String e1 = (val == null) ? "" : escape1;
String e2 = (val == null) ? "" : escape2;
if(val instanceof byte[]){
StringBuffer buf = new StringBuffer( "0x" );
for(int k=0; k<((byte[])val).length; k++){
String digit = "0" + Integer.toHexString( ((byte[])val)[k] );
buf.append( digit.substring( digit.length()-2 ) );
}
val = buf.toString();
}
st.execute("Insert into " + table + "(abc) Values(" + e1 + q + val + q + e2 + ")");
}
checkValues( st, values, needTrim);
st.execute("Delete From "+ table);
CallableStatement cal = con.prepareCall("Insert Into " + table + "(abc) Values(?)");
for(int i=0; i<values.length; i++){
Object val = values[i];
cal.setObject( 1, val);
cal.execute();
}
cal.close();
checkValues( st, values, needTrim);
st.execute("Delete From "+ table);
cal = con.prepareCall("Insert Into " + table + "(abc) Values(?)");
for(int i=0; i<values.length; i++){
Object val = values[i];
if(val == null){
cal.setNull( 1, Types.NULL );
}else
if(val instanceof Time){
cal.setTime( 1, (Time)val );
}else
if(val instanceof Timestamp){
cal.setTimestamp( 1, (Timestamp)val );
}else
if(val instanceof Date){
cal.setDate( 1, (Date)val );
}else
if(val instanceof String){
cal.setString( 1, (String)val );
}else
if(val instanceof Boolean){
cal.setBoolean( 1, ((Boolean)val).booleanValue() );
}else
if(val instanceof Byte){
cal.setByte( 1, ((Byte)val).byteValue() );
}else
if(val instanceof Short){
cal.setShort( 1, ((Short)val).shortValue() );
}else
if(val instanceof Integer){
cal.setInt( 1, ((Integer)val).intValue() );
}else
if(val instanceof Long){
cal.setLong( 1, ((Long)val).longValue() );
}else
if(val instanceof Float){
cal.setFloat( 1, ((Float)val).floatValue() );
}else
if(val instanceof Double){
cal.setDouble( 1, ((Double)val).doubleValue() );
}else
if(val instanceof BigDecimal){
cal.setBigDecimal( 1, (BigDecimal)val );
}else
if(val instanceof byte[]){
cal.setBytes( 1, (byte[])val );
}
cal.execute();
}
cal.close();
checkValues( st, values, needTrim);
st.execute("Delete From "+ table);
Statement st2 = con.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_UPDATABLE);
ResultSet rs2 = st2.executeQuery("SELECT * From " + table);
for(int i=0; i<values.length; i++){
rs2.moveToInsertRow();
Object val = values[i];
if(val == null){
rs2.updateNull( name );
}else
if(val instanceof Time){
rs2.updateTime( name, (Time)val );
}else
if(val instanceof Timestamp){
rs2.updateTimestamp( name, (Timestamp)val );
}else
if(val instanceof Date){
rs2.updateDate( name, (Date)val );
}else
if(val instanceof String){
rs2.updateString( name, (String)val );
}else
if(val instanceof Boolean){
rs2.updateBoolean( name, ((Boolean)val).booleanValue() );
}else
if(val instanceof Byte){
rs2.updateByte( name, ((Byte)val).byteValue() );
}else
if(val instanceof Short){
rs2.updateShort( name, ((Short)val).shortValue() );
}else
if(val instanceof Integer){
rs2.updateInt( name, ((Integer)val).intValue() );
}else
if(val instanceof Long){
rs2.updateLong( name, ((Long)val).longValue() );
}else
if(val instanceof Float){
rs2.updateFloat( name, ((Float)val).floatValue() );
}else
if(val instanceof Double){
rs2.updateDouble( name, ((Double)val).doubleValue() );
}else
if(val instanceof BigDecimal){
rs2.updateBigDecimal( name, (BigDecimal)val );
}else
if(val instanceof byte[]){
rs2.updateBytes( name, (byte[])val );
}
rs2.insertRow();
}
st2.close();
checkValues( st, values, needTrim);ResultSet rs = st.executeQuery("SELECT * From " + table);
int i = 0;
while(rs.next()){
assertEqualsRsValue(values[i], rs, needTrim);
i++;
}
rs.close();try{
Connection con = AllTests.getConnection();
Statement st = con.createStatement();
st.execute("drop table " + table);
st.close();
}catch(Throwable e){
}tearDown();Connection con = AllTests.getConnection();
dropTable(con,"testDelete");
Statement st = con.createStatement();
st.execute("create table testDelete(a int default 15)");
for(int i=0; i<10; i++){
st.execute("Insert into testDelete Values("+i+")");
}
assertRowCount( 10, "Select * from testDelete");
st.execute("delete from testDelete Where a=3");
assertRowCount( 9, "Select * from testDelete");
st.execute("delete from testDelete Where a<5");
assertRowCount( 5, "Select * from testDelete");
st.execute("delete from testDelete");
assertRowCount( 0, "Select * from testDelete");
dropTable(con,"testDelete");Connection con = AllTests.getConnection();
dropTable(con,"testUpdate1");
dropTable(con,"testUpdate2");
Statement st = con.createStatement();
st.execute("create table testUpdate1(id1 int, value1 varchar(100))");
st.execute("create table testUpdate2(id2 int, value2 varchar(100))");
st.execute("Insert into testUpdate1 Values(11, 'qwert1')");
st.execute("Insert into testUpdate2 Values(11, 'qwert2')");
st.execute("update testUpdate1 inner join testUpdate2 on id1=id2 Set value1=value1+'update', value2=value2+'update'");
ResultSet rs = st.executeQuery("Select * From testUpdate1 inner join testUpdate2 on id1=id2");
assertTrue( rs.next() );
assertEquals( "qwert1update", rs.getString("value1"));
assertEquals( "qwert2update", rs.getString("value2"));
dropTable(con,"testUpdate1");
dropTable(con,"testUpdate2");Connection con = AllTests.getConnection();
dropTable(con,"testUpdate");
Statement st = con.createStatement();
st.execute("create table testUpdate(id int default 15, value1 varchar(100), value2 int)");
for(int i=0; i<10; i++){
st.execute("Insert into testUpdate Values("+i+','+(i*100)+','+i+")");
}
assertRowCount( 10, "Select * from testUpdate");
st.execute("update testUpdate set value1=13 Where id=3");
assertEqualsRsValue( "13", "Select value1 from testUpdate Where id=3");
assertRowCount( 10, "Select * from testUpdate");
st.execute("update testUpdate set value1=1040 Where id=3");
assertEqualsRsValue( "1040", "Select value1 from testUpdate Where id=3");
assertRowCount( 10, "Select * from testUpdate");
st.execute("update testUpdate set value1=10400 Where id=3");
assertEqualsRsValue( "10400", "Select value1 from testUpdate Where id=3");
assertRowCount( 10, "Select * from testUpdate");
st.execute("update testUpdate set value1=13,id=3 Where id=3");
assertEqualsRsValue( "13", "Select value1 from testUpdate Where id=3");
assertRowCount( 10, "Select * from testUpdate");
st.execute("delete from testUpdate Where id=3");
assertRowCount( 9, "Select * from testUpdate");
dropTable(con,"testUpdate");Connection con = AllTests.getConnection();
dropTable(con,"testUpdate");
Statement st = con.createStatement();
st.execute("create table testUpdate(id int default 15, value int)");
for(int i=0; i<10; i++){
st.execute("Insert into testUpdate Values("+i+','+i+")");
}
assertRowCount( 10, "Select * from testUpdate");
int updateCount;
updateCount = st.executeUpdate("update testUpdate set value=103 Where id=3");
assertEqualsRsValue( new Integer(103), "Select value from testUpdate Where id=3");
assertRowCount( 10, "Select value from testUpdate");
assertEquals( 1, updateCount);
updateCount = st.executeUpdate("update testUpdate set value=104 Where id=3");
assertEqualsRsValue( new Integer(104), "Select value from testUpdate Where id=3");
assertRowCount( 10, "Select value from testUpdate");
assertEquals( 1, updateCount);
updateCount = st.executeUpdate("delete from testUpdate Where id=3");
assertRowCount( 9, "Select * from testUpdate");
assertEquals( 1, updateCount);
updateCount = st.executeUpdate("update testUpdate set value=27 Where id<5");
assertEquals( 4, updateCount);
dropTable(con,"testUpdate");Connection con;
try{
con = DriverManager.getConnection(AllTests.JDBC_URL + "?abc");
con.close();
fail("SQLException should be thrown");
}catch(SQLException ex){
}
con = DriverManager.getConnection(AllTests.JDBC_URL + "? ");
con.close();
con = DriverManager.getConnection(AllTests.JDBC_URL + "?a=b; ; c=d  ; e = f; ; ");
Connection con2 = DriverManager.getConnection( "jdbc:smallsql:" + new File( AllTests.CATALOG ).getAbsolutePath());
con.close();
con2.close();
con = DriverManager.getConnection( "jdbc:smallsql:file:" + AllTests.CATALOG );
con.close();Connection con = AllTests.getConnection();
try{
dropTable(con, "DuplicatedTable");
Statement st = con.createStatement();
st.execute("Create Table DuplicatedTable(col INT primary key)");
int tableFileCount = countFiles("DuplicatedTable");
try{
st.execute("Create Table DuplicatedTable(col INT primary key)");
fail("SQLException 'Duplicated Table' should be throw");
}catch(SQLException e){
assertSQLException("01000", 0, e);
}
assertEquals("Additional Files created",tableFileCount, countFiles("DuplicatedTable"));
}finally{
dropTable(con, "DuplicatedTable");
}Connection con = AllTests.getConnection();
Statement st = con.createStatement();
st.close();
try{
st.execute("Select 1");
fail("Exception should throw");
}catch(SQLException ex){
assertSQLException("HY010", 0, ex);
}
try{
st.executeQuery("Select 1");
fail("Exception should throw");
}catch(SQLException ex){
assertSQLException("HY010", 0, ex);
}
try{
st.executeUpdate("Select 1");
fail("Exception should throw");
}catch(SQLException ex){
assertSQLException("HY010", 0, ex);
}Connection con = AllTests.getConnection();
Statement st = con.createStatement();
try{
st.execute("Create Table DuplicatedColumn(col INT, Col INT)");
fail("SQLException 'Duplicated Column' should be throw");
}catch(SQLException e){
assertSQLException("01000", 0, e);
}int count = 0;
String names[] = new File(AllTests.CATALOG).list();
for(int i=0; i<names.length; i++){
if(names[i].startsWith(fileNameStart)){
count++;
}
}
return count;Connection con = AllTests.getConnection();
try{
Statement st = con.createStatement();
st.execute("create table foo (myint number)");
st.execute("create table bar (myint number)");
try{
st.executeQuery("select myint from foo, bar");
fail("SQLException 'Ambiguous name' should be throw");
}catch(SQLException e){
assertSQLException("01000", 0, e);
}
}finally{
dropTable(con, "foo");
dropTable(con, "bar");
}Connection con = AllTests.getConnection();
PreparedStatement pr = con.prepareStatement("Select ?");
pr.setInt(1, 1);
pr.close();
try{
pr.setInt(1, 1);
fail("Exception should throw");
}catch(SQLException ex){
assertSQLException("HY010", 0, ex);
}
try{
pr.execute();
fail("Exception should throw");
}catch(SQLException ex){
assertSQLException("HY010", 0, ex);
}
try{
pr.executeQuery();
fail("Exception should throw");
}catch(SQLException ex){
assertSQLException("HY010", 0, ex);
}
try{
pr.executeUpdate();
fail("Exception should throw");
}catch(SQLException ex){
assertSQLException("HY010", 0, ex);
}Connection con = AllTests.getConnection();
try{
con.createStatement().execute("Create Table ExceptionMethods(v varchar(30))");
con.createStatement().execute("Insert Into ExceptionMethods(v) Values('qwert')");
ResultSet rs = con.createStatement().executeQuery("Select * from ExceptionMethods");
assertEquals(true, rs.next());
try{
rs.isBeforeFirst();
fail("SQLException 'ResultSet is forward only' should be throw");
}catch(SQLException e){
assertSQLException("01000", 0, e);
}
try{
rs.isFirst();
fail("SQLException 'ResultSet is forward only' should be throw");
}catch(SQLException e){
assertSQLException("01000", 0, e);
}
try{
rs.first();
fail("SQLException 'ResultSet is forward only' should be throw");
}catch(SQLException e){
assertSQLException("01000", 0, e);
}
try{
rs.previous();
fail("SQLException 'ResultSet is forward only' should be throw");
}catch(SQLException e){
assertSQLException("01000", 0, e);
}
try{
rs.last();
fail("SQLException 'ResultSet is forward only' should be throw");
}catch(SQLException e){
assertSQLException("01000", 0, e);
}
try{
rs.isLast();
fail("SQLException 'ResultSet is forward only' should be throw");
}catch(SQLException e){
assertSQLException("01000", 0, e);
}
try{
rs.isAfterLast();
fail("SQLException 'ResultSet is forward only' should be throw");
}catch(SQLException e){
assertSQLException("01000", 0, e);
}
try{
rs.afterLast();
fail("SQLException 'ResultSet is forward only' should be throw");
}catch(SQLException e){
assertSQLException("01000", 0, e);
}
try{
rs.absolute(1);
fail("SQLException 'ResultSet is forward only' should be throw");
}catch(SQLException e){
assertSQLException("01000", 0, e);
}
try{
rs.relative(1);
fail("SQLException 'ResultSet is forward only' should be throw");
}catch(SQLException e){
assertSQLException("01000", 0, e);
}
}finally{
dropTable(con, "ExceptionMethods");
}Connection con = AllTests.getConnection();
try{
Statement st = con.createStatement();
st.execute("Create Table DuplicatedColumn(col INT)");
try{
st.execute("ALTER TABLE DuplicatedColumn Add Col INT");
fail("SQLException 'Duplicated Column' should be throw");
}catch(SQLException e){
assertSQLException("01000", 0, e);
}
}finally{
dropTable(con, "DuplicatedColumn");
}Connection con = AllTests.getConnection();
try{
Statement st = con.createStatement();
st.execute("Create Table DuplicatedColumn(col INT)");
try{
st.execute("INSERT INTO DuplicatedColumn(col,Col) Values(1,2)");
fail("SQLException 'Duplicated Column' should be throw");
}catch(SQLException e){
assertSQLException("01000", 0, e);
}
}finally{
dropTable(con, "DuplicatedColumn");
}TestSuite theSuite = new TestSuite("Exceptions");
for(int i=0; i<TESTS.length; i++){
theSuite.addTest(new TestExceptions( TESTS[i] ) );
}
return theSuite;if(init) return;
Connection con = AllTests.getConnection();
Statement st = con.createStatement();
dropTable( con, "exceptions");
st.execute("Create Table exceptions (c varchar(30), i int)");
init = true;TestValue value = new TestValue();
value.sql       = sql;
value.sqlstate  = sqlstate;
value.errorCode = errorCode;
value.errorType = errorType;
return value;init();
Connection con = AllTests.getConnection();
Statement st = con.createStatement();
ResultSet rs = null;
try{
rs = st.executeQuery( testValue.sql );
}catch(SQLException sqle){
assertTrue( "There should no syntax error:"+sqle, SYNTAX == testValue.errorType);
assertSQLException( testValue.sqlstate, testValue.errorCode, sqle );
}
if(testValue.errorType == SYNTAX){
assertNull("There should be a syntax error", rs);
return;
}
try{
while(rs.next()){
for(int i=1; i<=rs.getMetaData().getColumnCount(); i++){
rs.getObject(i);
}
}
fail("There should be a runtime error");
}catch(SQLException sqle){
assertSQLException( testValue.sqlstate, testValue.errorCode, sqle );
}TestSuite theSuite = new TestSuite("Functions");
for(int i=0; i<TESTS.length; i++){
theSuite.addTest(new TestFunctions( TESTS[i] ) );
}
return theSuite;String query = "Select " + testValue.function + ",5 from " + table;
assertEqualsRsValue( testValue.result, query);
if(!testValue.function.startsWith("Top")){
assertEqualsRsValue( testValue.result, "Select " + testValue.function + " from " + table + " Group By " + testValue.function);
}tearDown();
try{
Connection con = AllTests.getConnection();
Statement st = con.createStatement();
st.execute("create table " + table + "(aInt int, aVarchar varchar(100))");
st.execute("Insert into " + table + "(aInt, aVarchar) Values(-120,'qwert')");
st.close();
}catch(Throwable e){
e.printStackTrace();
}TestValue value = new TestValue();
value.function  = function;
value.result    = result;
return value;try{
Connection con = AllTests.getConnection();
Statement st = con.createStatement();
st.execute("drop table " + table);
st.close();
}catch(Throwable e){
}init();
assertEqualsRsValue( STR_VALUE2, "Select max(name) FROM " + table1);init();
assertEqualsRsValue( "name2", "Select last(name) FROM " + table1);init();
assertEqualsRsValue( java.sql.Time.valueOf("12:34:56"), "Select max({t '12:34:56'}) FROM " + table1);if(init) return;
try{
Connection con = AllTests.getConnection();
dropTable( con, table1 );
Statement st = con.createStatement();
st.execute("create table " + table1 + "(name varchar(30), id int )");
st.close();
PreparedStatement pr = con.prepareStatement("INSERT into " + table1 + "(name, id) Values(?,?)");
pr.setString( 1, STR_VALUE1);
pr.setInt( 2, 1 );
pr.execute();
pr.setString( 1, STR_VALUE1);
pr.setInt( 2, 2 );
pr.execute();
pr.setString( 1, STR_VALUE1);
pr.setNull( 2, Types.INTEGER );
pr.execute();
pr.setString( 1, STR_VALUE2);
pr.setInt( 2, 1 );
pr.execute();
pr.close();
init = true;
}catch(Throwable e){
e.printStackTrace();
}init();
Connection con = AllTests.getConnection();
PreparedStatement pr = con.prepareStatement("Select count(*) FROM " + table1 + " Where id=-1234");
for(int i=1; i<=3; i++){
ResultSet rs = pr.executeQuery();
assertTrue( "No row produce in loop:"+i, rs.next());
assertEquals( "loop:"+i, 0, rs.getInt(1));
}init();
assertEqualsRsValue( STR_VALUE1, "Select min(name) FROM " + table1);init();
assertEqualsRsValue( new BigDecimal("4.00"), "Select sum(cast(id as decimal(38,2))) FROM " + table1);init();
Connection con = AllTests.getConnection();
PreparedStatement pr = con.prepareStatement("Select count(*) FROM " + table1 + " Group By name Order By name DESC");
for(int i=1; i<=3; i++){
ResultSet rs = pr.executeQuery( );
assertTrue  ( "loop:"+i, rs.next());
assertEquals( "loop:"+i, 1, rs.getInt(1));
assertTrue  ( "loop:"+i, rs.next());
assertEquals( "loop:"+i, 3, rs.getInt(1));
}init();
assertEqualsRsValue( new Integer(1), "Select min(id) FROM " + table1);init();
assertEqualsRsValue( new java.math.BigDecimal("2"), "Select max(convert(numeric,id)) FROM " + table1);init();
assertEqualsRsValue( new java.math.BigDecimal("2.0000"), "Select max(convert(money,id)) FROM " + table1);init();
assertEqualsRsValue( new Integer(1), "Select avg(id) FROM " + table1);init();
assertEqualsRsValue( new Integer(1), "Select first(id) FROM " + table1);init();
assertEqualsRsValue(new Integer(4), "Select count(*) FROM " + table1 + " Group By name+null" );init();
assertEqualsRsValue( new Integer(1), "Select last(id) FROM " + table1);init();
Connection con = AllTests.getConnection();
Statement st = con.createStatement();
st.execute("Delete FROM " + table1);
init = false;
assertEqualsRsValue( new Integer(0), "Select count(*) FROM " + table1);init();
assertEqualsRsValue( new Integer(0), "Select count(*) FROM " + table1 + " Where id=-1234");init();
Connection con = AllTests.getConnection();
Statement st = con.createStatement();
ResultSet rs;
rs = st.executeQuery("Select name FROM " + table1 + " Group By name");
assertTrue(rs.next());
assertEquals( STR_VALUE1, rs.getObject(1) );
assertTrue(rs.next());
assertEquals( STR_VALUE2, rs.getObject(1) );init();
assertEqualsRsValue( java.sql.Timestamp.valueOf("2345-01-23 12:34:56.123"), "Select max({ts '2345-01-23 12:34:56.123'}) FROM " + table1);init();
Connection con = AllTests.getConnection();
PreparedStatement pr = con.prepareStatement("Select abs(sum(abs(3-id))+2) FROM " + table1 + " Group By name+'a' Order By 'b'+(Name+'a')");
for(int i=1; i<=3; i++){
ResultSet rs = pr.executeQuery( );
assertTrue  ( "loop:"+i, rs.next());
assertEquals( "loop:"+i, 5, rs.getInt(1));
assertTrue  ( "loop:"+i, rs.next());
assertEquals( "loop:"+i, 4, rs.getInt(1));
}init();
assertEqualsRsValue( "name1", "Select first(name) FROM " + table1);init();
assertEqualsRsValue( java.sql.Date.valueOf("2345-01-23"), "Select max({d '2345-01-23'}) FROM " + table1);init();
Connection con = AllTests.getConnection();
Statement st = con.createStatement();
try{
ResultSet rs;
st.execute("Create View qry" + table1 + " as Select name, name as name2, count(*) as count FROM " + table1 + " Group By name");
rs = st.executeQuery("Select * from qry" + table1);
assertEquals( "name",  rs.getMetaData().getColumnLabel(1) );
assertEquals( "name2", rs.getMetaData().getColumnLabel(2) );
assertEquals( "count", rs.getMetaData().getColumnLabel(3) );
}finally{
st.execute("Drop View qry" + table1);
}init();
assertEqualsRsValue( null, "Select max(id) FROM " + table1 + " Where id is null");init();
assertEqualsRsValue( null, "Select min(id) FROM " + table1 + " Where id is null");init();
assertEqualsRsValue( new Integer(2), "Select max(id) FROM " + table1);init();
assertEqualsRsValue( new Long(4), "Select sum(cast(id as BigInt)) FROM " + table1);init();
Connection con = AllTests.getConnection();
Statement st = con.createStatement();
ResultSet rs;
rs = st.executeQuery("Select count(id) FROM " + table1 + " Group By name");
while(rs.next()){
rs.getObject(1);
}
rs = st.executeQuery("Select count(*) FROM " + table1 + " Group By name");
while(rs.next()){
rs.getObject(1);
}
rs = st.executeQuery("Select count(*) FROM " + table1);
assertTrue(rs.next());
assertEquals( 4, rs.getInt(1));
rs = st.executeQuery("Select count(id) FROM " + table1);
assertTrue(rs.next());
assertEquals( 3, rs.getInt(1));
rs = st.executeQuery("Select count(*)+1 FROM " + table1);
assertTrue(rs.next());
assertEquals( 5, rs.getInt(1));init();
assertEqualsRsValue( new Double(2), "Select max(convert(float,id)) FROM " + table1);init();
assertEqualsRsValue( new Long(2), "Select max(cast(id as BigInt)) FROM " + table1);init();
Connection con = AllTests.getConnection();
PreparedStatement pr = con.prepareStatement("Select sum(id), name+'a' as ColumnName FROM " + table1 + " Group By name+'a' Order By Name+'a'");
for(int i=1; i<=3; i++){
ResultSet rs = pr.executeQuery( );
assertTrue  ( "loop:"+i, rs.next());
assertEquals( "loop:"+i, 3, rs.getInt(1));
assertTrue  ( "loop:"+i, rs.next());
assertEquals( "loop:"+i, 1, rs.getInt(1));
assertEquals( "loop:"+i+" Alias name von Expression", "ColumnName", rs.getMetaData().getColumnName(2));
}init();
assertEqualsRsValue( new Double(4), "Select sum(cast(id as double)) FROM " + table1);init();
String sql = "Select max(convert(uniqueidentifier, '12345678-3445-3445-3445-1234567890ab')) FROM " + table1;
assertEqualsRsValue( "12345678-3445-3445-3445-1234567890AB", sql);init();
assertEqualsRsValue( new Float(4), "Select sum(cast(id as real)) FROM " + table1);init();
assertEqualsRsValue( new Integer(4), "Select sum(id) FROM " + table1);init();
assertEqualsRsValue( new Double(2), "Select max(convert(double,id)) FROM " + table1);init();
assertEqualsRsValue( new Integer(2), "Select max(convert(tinyint,id)) FROM " + table1);init();
assertEqualsRsValue( new Float(2), "Select max(convert(real,id)) FROM " + table1);Connection con = AllTests.getConnection();
dropTable(con,"QuoteIdentifer");
con.createStatement().execute("create table \"QuoteIdentifer\"(\"a\" int default 5)");
ResultSet rs = con.createStatement().executeQuery("SELECT tbl.* from \"QuoteIdentifer\" tbl");
assertEquals( "a", rs.getMetaData().getColumnName(1));
assertEquals( "QuoteIdentifer", rs.getMetaData().getTableName(1));
while(rs.next()){
}
dropTable(con,"QuoteIdentifer");Connection con = AllTests.getConnection();
dropTable( con, table );
dropTable( con, table2 );
dropTable( con, table3 );clear();
Connection con = AllTests.getConnection();
Statement st = con.createStatement();
st.execute("create table " + table + "(a " + testValue.dataType +" PRIMARY KEY, b " + testValue.dataType + ")");
st.execute("create table " + table2+ "(c " + testValue.dataType +" PRIMARY KEY, d " + testValue.dataType + ")");
st.execute("create table " + table3+ "(c " + testValue.dataType +" PRIMARY KEY, d " + testValue.dataType + ")");
st.close();
con.close();
con = AllTests.getConnection();
PreparedStatement pr = con.prepareStatement("INSERT into " + table + "(a,b) Values(?,?)");
insertValues( pr );
pr.close();
pr = con.prepareStatement("INSERT into " + table2 + " Values(?,?)");
insertValues( pr );
pr.close();pr.setObject( 1, testValue.small);
pr.setObject( 2, testValue.large);
pr.execute();
pr.setObject( 1, testValue.small);
pr.setObject( 2, testValue.small);
pr.execute();
pr.setObject( 1, testValue.large);
pr.setObject( 2, testValue.large);
pr.execute();
pr.setObject( 1, testValue.large);
pr.setObject( 2, testValue.small);
pr.execute();
pr.setObject( 1, null);
pr.setObject( 2, testValue.small);
pr.execute();
pr.setObject( 1, testValue.small);
pr.setObject( 2, null);
pr.execute();
pr.setObject( 1, null);
pr.setObject( 2, null);
pr.execute();TestValue value = new TestValue();
value.dataType  = dataType;
value.small     = small;
value.large     = large;
return value;clear();Connection con = AllTests.getConnection();
Statement st = con.createStatement();
ResultSet rs;
rs = st.executeQuery("Select * from " + table + " where 1 = 0");
assertFalse( "To many rows", rs.next() );
assertRowCount( 7, "Select * from " + table);
assertRowCount( 49, "Select * from " + table + " t1, " + table2 + " t2");
assertRowCount( 0, "Select * from " + table + ", " + table3);
assertRowCount( 49, "Select * from ("+ table +"), " + table2);
assertRowCount( 49, "Select * from " + table + " Cross Join " + table2);
assertRowCount( 13, "Select * from " + table + " INNER JOIN " + table2 + " ON " + table + ".a = " + table2 + ".c");
assertRowCount( 13, "Select * from " + table + "       JOIN " + table2 + " ON " + table2 + ".c = " + table + ".a");
assertRowCount( 13, "Select * from {oj " + table + " INNER JOIN " + table2 + " ON " + table + ".a = " + table2 + ".c}");
assertRowCount( 13, "Select * from " + table + " AS t1 INNER JOIN " + table2 + " t2 ON t1.a = t2.c");
assertRowCount( 13, "Select * from {oj " + table + " t1 INNER JOIN " + table2 + " t2 ON t1.a = t2.c}");
assertRowCount( 4, "Select * from " + table + " t1 INNER JOIN " + table2 + " t2 ON t1.a = t2.c and t1.b=t2.d");
assertRowCount( 4, "Select * from " + table + " t1       JOIN " + table2 + " t2 ON t1.a = t2.c and t2.d=t1.b");
assertRowCount( 7, "Select * from " + table + " t1 LEFT OUTER JOIN " + table2 + " t2 ON t1.a = t2.c and t1.b=t2.d");
assertRowCount( 7, "Select * from " + table + " t1 LEFT       JOIN " + table2 + " t2 ON t1.a = t2.c and t1.b=t2.d");
assertRowCount( 15, "Select * from " + table + " t1 LEFT OUTER JOIN " + table2 + " t2 ON t1.a = t2.c");
assertRowCount( 7, "Select * from " + table + " t1 LEFT OUTER JOIN " + table3 + " t2 ON t1.a = t2.c");
assertRowCount( 7, "Select * from " + table + " t1 RIGHT OUTER JOIN " + table2 + " t2 ON t1.a = t2.c and t1.b=t2.d");
assertRowCount( 7, "Select * from " + table + " t1 RIGHT OUTER JOIN " + table2 + " t2 ON false");
assertRowCount( 15, "Select * from " + table + " t1 RIGHT OUTER JOIN " + table2 + " t2 ON t1.a = t2.c");
assertRowCount( 0, "Select * from " + table + " t1 RIGHT OUTER JOIN " + table3 + " t2 ON t1.a = t2.c");
assertRowCount( 14, "Select * from " + table + " t1 FULL OUTER JOIN " + table2 + " t2 ON 1=0");
assertRowCount( 17, "Select * from " + table + " t1 FULL OUTER JOIN " + table2 + " t2 ON t1.a = t2.c");
assertRowCount( 7, "Select * from " + table + " t1 FULL OUTER JOIN " + table3 + " t2 ON t1.a = t2.c");
assertRowCount( 7, "Select * from " + table3 + " t1 FULL OUTER JOIN " + table + " t2 ON t1.c = t2.a");
assertRowCount( 5, "Select * from " + table + " INNER JOIN (SELECT DISTINCT c FROM " + table2 + ") t1 ON " + table + ".a = t1.c");
st.close();TestSuite theSuite = new TestSuite("Joins");
for(int i=0; i<TESTS.length; i++){
theSuite.addTest(new TestJoins( TESTS[i] ) );
}
return theSuite;Connection conn = AllTests.createConnection("?locale=en", null);
try {
conn.prepareStatement("DROP TABLE " + TABLE_NAME).execute();
}
catch (Exception e) {}
finally {
conn.close();
}Connection conn = AllTests.createConnection("?locale=it", null);
Statement stat = conn.createStatement();
try {
try {
recreateTestTab(stat);
stat.execute("CREATE TABLE " + TABLE_NAME + " (id_test INT)");
fail();
}
catch(SQLException e) {
assertMessage(e, "La tabella/vista '" + TABLE_NAME + "' è già esistente.");
}
try {
stat.execute("DROP TABLE " + TABLE_NAME);
stat.execute("DROP TABLE " + TABLE_NAME);
}
catch (SQLException e) {
assertMessage(e, "Non si può effettuare DROP della tabella");
}
try {
stat.execute("CREATE TABLE foo");
}
catch (SQLException e) {
assertMessage(e, "Errore di sintassi, fine inattesa");
}
}
finally {
conn.close();
}stat.execute("CREATE TABLE " + TABLE_NAME + " (id_test INT)");String message = e.getMessage();
boolean found = true;
for (int i = 0; found && i < expectedTexts.length; i++) {
found = found && message.indexOf(expectedTexts[i]) >= 0;
}
if (! found) {
System.err.println("ERROR [Wrong message]:" + message);
fail();
}tearDown();boolean failed = false;
StringBuffer msgBuf = new StringBuffer();
Language eng = Language.getLanguage("en");
HashSet engEntriesSet = new HashSet();
String[][] engEntriesArr = eng.getEntries();
for (int j = 1; j < engEntriesArr.length; j++) {
engEntriesSet.add(engEntriesArr[j][0]);
}
for (int i = 0; i < OTHER_LANGUAGES.length; i++) {
String localeStr = OTHER_LANGUAGES[i];
Language lang2 = Language.getLanguage(localeStr);
HashSet otherEntriesSet = new HashSet();
String[][] otherEntriesArr = lang2.getEntries();
for (int j = 0; j < otherEntriesArr.length; j++) {
otherEntriesSet.add(otherEntriesArr[j][0]);
}
Set diff = (Set)engEntriesSet.clone();
diff.removeAll(otherEntriesSet);
if (diff.size() > 0) {
failed = true;
msgBuf.append("\nMissing entries for language ").append( OTHER_LANGUAGES[i] ).append(": ");
for (Iterator itr = diff.iterator(); itr.hasNext(); ) {
msgBuf.append(itr.next());
if (itr.hasNext()) msgBuf.append(',');
}
}
diff = (Set)otherEntriesSet.clone();
diff.removeAll(engEntriesSet);
if (diff.size() > 0) {
failed = true;
msgBuf.append("\nAdditional entries for language ").append( OTHER_LANGUAGES[i] ).append(": ");
for (Iterator itr = diff.iterator(); itr.hasNext(); ) {
msgBuf.append(itr.next());
if (itr.hasNext()) msgBuf.append(',');
}
}
StringBuffer buf = new StringBuffer();
for (int j = 1; j < engEntriesArr.length; j++) {
String key = engEntriesArr[j][0];
String engValue = eng.getMessage(key);
String otherValue = lang2.getMessage(key);
if(engValue.equals(otherValue)){
failed = true;
if(buf.length() > 0){
buf.append(',');
}
buf.append(key);
}
}
if(buf.length()>0){
msgBuf.append("\nNot translated entries for language ").append( OTHER_LANGUAGES[i] ).append(": ");
msgBuf.append(buf);
}
}
if (failed){
System.err.println(msgBuf);
fail(msgBuf.toString());
}assertMessage(e, new String[] { expectedText });Locale origLocale = Locale.getDefault();
Locale.setDefault(Locale.ITALY);
Connection conn = AllTests.createConnection("?locale=XXX", null);
Statement stat = conn.createStatement();
try {
recreateTestTab(stat);
stat.execute("CREATE TABLE " + TABLE_NAME + " (id_test INT)");
fail();
}
catch (SQLException e) {
assertMessage(e, "La tabella/vista '" + TABLE_NAME + "' è già esistente.");
}
finally {
Locale.setDefault(origLocale);
conn.close();
}Connection conn = AllTests.createConnection("?locale=it", null);
Statement stat = conn.createStatement();
try {
try {
stat.execute("CREATE TABLE");
}
catch (SQLException se) {
assertMessage(se, "Errore di sintassi, fine inattesa della stringa SQL. Le parole chiave richieste sono: <identifier>");
}
try {
stat.execute("Some nonsensical sentence.");
}
catch (SQLException se) {
assertMessage(se, "Errore di sintassi alla posizione 0 in 'Some'. Le parole chiave richieste sono");
}
recreateTestTab(stat);
try {
stat.execute("SELECT bar() FROM foo");
}
catch (SQLException se) {
assertMessage(se, "Errore di sintassi alla posizione 7 in 'bar'. Funzione sconosciuta");
}
try {
stat.execute("SELECT UCASE('a', '');");
}
catch (SQLException se) {
assertMessage(se, "Errore di sintassi alla posizione 7 in 'UCASE'. Totale parametri non valido.");
}
}
finally {
conn.close();
}Connection con = AllTests.getConnection();
Statement st = con.createStatement();
ResultSet rs = st.executeQuery("Select * FROM " + table);
long i = firstValue;
while(rs.next()){
Object obj1 = rs.getObject(1);
Object obj2 = rs.getObject(2);
if(obj1 instanceof Money){
Money mon1 = (Money)obj1;
Money mon2 = (Money)obj2;
assertEquals("Roundungsfehler money:", i, mon1.unscaledValue());
assertEquals("Roundungsfehler smallmoney:", i, mon2.unscaledValue());
}else{
BigDecimal mon1 = (BigDecimal)obj1;
BigDecimal mon2 = (BigDecimal)obj2;
assertEquals("Roundungsfehler money:", i, mon1.unscaledValue().longValue());
assertEquals("Roundungsfehler smallmoney:", i, mon2.unscaledValue().longValue());
}
i++;
}
st.close();tearDown();
Connection con = AllTests.getConnection();
Statement st = con.createStatement();
st.execute("create table " + table + "(a money, b smallmoney)");try{
Connection con = AllTests.getConnection();
Statement st = con.createStatement();
st.execute("drop table " + table);
st.close();
}catch(Throwable e){
}Connection con = AllTests.getConnection();
Statement st = con.createStatement();
int firstValue = -10000;
for(int i=firstValue; i<10000; i++){
st.execute("Insert into " + table + "(a,b) values( (" + i + "/10000.0), (" + i + "/10000.0) )");
}
st.close();
verify(firstValue);Connection con = AllTests.getConnection();
Statement st = con.createStatement();
int firstValue = -10000;
for(int i=firstValue; i<10000; i++){
st.execute("Insert into " + table + "(a,b) values(" + (i/10000.0) + "," +(i/10000.0) +")");
}
st.close();
verify(firstValue);junit.swingui.TestRunner.main(new String[]{TestOperatoren.class.getName()});try{
Connection con = AllTests.getConnection();
Statement st = con.createStatement();
st.execute("drop table " + table);
st.close();
}catch(Throwable e){
}TestSuite theSuite = new TestSuite("Operatoren");
for(int i=0; i<TESTS.length; i++){
theSuite.addTest(new TestOperatoren( TESTS[i] ) );
}
return theSuite;Connection con = AllTests.getConnection();
Statement st = con.createStatement();
ResultSet rs;
rs = st.executeQuery("Select * from " + table + " where 1 = 0");
assertFalse( "To many rows", rs.next() );
rs = st.executeQuery("Select * from " + table + " where a = b");
assertTrue( "To few rows", rs.next() );
assertEqualsObject( "Values not equals", rs.getObject(1), rs.getObject(2), false);
assertTrue( "To few rows", rs.next() );
assertEqualsObject( "Values not equals", rs.getObject(1), rs.getObject(2), false);
assertFalse( "To many rows", rs.next() );
rs = st.executeQuery("Select * from " + table + " where a <= b and b <= a");
assertTrue( "To few rows", rs.next() );
assertEqualsObject( "Values not equals", rs.getObject(1), rs.getObject(2), false);
assertTrue( "To few rows", rs.next() );
assertEqualsObject( "Values not equals", rs.getObject(1), rs.getObject(2), false);
assertFalse( "To many rows", rs.next() );
rs = st.executeQuery("Select * from " + table + " where (a > (b))");
assertTrue( "To few rows", rs.next() );
assertFalse( "To many rows", rs.next() );
rs = st.executeQuery("Select * from " + table + " where a >= b");
assertTrue( "To few rows", rs.next() );
assertTrue( "To few rows", rs.next() );
assertTrue( "To few rows", rs.next() );
assertFalse( "To many rows", rs.next() );
rs = st.executeQuery("Select * from " + table + " where not (a >= b)");
assertTrue( "To few rows", rs.next() );
assertTrue( "To few rows", rs.next() );
assertTrue( "To few rows", rs.next() );
assertTrue( "To few rows", rs.next() );
assertFalse( "To many rows", rs.next() );
rs = st.executeQuery("Select * from " + table + " where a < b");
assertTrue( "To few rows", rs.next() );
assertFalse( "To many rows", rs.next() );
rs = st.executeQuery("Select * from " + table + " where a < b or a>b");
assertTrue( "To few rows", rs.next() );
assertTrue( "To few rows", rs.next() );
assertFalse( "To many rows", rs.next() );
rs = st.executeQuery("Select * from " + table + " where a <= b");
assertTrue( "To few rows", rs.next() );
assertTrue( "To few rows", rs.next() );
assertTrue( "To few rows", rs.next() );
assertFalse( "To many rows", rs.next() );
rs = st.executeQuery("Select * from " + table + " where a <> b");
assertTrue( "To few rows", rs.next() );
assertTrue( "To few rows", rs.next() );
assertFalse( "To many rows", rs.next() );
PreparedStatement pr = con.prepareStatement("Select * from " + table + " where a between ? and ?");
pr.setObject( 1, testValue.small);
pr.setObject( 2, testValue.large);
rs = pr.executeQuery();
assertTrue( "To few rows", rs.next() );
assertTrue( "To few rows", rs.next() );
assertTrue( "To few rows", rs.next() );
assertTrue( "To few rows", rs.next() );
assertTrue( "To few rows", rs.next() );
assertFalse( "To many rows", rs.next() );
pr.close();
pr = con.prepareStatement("Select * from " + table + " where a not between ? and ?");
pr.setObject( 1, testValue.small);
pr.setObject( 2, testValue.large);
rs = pr.executeQuery();
assertTrue( "To few rows", rs.next() );
assertTrue( "To few rows", rs.next() );
assertFalse( "To many rows", rs.next() );
pr.close();
pr = con.prepareStatement("Select * from " + table + " where a in(?,?)");
pr.setObject( 1, testValue.small);
pr.setObject( 2, testValue.large);
rs = pr.executeQuery();
assertTrue( "To few rows", rs.next() );
assertTrue( "To few rows", rs.next() );
assertTrue( "To few rows", rs.next() );
assertTrue( "To few rows", rs.next() );
assertTrue( "To few rows", rs.next() );
assertFalse( "To many rows", rs.next() );
pr.close();
pr = con.prepareStatement("Select * from " + table + " where a not in(?,?)");
pr.setObject( 1, testValue.small);
pr.setObject( 2, testValue.large);
rs = pr.executeQuery();
assertTrue( "To few rows", rs.next());
assertTrue( "To few rows", rs.next());
assertFalse( "To many rows", rs.next() );
pr.close();
st.close();tearDown();
try{
Connection con = AllTests.getConnection();
Statement st = con.createStatement();
st.execute("create table " + table + "(a " + testValue.dataType +", b " + testValue.dataType + ")");
st.close();
PreparedStatement pr = con.prepareStatement("INSERT into " + table + "(a,b) Values(?,?)");
pr.setObject( 1, testValue.small);
pr.setObject( 2, testValue.large);
pr.execute();
pr.setObject( 1, testValue.small);
pr.setObject( 2, testValue.small);
pr.execute();
pr.setObject( 1, testValue.large);
pr.setObject( 2, testValue.large);
pr.execute();
pr.setObject( 1, testValue.large);
pr.setObject( 2, testValue.small);
pr.execute();
pr.setObject( 1, null);
pr.setObject( 2, testValue.small);
pr.execute();
pr.setObject( 1, testValue.small);
pr.setObject( 2, null);
pr.execute();
pr.setObject( 1, null);
pr.setObject( 2, null);
pr.execute();
pr.close();
}catch(Throwable e){
e.printStackTrace();
}TestValue value = new TestValue();
value.dataType  = dataType;
value.small     = small;
value.large     = large;
return value;init();
Connection con = AllTests.getConnection();
Statement st = con.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_UPDATABLE);
ResultSet rs = st.executeQuery("SELECT * FROM " + table1 + " ORDER  by v");
int colCount = rs.getMetaData().getColumnCount();
ArrayList result = new ArrayList();
while(rs.next()){
Object[] row = new Object[colCount];
for(int i=0; i<colCount; i++){
row[i] = rs.getObject(i+1);
}
result.add(row);
}
int rowCount = result.size();
while(rs.previous()){
Object[] row = (Object[])result.get(--rowCount);
for(int i=0; i<colCount; i++){
assertEquals( "Difference in row:"+rowCount, row[i], rs.getObject(i+1));
}
}
assertEquals( "RowCount different between next and previous:"+rowCount, 0, rowCount);init();
Connection con = AllTests.getConnection();
Statement st = con.createStatement();
ResultSet rs;
rs = st.executeQuery("SELECT * FROM " + table3 + " ORDER  by vb");
assertTrue( rs.next() );
assertNull( rs.getObject("vb") );
assertTrue( rs.next() );
assertEqualsObject( "", new byte[0], rs.getObject("vb"), false );
assertTrue( rs.next() );
assertEqualsObject( "", table3.getBytes(), rs.getObject("vb"), false );
assertFalse( rs.next() );init();
Connection con = AllTests.getConnection();
Statement st = con.createStatement();
ResultSet rs;
String oldValue;
rs = st.executeQuery("SELECT v, 5 as Const FROM " + table1 + " Union All Select vc, 6 From " + table3 + " ORDER by v");
assertRSMetaData(rs, new String[]{"v", "Const"}, new int[]{Types.VARCHAR, Types.INTEGER});
assertTrue( rs.next() );
oldValue = rs.getString("v");
assertNull(oldValue);
assertTrue( rs.next() );
oldValue = rs.getString("v");
assertNull(oldValue);
assertTrue( rs.next() );
oldValue = rs.getString("v");
int count = 3;
while(rs.next()){
String newValue = rs.getString("v");
assertTrue( oldValue.compareTo( newValue ) < 0 );
oldValue = newValue;
count++;
}
assertEquals( valueCount+4, count );init();
Connection con = AllTests.getConnection();
Statement st = con.createStatement();
ResultSet rs;
int oldValue;
rs = st.executeQuery("SELECT * FROM " + table1 + " ORDER  by abs(i)");
assertTrue( rs.next() );
assertNull(rs.getObject("i"));
assertTrue( rs.next() );
oldValue = Math.abs( rs.getInt("i") );
int count = 1;
while(rs.next()){
int newValue = Math.abs( rs.getInt("i") );
assertTrue( oldValue <= newValue );
oldValue = newValue;
count++;
}
assertEquals( valueCount, count );init();
Connection con = AllTests.getConnection();
Statement st = con.createStatement();
ResultSet rs = null;
String oldValue;
rs = st.executeQuery("SELECT * FROM " + table1+","+table2+" ORDER  by v, c2");
assertTrue( rs.next() );
assertNull( rs.getObject("v") );
assertNull( rs.getObject("c2") );
assertTrue( rs.next() );
oldValue = rs.getString("c2");
int count = 1;
while(rs.next() && rs.getString("v") == null){
String newValue = rs.getString("c2");
assertTrue( oldValue.compareTo( newValue ) < 0 );
oldValue = newValue;
count++;
}
assertEquals( valueCount+1, count );
boolean isNext = true;
while(isNext){
String vValue = rs.getString("v");
assertNull( rs.getObject("c2") );
assertTrue( rs.next() );
oldValue = rs.getString("c2");
assertEquals( vValue, rs.getString("v") );
isNext = rs.next();
count = 1;
while(isNext && vValue.equals(rs.getString("v"))){
String newValue = rs.getString("c2");
assertTrue( oldValue.compareTo( newValue ) < 0 );
oldValue = newValue;
count++;
isNext = rs.next();
}
assertEquals( valueCount+1, count );
}init();
Connection con = AllTests.getConnection();
Statement st = con.createStatement();
ResultSet rs;
String oldValue;
rs = st.executeQuery("SELECT * FROM " + table1 + " ORDER  by nv");
assertTrue( rs.next() );
oldValue = rs.getString("nv");
assertNull(oldValue);
assertTrue( rs.next() );
oldValue = rs.getString("nv");
int count = 1;
while(rs.next()){
assertTrue( String.CASE_INSENSITIVE_ORDER.compare( oldValue, rs.getString("nv") ) <= 0 );
oldValue = rs.getString("nv");
count++;
}
assertEquals( valueCount, count );init();
Connection con = AllTests.getConnection();
Statement st = con.createStatement();
ResultSet rs;
String oldValue;
rs = st.executeQuery("SELECT * FROM " + table1 + " ORDER  by v desc");
assertTrue( rs.next() );
oldValue = rs.getString("v");
int count = 1;
while(oldValue != null && rs.next()){
String newValue = rs.getString("v");
if(newValue != null){
assertTrue( oldValue.compareTo( newValue ) > 0 );
count++;
}
oldValue = newValue;
}
assertNull(oldValue);
assertFalse( rs.next() );
assertEquals( valueCount, count );init();
Connection con = AllTests.getConnection();
Statement st = con.createStatement();
ResultSet rs;
String oldValue;
rs = st.executeQuery("SELECT * FROM " + table1 + " ORDER  by v desc, i asc");
assertTrue( rs.next() );
oldValue = rs.getString("v");
int count = 1;
while(oldValue != null && rs.next()){
String newValue = rs.getString("v");
if(newValue != null){
assertTrue( oldValue.compareTo( newValue ) > 0 );
count++;
}
oldValue = newValue;
}
assertNull(oldValue);
assertFalse( rs.next() );
assertEquals( valueCount, count );init();
Connection con = AllTests.getConnection();
Statement st = con.createStatement();
ResultSet rs;
Long oldValue;
rs = st.executeQuery("SELECT * FROM " + table1 + " ORDER  by bi");
assertTrue( rs.next() );
oldValue = (Long)rs.getObject("bi");
assertNull(oldValue);
assertTrue( rs.next() );
oldValue = (Long)rs.getObject("bi");
int count = 1;
while(rs.next()){
assertTrue( oldValue.compareTo( (Long)rs.getObject("bi") ) < 0 );
oldValue = (Long)rs.getObject("bi");
count++;
}
assertEquals( valueCount, count );init();
Connection con = AllTests.getConnection();
Statement st = con.createStatement();
ResultSet rs;
Integer oldValue;
rs = st.executeQuery("SELECT * FROM " + table1 + " ORDER  by i");
assertTrue( rs.next() );
oldValue = (Integer)rs.getObject("i");
assertNull(oldValue);
assertTrue( rs.next() );
oldValue = (Integer)rs.getObject("i");
int count = 1;
while(rs.next()){
assertTrue( oldValue.compareTo( (Integer)rs.getObject("i") ) < 0 );
oldValue = (Integer)rs.getObject("i");
count++;
}
assertEquals( valueCount, count );init();
Connection con = AllTests.getConnection();
Statement st = con.createStatement();
ResultSet rs;
Double oldValue;
rs = st.executeQuery("SELECT * FROM " + table1 + " ORDER  by d");
assertTrue( rs.next() );
oldValue = (Double)rs.getObject("d");
assertNull(oldValue);
assertTrue( rs.next() );
oldValue = (Double)rs.getObject("d");
int count = 1;
while(rs.next()){
assertTrue( oldValue.compareTo( (Double)rs.getObject("d") ) < 0 );
oldValue = (Double)rs.getObject("d");
count++;
}
assertEquals( valueCount, count );init();
Connection con = AllTests.getConnection();
Statement st = con.createStatement();
ResultSet rs;
Integer oldValue;
rs = st.executeQuery("SELECT * FROM " + table1 + " ORDER  by i Asc");
assertTrue( rs.next() );
oldValue = (Integer)rs.getObject("i");
assertNull(oldValue);
assertTrue( rs.next() );
oldValue = (Integer)rs.getObject("i");
int count = 1;
while(rs.next()){
assertTrue( oldValue.compareTo( (Integer)rs.getObject("i") ) < 0 );
oldValue = (Integer)rs.getObject("i");
count++;
}
assertEquals( valueCount, count );init();
Connection con = AllTests.getConnection();
Statement st = con.createStatement();
ResultSet rs;
Long oldValue;
rs = st.executeQuery("SELECT bi/2 bi_2 FROM " + table1 + " ORDER  by (bi/2)");
assertTrue( rs.next() );
oldValue = (Long)rs.getObject("bi_2");
assertNull(oldValue);
assertTrue( rs.next() );
oldValue = (Long)rs.getObject("bi_2");
int count = 1;
while(rs.next()){
Long newValue = (Long)rs.getObject("bi_2");
assertTrue( oldValue + "<="+newValue, oldValue.compareTo( newValue ) <= 0 );
oldValue = newValue;
count++;
}
assertEquals( valueCount, count );if(init) return;
try{
Connection con = AllTests.getConnection();
dropTable( con, table1 );
dropTable( con, table2 );
dropTable( con, table3 );
Statement st = con.createStatement();
st.execute("create table " + table1 + "(v varchar(30), c char(30), nv nvarchar(30),i int, d float, r real, bi bigint, b boolean)");
st.execute("create table " + table2 + "(c2 char(30))");
st.execute("create table " + table3 + "(vc varchar(30), vb varbinary(30))");
st.close();
PreparedStatement pr = con.prepareStatement("INSERT into " + table1 + "(v,c,nv,i,d,r,bi,b) Values(?,?,?,?,?,?,?,?)");
PreparedStatement pr2= con.prepareStatement("INSERT into " + table2 + "(c2) Values(?)");
for(int i=150; i>-10; i--){
pr.setString( 1, String.valueOf(i));
pr.setString( 2, String.valueOf(i));
pr.setString( 3, String.valueOf( (char)i ));
pr.setInt   ( 4, i );
pr.setDouble( 5, i );
pr.setFloat ( 6, i );
pr.setInt   ( 7, i );
pr.setBoolean( 8, i == 0 );
pr.execute();
pr2.setString( 1, String.valueOf(i));
pr2.execute();
valueCount++;
}
pr.setObject( 1, null, Types.VARCHAR);
pr.setObject( 2, null, Types.VARCHAR);
pr.setObject( 3, null, Types.VARCHAR);
pr.setObject( 4, null, Types.VARCHAR);
pr.setObject( 5, null, Types.VARCHAR);
pr.setObject( 6, null, Types.VARCHAR);
pr.setObject( 7, null, Types.VARCHAR);
pr.setObject( 8, null, Types.VARCHAR);
pr.execute();
pr2.setObject( 1, null, Types.VARCHAR);
pr2.execute();
pr2.setString( 1, "");
pr2.execute();
pr.close();
pr = con.prepareStatement("INSERT into " + table3 + "(vc, vb) Values(?,?)");
pr.setString( 1, table3);
pr.setBytes( 2, table3.getBytes());
pr.execute();
pr.setString( 1, "");
pr.setBytes( 2, new byte[0]);
pr.execute();
pr.setString( 1, null);
pr.setBytes( 2, null);
pr.execute();
init = true;
}catch(Throwable e){
e.printStackTrace();
}init();
Connection con = AllTests.getConnection();
Statement st = con.createStatement();
ResultSet rs;
int oldValue;
int oldValue2;
rs = st.executeQuery("SELECT * FROM " + table1 + " ORDER  by abs(i) Asc, i desc");
assertTrue( rs.next() );
assertNull(rs.getObject("i"));
assertTrue( rs.next() );
oldValue = Math.abs( rs.getInt("i") );
oldValue2 = rs.getInt("i");
int count = 1;
while(rs.next()){
int newValue2 = rs.getInt("i");
int newValue = Math.abs( newValue2 );
assertTrue( oldValue <= newValue );
if(oldValue == newValue){
assertTrue( oldValue2 > newValue2 );
}
oldValue = newValue;
oldValue2 = newValue2;
count++;
}
assertEquals( valueCount, count );init();
Connection con = AllTests.getConnection();
Statement st = con.createStatement();
ResultSet rs;
String oldValue;
rs = st.executeQuery("SELECT * FROM " + table1 + " ORDER  by v");
assertTrue( rs.next() );
oldValue = rs.getString("v");
assertNull(oldValue);
assertTrue( rs.next() );
oldValue = rs.getString("v");
int count = 1;
while(rs.next()){
String newValue = rs.getString("v");
assertTrue( oldValue + "<" + newValue, oldValue.compareTo( newValue ) < 0 );
oldValue = newValue;
count++;
}
assertEquals( valueCount, count );init();
Connection con = AllTests.getConnection();
Statement st = con.createStatement();
ResultSet rs;
String oldValue;
rs = st.executeQuery("SELECT first(v) cc FROM " + table1 + " Group By i ORDER  by first(V)");
assertTrue( rs.next() );
oldValue = rs.getString("cc");
assertNull(oldValue);
assertTrue( rs.next() );
oldValue = rs.getString("cc");
int count = 1;
while(rs.next()){
assertTrue( oldValue.compareTo( rs.getString("cc") ) < 0 );
oldValue = rs.getString("cc");
count++;
}
assertEquals( valueCount, count );init();
Connection con = AllTests.getConnection();
Statement st = con.createStatement();
ResultSet rs;
Integer oldValue;
rs = st.executeQuery("SELECT * FROM " + table1 + " ORDER  by i Desc");
assertTrue( rs.next() );
oldValue = (Integer)rs.getObject("i");
int count = 1;
while(oldValue != null && rs.next()){
Integer newValue = (Integer)rs.getObject("i");
if(newValue != null){
assertTrue( oldValue.compareTo( newValue ) > 0 );
count++;
}
oldValue = newValue;
}
assertNull(oldValue);
assertFalse( rs.next() );
assertEquals( valueCount, count );init();
Connection con = AllTests.getConnection();
Statement st = con.createStatement();
ResultSet rs;
String oldValue;
rs = st.executeQuery("SELECT * FROM " + table1 + " ORDER  by c");
assertTrue( rs.next() );
oldValue = rs.getString("c");
assertNull(oldValue);
assertTrue( rs.next() );
oldValue = rs.getString("c");
int count = 1;
while(rs.next()){
String newValue = rs.getString("c");
assertTrue( oldValue + "<" + newValue, oldValue.compareTo( newValue ) < 0 );
oldValue = newValue;
count++;
}
rs.close();
assertEquals( valueCount, count );init();
Connection con = AllTests.getConnection();
Statement st = con.createStatement();
ResultSet rs;
rs = st.executeQuery("SELECT * FROM " + table3 + " ORDER  by vc");
assertTrue( rs.next() );
assertNull( rs.getObject("vc") );
assertTrue( rs.next() );
assertEquals( "", rs.getObject("vc") );
assertTrue( rs.next() );
assertEquals( table3, rs.getObject("vc") );
assertFalse( rs.next() );init();
Connection con = AllTests.getConnection();
Statement st = con.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_UPDATABLE);
ResultSet rs;
int count;
rs = st.executeQuery("SELECT * FROM " + table1 + " ORDER  by i desc, d");
rs.next();
rs.next();
rs.previous();
rs.last();
count = 0;
while(rs.previous()) count++;
assertEquals( valueCount, count );
rs.beforeFirst();
count = -1;
while(rs.next()) count++;
assertEquals( valueCount, count );
rs.beforeFirst();
count = -1;
while(rs.next()) count++;
assertEquals( valueCount, count );init();
Connection con = AllTests.getConnection();
Statement st = con.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_UPDATABLE);
ResultSet rs;
int count;
rs = st.executeQuery("SELECT * FROM " + table1 + " ORDER  by v");
rs.next();
rs.next();
rs.previous();
rs.last();
count = 0;
while(rs.previous()) count++;
assertEquals( valueCount, count );
rs.beforeFirst();
count = -1;
while(rs.next()) count++;
assertEquals( valueCount, count );
rs.beforeFirst();
count = -1;
while(rs.next()) count++;
assertEquals( valueCount, count );init();
Connection con = AllTests.getConnection();
Statement st = con.createStatement();
ResultSet rs;
Float oldValue;
rs = st.executeQuery("SELECT * FROM " + table1 + " ORDER  by r");
assertTrue( rs.next() );
oldValue = (Float)rs.getObject("r");
assertNull(oldValue);
assertTrue( rs.next() );
oldValue = (Float)rs.getObject("r");
int count = 1;
while(rs.next()){
assertTrue( oldValue.compareTo( (Float)rs.getObject("r") ) < 0 );
oldValue = (Float)rs.getObject("r");
count++;
}
assertEquals( valueCount, count );init();
Connection con = AllTests.getConnection();
Statement st = con.createStatement();
ResultSet rs;
String oldValue;
rs = st.executeQuery("SELECT * FROM " + table1 + " t1 Inner join "+table2+" t2 on t1.c=t2.c2  ORDER  by v");
assertTrue( rs.next() );
oldValue = rs.getString("v");
int count = 1;
while(rs.next()){
assertTrue( oldValue.compareTo( rs.getString("v") ) < 0 );
oldValue = rs.getString("v");
count++;
}
assertEquals( valueCount, count );init();
Connection con = AllTests.getConnection();
Statement st = con.createStatement();
ResultSet rs;
String oldValue;
rs = st.executeQuery("SELECT * FROM " + table1 + " ORDER  by v ASC");
assertTrue( rs.next() );
oldValue = rs.getString("v");
assertNull(oldValue);
assertTrue( rs.next() );
oldValue = rs.getString("v");
int count = 1;
while(rs.next()){
String newValue = rs.getString("v");
assertTrue( oldValue.compareTo( newValue ) < 0 );
oldValue = newValue;
count++;
}
rs.close();
assertEquals( valueCount, count );init();
Connection con = AllTests.getConnection();
Statement st = con.createStatement();
ResultSet rs;
boolean oldValue;
rs = st.executeQuery("SELECT * FROM " + table1 + " ORDER  by b");
assertTrue( rs.next() );
oldValue = rs.getBoolean("b");
assertFalse(oldValue);
assertTrue(rs.wasNull());
assertTrue( rs.next() );
oldValue = rs.getBoolean("b");
assertFalse(oldValue);
assertFalse(rs.wasNull());
int count = 1;
while(!oldValue && rs.next()){
oldValue = rs.getBoolean("b");
assertFalse(rs.wasNull());
count++;
}
while(oldValue && rs.next()){
oldValue = rs.getBoolean("b");
assertFalse(rs.wasNull());
count++;
}
assertFalse(rs.next());
assertEquals( valueCount, count );Connection con = AllTests.getConnection();
Statement st = con.createStatement();
dropTable( con, "ManyCols" );
StringBuffer buf = new StringBuffer("Create Table ManyCols(");
for(int i=1; i<300; i++){
if(i!=1)buf.append(',');
buf.append("column").append(i).append(" int");
}
buf.append(')');
st.execute(buf.toString());
con.close();
con = AllTests.getConnection();
st = con.createStatement();
assertEquals(1,st.executeUpdate("Insert Into ManyCols(column260) Values(123456)"));
st.execute("Drop Table ManyCols");Connection con = AllTests.getConnection();
try{
Statement st = con.createStatement();
st.execute("Create Table Binary (b varbinary(20))");
st.execute("Truncate Table Binary");
st.execute("Insert Into Binary(b) Values(12345)");
ResultSet rs = st.executeQuery("Select * From Binary");
rs.next();
assertEquals(rs.getInt(1), 12345);
st.execute("Truncate Table Binary");
st.execute("Insert Into Binary(b) Values(1.2345)");
rs = st.executeQuery("Select * From Binary");
rs.next();
assertEquals( 1.2345, rs.getDouble(1), 0.0);
st.execute("Truncate Table Binary");
st.execute("Insert Into Binary(b) Values(cast(1.2345 as real))");
rs = st.executeQuery("Select * From Binary");
rs.next();
assertEquals( 1.2345F, rs.getFloat(1), 0.0);
}finally{
dropTable( con, "Binary" );
}Connection con = DriverManager.getConnection("jdbc:smallsql");
Statement st = con.createStatement();
try{
st.execute("Create Database anyTestDatabase");
}catch(SQLException ex){
st.execute("Drop Database anyTestDatabase");
throw ex;
}
st.execute("Drop Database anyTestDatabase");assertRowCount( 1, "Select 12, 'qwert'" );Connection con = DriverManager.getConnection("jdbc:smallsql");
assertEquals( "", con.getCatalog() );
con.setCatalog( AllTests.CATALOG );
assertEquals( AllTests.CATALOG, con.getCatalog() );
con.close();
con = DriverManager.getConnection("jdbc:smallsql");
assertEquals( "", con.getCatalog() );
con.createStatement().execute( "Use " + AllTests.CATALOG );
assertEquals( AllTests.CATALOG, con.getCatalog() );
con.close();
con = DriverManager.getConnection("jdbc:smallsql?dbpath=" + AllTests.CATALOG);
assertEquals( AllTests.CATALOG, con.getCatalog() );
con.close();Connection con = AllTests.getConnection();
Statement st = con.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_READ_ONLY );
ResultSet rs = st.executeQuery("Select 12, 'qwert' alias");
assertRSMetaData( rs, new String[]{"col1", "alias"}, new int[]{Types.INTEGER, Types.VARCHAR });
assertTrue( rs.isBeforeFirst() );
assertFalse( rs.isFirst() );
assertFalse( rs.isLast() );
assertFalse( rs.isAfterLast() );
assertTrue( rs.next() );
assertFalse( rs.isBeforeFirst() );
assertTrue( rs.isFirst() );
assertTrue( rs.isLast() );
assertFalse( rs.isAfterLast() );
assertFalse( rs.next() );
assertFalse( rs.isBeforeFirst() );
assertFalse( rs.isFirst() );
assertFalse( rs.isLast() );
assertTrue( rs.isAfterLast() );
assertTrue( rs.previous() );
assertFalse( rs.isBeforeFirst() );
assertTrue( rs.isFirst() );
assertTrue( rs.isLast() );
assertFalse( rs.isAfterLast() );
assertFalse( rs.previous() );
assertTrue( rs.isBeforeFirst() );
assertFalse( rs.isFirst() );
assertFalse( rs.isLast() );
assertFalse( rs.isAfterLast() );
assertTrue( rs.first() );
assertFalse( rs.isBeforeFirst() );
assertTrue( rs.isFirst() );
assertTrue( rs.isLast() );
assertFalse( rs.isAfterLast() );
assertTrue( rs.last() );
assertFalse( rs.isBeforeFirst() );
assertTrue( rs.isFirst() );
assertTrue( rs.isLast() );
assertFalse( rs.isAfterLast() );Connection con = AllTests.getConnection();
try{
con.createStatement().execute("Create Table Like (c varchar(20))");
con.createStatement().execute("Insert Into Like(c) Values('qwert1')");
con.createStatement().execute("Insert Into Like(c) Values('qwert2')");
con.createStatement().execute("Insert Into Like(c) Values('qwert2.5')");
con.createStatement().execute("Insert Into Like(c) Values('awert1')");
con.createStatement().execute("Insert Into Like(c) Values('awert2')");
con.createStatement().execute("Insert Into Like(c) Values('awert3')");
con.createStatement().execute("Insert Into Like(c) Values('qweSGSGSrt1')");
assertRowCount( 2, "Select * From Like Where c like 'qwert_'" );
assertRowCount( 3, "Select * From Like Where c like 'qwert%'" );
assertRowCount( 2, "Select * From Like Where c like 'qwert2%'" );
assertRowCount( 6, "Select * From Like Where c like '_wert%'" );
assertRowCount( 2, "Select * From Like Where c like 'qwe%rt1'" );
assertRowCount( 3, "Select * From Like Where c like 'qwe%rt_'" );
assertRowCount( 7, "Select * From Like Where c like '%_'" );
}finally{
dropTable( con, "Like" );
}Connection con = AllTests.getConnection();
try{
con.createStatement().execute("Create Table TestDistinct (i counter, v varchar(20), n bigint, b boolean)");
assertRowCount( 0, "Select * From TestDistinct" );
con.createStatement().execute("Insert Into TestDistinct(v,b) Values('qwert1',true)");
con.createStatement().execute("Insert Into TestDistinct(v,b) Values('qwert2',true)");
con.createStatement().execute("Insert Into TestDistinct(v,b) Values('qwert1',true)");
con.createStatement().execute("Insert Into TestDistinct(v,b) Values('qwert2',true)");
con.createStatement().execute("Insert Into TestDistinct(v,b) Values('qwert1',false)");
assertRowCount( 5, "Select b,n,v From TestDistinct" );
assertRowCount( 2, "Select Distinct v From TestDistinct t1" );
assertRowCount( 3, "Select Distinct b,n,v From TestDistinct" );
assertRowCount( 3, "Select Distinct b,n,v,i+null,23+i-i,'asdf'+v From TestDistinct" );
assertRowCount( 5, "Select All b,n,v From TestDistinct" );
}finally{
dropTable( con, "TestDistinct" );
}Connection con = AllTests.getConnection();
try{
con.createStatement().execute("Set Transaction Isolation Level Read Uncommitted");
assertEquals( Connection.TRANSACTION_READ_UNCOMMITTED, con.getTransactionIsolation() );
con.createStatement().execute("Set Transaction Isolation Level Read Committed");
assertEquals( Connection.TRANSACTION_READ_COMMITTED, con.getTransactionIsolation() );
con.createStatement().execute("Set Transaction Isolation Level Repeatable Read");
assertEquals( Connection.TRANSACTION_REPEATABLE_READ, con.getTransactionIsolation() );
con.createStatement().execute("Set Transaction Isolation Level Serializable");
assertEquals( Connection.TRANSACTION_SERIALIZABLE, con.getTransactionIsolation() );
}finally{
con.setTransactionIsolation( Connection.TRANSACTION_READ_COMMITTED );
}Connection con = AllTests.getConnection();
try{
con.createStatement().execute("Create Table CharEqualsVarchar (c char(10))");
assertRowCount( 0, "Select * From CharEqualsVarchar" );
con.createStatement().execute("Insert Into CharEqualsVarchar(c) Values('qwert1')");
assertRowCount( 1, "Select * From CharEqualsVarchar" );
assertRowCount( 1, "Select * From CharEqualsVarchar Where c = 'qwert1'" );
assertRowCount( 0, "Select * From CharEqualsVarchar Where c = 'qwert1        xxxx'" );
assertRowCount( 1, "Select * From CharEqualsVarchar Where c = cast('qwert1' as char(8))" );
assertRowCount( 1, "Select * From CharEqualsVarchar Where c = cast('qwert1' as char(12))" );
assertRowCount( 1, "Select * From CharEqualsVarchar Where c In('qwert1')" );
assertRowCount( 0, "Select * From CharEqualsVarchar Where c In('qwert1        xxxx')" );
PreparedStatement pr;
pr = con.prepareStatement( "Select * From CharEqualsVarchar Where c = ?" );
pr.setString( 1, "qwert1" );
assertRowCount( 1, pr.executeQuery() );
pr.setString( 1, "qwert1        xxxx" );
assertRowCount( 0, pr.executeQuery() );
}finally{
dropTable( con, "CharEqualsVarchar" );
}Connection con = AllTests.getConnection();
try{
con.createStatement().execute("Create Table InsertSelect (i counter, v varchar(20))");
assertEqualsRsValue( new Integer(0), "Select count(*) from InsertSelect");
con.createStatement().execute("Insert Into InsertSelect(v) Values('qwert')");
assertEqualsRsValue( new Integer(1), "Select count(*) from InsertSelect");
con.createStatement().execute("Insert Into InsertSelect(v) Select v From InsertSelect");
assertEqualsRsValue( new Integer(2), "Select count(*) from InsertSelect");
con.createStatement().execute("Insert Into InsertSelect(v) (Select v From InsertSelect)");
assertEqualsRsValue( new Integer(4), "Select count(*) from InsertSelect");
}finally{
dropTable( con, "InsertSelect" );
}Connection con = AllTests.getConnection();
try{
con.createStatement().execute("Create Table TestInSelect (i counter, v varchar(20), n bigint, b boolean)");
assertRowCount( 0, "Select * From TestInSelect WHere i In (Select i from TestInSelect)" );
con.createStatement().execute("Insert Into TestInSelect(v,b) Values('qwert1',true)");
assertRowCount( 1, "Select * From TestInSelect WHere i In (Select i from TestInSelect)" );
con.createStatement().execute("Insert Into TestInSelect(v,b) Values('qwert1',true)");
assertRowCount( 2, "Select * From TestInSelect WHere i In (Select i from TestInSelect)" );
assertRowCount( 1, "Select * From TestInSelect WHere i In (Select i from TestInSelect Where i>1)" );
assertRowCount( 1, "Select * From TestInSelect Where i IN ( 1, 1, 12345, 987654321)" );
assertRowCount( 2, "Select * From TestInSelect Where v IN ( null, '', 'qwert1', 'qwert1')" );
assertRowCount( 2, "Select * From TestInSelect Where v IN ( 'qwert1')" );
assertRowCount( 0, "Select * From TestInSelect Where '' IN ( 'qwert1')" );
assertRowCount( 2, "Select * From TestInSelect Where 'qwert1' IN ( 'qwert1', 'qwert2')" );
}finally{
dropTable( con, "TestInSelect" );
}final Object value = "UpdateAndScroll";
Object value1;
Object value2;
Connection con = AllTests.getConnection();
Statement st = con.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_UPDATABLE);
ResultSet rs = st.executeQuery("Select * From ResultSet");
assertTrue("start", rs.last());
value1 = rs.getObject("i");
rs.updateObject("c", value, Types.VARCHAR );
assertEquals("getObject", value, rs.getObject("c"));
assertEquals("getObject", value1, rs.getObject("i"));
assertTrue("first", rs.first());
assertNotSame("getObject", value, rs.getObject("c"));
assertTrue("start", rs.first());
rs.updateObject("c", value, Types.VARCHAR );
assertEquals("getObject", value, rs.getObject("c"));
assertTrue("next", rs.next());
assertNotSame("getObject", value, rs.getObject("c"));
assertTrue("start", rs.last());
rs.updateObject("c", value );
assertEquals("getObject", value, rs.getObject("c"));
assertTrue("previous", rs.previous());
assertNotSame("getObject", value, rs.getObject("c"));
assertTrue("start", rs.first());
rs.updateObject("c", value, Types.VARCHAR );
assertEquals("getObject", value, rs.getObject("c"));
assertTrue("last", rs.last());
assertNotSame("getObject", value, rs.getObject("c"));
assertTrue("start", rs.first());
rs.updateObject("c", value, Types.VARCHAR );
assertEquals("getObject", value, rs.getObject("c"));
rs.refreshRow();
assertNotSame("getObject", value, rs.getObject("c"));
assertTrue("start", rs.first());
value1 = rs.getObject("i");
value2 = rs.getObject("c");
rs.updateObject("c", value);
assertEquals("getObject", value, rs.getObject("c"));
rs.moveToInsertRow();
assertNull("new row", rs.getObject("i"));
assertNull("new row", rs.getObject("c"));
rs.updateObject("c", value);
assertEquals("getObject", value, rs.getObject("c"));
rs.moveToCurrentRow();
assertEquals("getObject", value1, rs.getObject("i"));
assertEquals("getObject", value2, rs.getObject("c"));Connection con = AllTests.getConnection();
Statement st = con.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_UPDATABLE);
ResultSet rs = st.executeQuery("Select * From ResultSet Where i>1");
assertTrue("next", rs.next());
assertFalse( rs.rowDeleted() );
rs.deleteRow();
assertTrue( rs.rowDeleted() );Connection con = AllTests.getConnection();
Statement st = con.createStatement();
ResultSet rs = st.executeQuery("Select * From ResultSet");
assertEquals(st, rs.getStatement());
rs.clearWarnings();
assertNull(rs.getWarnings());
rs.setFetchDirection(ResultSet.FETCH_FORWARD);
assertEquals( rs.getFetchDirection(), ResultSet.FETCH_FORWARD);
rs.setFetchDirection(ResultSet.FETCH_REVERSE);
assertEquals( rs.getFetchDirection(), ResultSet.FETCH_REVERSE);
rs.setFetchSize(123);
assertEquals( rs.getFetchSize(), 123);if(init) return;
Connection con = AllTests.getConnection();
Statement st = con.createStatement();
dropTable( con, "ResultSet");
st.execute("Create Table ResultSet (i int identity, c varchar(30))");
st = con.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_UPDATABLE);
ResultSet rs = st.executeQuery("Select * From ResultSet");
rs.moveToInsertRow();
rs.insertRow();
rs.moveToInsertRow();
rs.insertRow();
init = true;Connection con = AllTests.getConnection();
Statement st = con.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_UPDATABLE);
ResultSet rs;
rs = st.executeQuery("Select * From ResultSet");
assertTrue("next", rs.next());
assertEquals("getRow", 1, rs.getRow() );
int id = rs.getInt("i");
rs.updateShort("c", (short)123 );
assertEquals( (short)123, rs.getShort("c") );
assertEquals( id, rs.getInt("i") );
rs.updateRow();
assertEquals( (short)123, rs.getShort("c") );
assertFalse( rs.rowUpdated() );
assertFalse( rs.rowInserted() );
assertFalse( rs.rowDeleted() );
assertEquals("getRow", 1, rs.getRow() );
rs = st.executeQuery("Select * From ResultSet");
assertTrue("next", rs.next());
rs.updateByte("c", (byte)66 );
assertEquals( (byte)66, rs.getByte("c") );
rs.updateRow();
assertEquals( (short)66, rs.getShort("c") );Connection con = AllTests.getConnection();
Statement st = con.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_UPDATABLE);
ResultSet rs = st.executeQuery("Select * From ResultSet Where 1=0");
assertTrue("isBeforeFirst", rs.isBeforeFirst() );
assertTrue("isAfterLast", rs.isAfterLast() );
assertEquals("getRow", 0, rs.getRow() );
rs.moveToInsertRow();
rs.insertRow();
rs.beforeFirst();
assertTrue("isBeforeFirst", rs.isBeforeFirst() );
assertFalse("isAfterLast", rs.isAfterLast() );
assertEquals("getRow", 0, rs.getRow() );
assertTrue("next", rs.next() );
assertTrue("isFirst", rs.isFirst() );
assertTrue("rowInserted", rs.rowInserted() );
assertEquals("getRow", 1, rs.getRow() );
assertTrue("isLast", rs.isLast() );
assertFalse("next", rs.next() );
assertFalse("isBeforeFirst", rs.isBeforeFirst() );
assertTrue("isAfterLast", rs.isAfterLast() );
assertEquals("getRow", 0, rs.getRow() );
assertTrue("first", rs.first() );
assertEquals("getRow", 1, rs.getRow() );
assertFalse("previous", rs.previous() );
assertEquals("getRow", 0, rs.getRow() );
assertTrue("isBeforeFirst", rs.isBeforeFirst() );
assertFalse("isAfterLast", rs.isAfterLast() );
assertTrue("last", rs.last() );
assertEquals("getRow", 1, rs.getRow() );
assertTrue("isLast", rs.isLast() );
rs.afterLast();
assertFalse("isBeforeFirst", rs.isBeforeFirst() );
assertTrue("isAfterLast", rs.isAfterLast() );
assertEquals("getRow", 0, rs.getRow() );Connection con = AllTests.getConnection();
Statement st = con.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_UPDATABLE);
ResultSet rs = st.executeQuery("Select i,max(c) From ResultSet Group By i HAVING i=1");
assertEquals("getConcurrency",ResultSet.CONCUR_READ_ONLY, rs.getConcurrency());
assertTrue("isBeforeFirst", rs.isBeforeFirst() );
assertFalse("isAfterLast", rs.isAfterLast() );
assertEquals("getRow", 0, rs.getRow() );
rs.beforeFirst();
assertTrue("isBeforeFirst", rs.isBeforeFirst() );
assertFalse("isAfterLast", rs.isAfterLast() );
assertEquals("getRow", 0, rs.getRow() );
assertTrue("next", rs.next() );
assertTrue("isFirst", rs.isFirst() );
assertFalse("rowInserted", rs.rowInserted() );
assertEquals("getRow", 1, rs.getRow() );
assertTrue("isLast", rs.isLast() );
assertFalse("next", rs.next() );
assertFalse("isBeforeFirst", rs.isBeforeFirst() );
assertTrue("isAfterLast", rs.isAfterLast() );
assertEquals("getRow", 0, rs.getRow() );
assertTrue("first", rs.first() );
assertEquals("getRow", 1, rs.getRow() );
assertFalse("previous", rs.previous() );
assertEquals("getRow", 0, rs.getRow() );
assertTrue("isBeforeFirst", rs.isBeforeFirst() );
assertFalse("isAfterLast", rs.isAfterLast() );
assertTrue("last", rs.last() );
assertEquals("getRow", 1, rs.getRow() );
assertTrue("isLast", rs.isLast() );
rs.afterLast();
assertFalse("isBeforeFirst", rs.isBeforeFirst() );
assertTrue("isAfterLast", rs.isAfterLast() );
assertEquals("getRow", 0, rs.getRow() );assertEquals(0, rs.getRow());
assertTrue(rs.absolute(2));
assertEquals("qwert2", rs.getString("v"));
assertEquals(2, rs.getRow());
assertTrue(rs.relative(-1));
assertEquals("qwert1", rs.getString("v"));
assertEquals(1, rs.getRow());
assertTrue(rs.absolute(1));
assertEquals("qwert1", rs.getString("v"));
assertEquals(1, rs.getRow());
assertTrue(rs.isFirst());
assertTrue(rs.relative(1));
assertEquals("qwert2", rs.getString("v"));
assertEquals(2, rs.getRow());
assertFalse(rs.isLast());
assertFalse(rs.isFirst());
assertTrue(rs.absolute(-1));
assertEquals("qwert3", rs.getString("v"));
assertEquals(3, rs.getRow());
assertTrue(rs.isLast());
assertFalse(rs.isFirst());
assertTrue(rs.relative(0));
assertEquals("qwert3", rs.getString("v"));
assertEquals(3, rs.getRow());
assertTrue(rs.isLast());
assertFalse(rs.isFirst());
assertFalse(rs.absolute(4));
assertEquals(0, rs.getRow());
assertFalse(rs.isLast());
assertFalse(rs.isFirst());
assertFalse(rs.isBeforeFirst());
assertTrue(rs.isAfterLast());
assertTrue(rs.last());
assertEquals(3, rs.getRow());
assertTrue(rs.isLast());
assertFalse(rs.isFirst());
assertFalse(rs.absolute(-4));
assertEquals(0, rs.getRow());
assertFalse(rs.isLast());
assertFalse(rs.isFirst());
assertTrue(rs.isBeforeFirst());
assertFalse(rs.isAfterLast());
assertFalse(rs.relative(4));
assertEquals(0, rs.getRow());
assertFalse(rs.isLast());
assertFalse(rs.isFirst());
assertFalse(rs.isBeforeFirst());
assertTrue(rs.isAfterLast());
assertFalse(rs.relative(-4));
assertEquals(0, rs.getRow());
assertFalse(rs.isLast());
assertFalse(rs.isFirst());
assertTrue(rs.isBeforeFirst());
assertFalse(rs.isAfterLast());con.setAutoCommit(false);
for(int r=row; r < 4; r++){
rs.moveToInsertRow();
rs.updateString( "v", "qwert" + r);
rs.insertRow();
}
assertTrue( rs.last() );
assertEquals( 3, rs.getRow() );
rs.beforeFirst();
assertRowCount( 3, rs );
rs.beforeFirst();
testAbsoluteRelativeAssert(rs);
con.rollback();
assertRowCount( row - 1, con.createStatement().executeQuery("Select * from Scrollable"));
rs.last();
assertTrue( rs.rowDeleted() );
assertTrue( rs.rowInserted() );
rs.beforeFirst();
assertRowCount( 3, rs );
con.setAutoCommit(true);assertFalse( "isFirst", rs.isFirst() );
assertTrue( rs.isBeforeFirst() );
assertFalse( "There should be no rows:", rs.first());
assertFalse( "isFirst", rs.isFirst() );
assertTrue( rs.isBeforeFirst() );
try{
rs.getString("v");
fail("SQLException 'No current row' should be throw");
}catch(SQLException ex){
assertSQLException("01000", 0, ex);
}Connection con = AllTests.getConnection();
try{
con.createStatement().execute("Create Table Scrollable (i int Identity primary key, v varchar(20))");
Statement st = con.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_UPDATABLE);
for(int row = 1; row < 4; row++){
testUpdatableAssert( con, st.executeQuery("Select * from Scrollable"), row );
testUpdatableAssert( con, st.executeQuery("Select * from Scrollable Order By i"), row );
testUpdatableAssert( con, st.executeQuery("Select * from Scrollable Where 1 = 1"), row );
testUpdatableAssert( con, st.executeQuery("Select * from Scrollable Where 1 = 1 Order By i"), row );
con.createStatement().execute("Insert Into Scrollable(v) Values('qwert" +row + "')");
}
}finally{
dropTable( con, "Scrollable");
}assertTrue( rs.isBeforeFirst() );
assertTrue( rs.isAfterLast() );
rs.afterLast();
assertTrue( rs.isAfterLast() );
assertFalse("There should be no rows:", rs.previous());
try{
rs.getString("v");
fail("SQLException 'No current row' should be throw");
}catch(SQLException ex){
assertSQLException("01000", 0, ex);
}assertFalse("There should be no rows:", rs.next());
try{
rs.getString("v");
fail("SQLException 'No current row' should be throw");
}catch(SQLException ex){
assertSQLException( "01000", 0, ex);
}assertFalse( "There should be no rows:", rs.last());
assertFalse( "isLast", rs.isLast());
try{
rs.getString("v");
fail("SQLException 'No current row' should be throw");
}catch(SQLException ex){
assertSQLException( "01000", 0, ex );
}Connection con = AllTests.getConnection();
try{
con.createStatement().execute("Create Table Scrollable (i counter, v varchar(20))");
assertRowCount( 0, "Select * from Scrollable");
con.createStatement().execute("Insert Into Scrollable(v) Values('qwert')");
assertRowCount( 1, "Select * from Scrollable");
assertRowCount( 0, "Select * from Scrollable Where 1=0");
Statement st = con.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_UPDATABLE);
testPreviousWithWhereAssert( st.executeQuery("Select * from Scrollable Where 1=0") );
testPreviousWithWhereAssert( st.executeQuery("Select * from Scrollable Where 1=0 Order By v") );
testPreviousWithWhereAssert( st.executeQuery("Select v from Scrollable Where 1=0 Group By v") );
testPreviousWithWhereAssert( st.executeQuery("Select v from Scrollable Where 1=0 Group By v Order By v") );
testPreviousWithWhereAssert( st.executeQuery("Select v from Scrollable Group By v Having 1=0 Order By v") );
}finally{
dropTable( con, "Scrollable");
}Connection con = AllTests.getConnection();
try{
con.createStatement().execute("Create Table Scrollable (i counter, v varchar(20))");
assertRowCount( 0, "Select * from Scrollable");
con.createStatement().execute("Insert Into Scrollable(v) Values('qwert')");
assertRowCount( 1, "Select * from Scrollable");
assertRowCount( 0, "Select * from Scrollable Where 1=0");
Statement st = con.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_UPDATABLE);
testLastWithWhereAssert( st.executeQuery("Select * from Scrollable Where 1=0") );
testLastWithWhereAssert( st.executeQuery("Select * from Scrollable Where 1=0 Order By v") );
testLastWithWhereAssert( st.executeQuery("Select v from Scrollable Where 1=0 Order By v") );
testLastWithWhereAssert( st.executeQuery("Select v from Scrollable Where 1=0 Group By v Order By v") );
}finally{
dropTable( con, "Scrollable");
}Connection con = AllTests.getConnection();
try{
con.createStatement().execute("Create Table Scrollable (i counter, v varchar(20))");
assertRowCount( 0, "Select * from Scrollable");
con.createStatement().execute("Insert Into Scrollable(v) Values('qwert1')");
con.createStatement().execute("Insert Into Scrollable(v) Values('qwert2')");
con.createStatement().execute("Insert Into Scrollable(v) Values('qwert3')");
Statement st = con.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_UPDATABLE);
testAbsoluteRelativeAssert( st.executeQuery("Select * from Scrollable") );
testAbsoluteRelativeAssert( st.executeQuery("Select * from Scrollable Order By i") );
testAbsoluteRelativeAssert( st.executeQuery("Select v from Scrollable Group By v") );
testAbsoluteRelativeAssert( st.executeQuery("Select v from Scrollable Group By v Order By v") );
}finally{
dropTable( con, "Scrollable");
}Connection con = AllTests.getConnection();
try{
con.createStatement().execute("Create Table Scrollable (i counter, v varchar(20))");
assertRowCount( 0, "Select * from Scrollable");
con.createStatement().execute("Insert Into Scrollable(v) Values('qwert')");
assertRowCount( 1, "Select * from Scrollable");
assertRowCount( 0, "Select * from Scrollable Where 1=0");
Statement st = con.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_UPDATABLE);
testFirstWithWhereAssert( st.executeQuery("Select * from Scrollable Where 1=0") );
testFirstWithWhereAssert( st.executeQuery("Select * from Scrollable Where 1=0 Order By v") );
testFirstWithWhereAssert( st.executeQuery("Select v from Scrollable Where 1=0 Group By v") );
testFirstWithWhereAssert( st.executeQuery("Select v from Scrollable Where 1=0 Group By v Order By v") );
}finally{
dropTable( con, "Scrollable");
}Connection con = AllTests.getConnection();
try{
con.createStatement().execute("Create Table Scrollable (i counter, v varchar(20))");
assertRowCount( 0, "Select * from Scrollable");
con.createStatement().execute("Insert Into Scrollable(v) Values('qwert')");
assertRowCount( 1, "Select * from Scrollable");
assertRowCount( 0, "Select * from Scrollable Where 1=0");
Statement st = con.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_UPDATABLE);
testNextWithWhereAssert( st.executeQuery("Select * from Scrollable Where 1=0") );
testNextWithWhereAssert( st.executeQuery("Select * from Scrollable Where 1=0 Order By v") );
testNextWithWhereAssert( st.executeQuery("Select v from Scrollable Where 1=0 Group By v") );
testNextWithWhereAssert( st.executeQuery("Select v from Scrollable Where 1=0 Group By v Order By v") );
}finally{
dropTable( con, "Scrollable");
}Connection con = AllTests.getConnection();
Statement st = con.createStatement();
assertEquals(con, st.getConnection() );Connection con = AllTests.getConnection();
Statement st = con.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_UPDATABLE);
assertEquals(ResultSet.TYPE_SCROLL_SENSITIVE, st.getResultSetType());
assertEquals(ResultSet.CONCUR_UPDATABLE, st.getResultSetConcurrency());
ResultSet rs = st.executeQuery("Select * From statement");
assertEquals(ResultSet.TYPE_SCROLL_SENSITIVE, rs.getType());
assertEquals(ResultSet.CONCUR_UPDATABLE, rs.getConcurrency());Connection con = AllTests.getConnection();
Statement st = con.createStatement();
assertEquals("Result Length wrong", 0, st.executeBatch().length );
st.clearBatch();
st.addBatch("Bla Bla");
try {
st.executeBatch();
} catch (BatchUpdateException ex) {
assertEquals("Result Length wrong",1,ex.getUpdateCounts().length);
}
st.clearBatch();
int count = 10;
for(int i=1; i<=count; i++){
st.addBatch("Insert Into statement(c) Values('batch"+i+"')");
}
int[] result = st.executeBatch();
assertEquals("Result Length wrong", count, result.length);
for(int i=0; i<count; i++){
assertEquals("Update Count", 1, result[i]);
}
assertRowCount(10, "Select * From statement");if(init) return;
Connection con = AllTests.getConnection();
Statement st = con.createStatement();
dropTable( con, "statement");
st.execute("Create Table statement (c varchar(30), i counter)");
init = true;Connection con = AllTests.getConnection();
Statement st = con.createStatement();
st.setMaxRows(5);
ResultSet rs = st.executeQuery("Select * From statement");
assertEquals("Statement.getResultSet", rs, st.getResultSet());
assertRowCount(5,rs);
assertRowCount(4,"Select top 4 * From statement");
assertRowCount(3,"Select * From statement Limit 3");
assertRowCount(2,"Select * From statement Order By c ASC Limit 2");
assertRowCount(0,"Select top 0 * From statement");
st = con.createStatement( ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE );
rs = st.executeQuery("Select Top 0 * From statement");
assertFalse( "last()", rs.last() );
PreparedStatement pr = con.prepareStatement("Select * From statement");
pr.setMaxRows(6);
rs = pr.executeQuery();
assertEquals("PreparedStatement.getResultSet", rs, pr.getResultSet());
assertRowCount(6,rs);
pr.setMaxRows(3);
rs = pr.executeQuery();
assertRowCount(3,rs);
pr.setMaxRows(4);
rs = pr.executeQuery();
assertRowCount(4,rs);Connection con = AllTests.getConnection();
Statement st = con.createStatement();
ResultSet rs = st.executeQuery("Select * From statement");
assertEquals( "getResultSet()", rs, st.getResultSet() );
assertEquals( "getUpdateCount()", -1, st.getUpdateCount() );
assertFalse( st.getMoreResults() );
try{
rs.next();
fail("ResultSet should be closed");
}catch(SQLException ex){
assertSQLException("01000", 0, ex);
}
assertNull( "getResultSet()", st.getResultSet() );
assertEquals( "getUpdateCount()", -1, st.getUpdateCount() );
rs = st.executeQuery("Select * From statement");
assertEquals( "getResultSet()", rs, st.getResultSet() );
assertEquals( "getUpdateCount()", -1, st.getUpdateCount() );
assertFalse( st.getMoreResults(Statement.KEEP_CURRENT_RESULT) );
assertTrue(rs.next());
assertNull( "getResultSet()", st.getResultSet() );
assertEquals( "getUpdateCount()", -1, st.getUpdateCount() );
int count = st.executeUpdate("Update statement set c = c");
assertTrue( "Update Erfolgreich", count>0 );
assertNull( "getResultSet()", st.getResultSet() );
assertEquals( "getUpdateCount()", count, st.getUpdateCount() );
assertFalse( st.getMoreResults() );
assertNull( "getResultSet()", st.getResultSet() );
assertEquals( "getUpdateCount()", -1, st.getUpdateCount() );Connection con = AllTests.getConnection();
Statement st = con.createStatement();
ResultSet rs;
st.execute("Insert Into statement(c) Values('key1')", Statement.NO_GENERATED_KEYS);
try{
st.getGeneratedKeys();
fail("NO_GENERATED_KEYS");
}catch(SQLException ex){
assertSQLException("01000", 0, ex);
}
assertEquals("UpdateCount", 1, st.getUpdateCount());
assertNull("getResultSet", st.getResultSet());
st.execute("Insert Into statement(c) Values('key2')", Statement.RETURN_GENERATED_KEYS);
rs = st.getGeneratedKeys();
assertNotNull("RETURN_GENERATED_KEYS", rs);
assertEquals("ColumnCount",1,rs.getMetaData().getColumnCount());
assertEquals("ColumnCount","i",rs.getMetaData().getColumnName(1));
assertTrue(rs.next());
assertEqualsRsValue( new Long(rs.getLong(1)), rs, false );
assertFalse(rs.next());
assertEquals(1,st.executeUpdate("Insert Into statement(c) Values('key3')", Statement.RETURN_GENERATED_KEYS));
rs = st.getGeneratedKeys();
assertNotNull("RETURN_GENERATED_KEYS", rs);
assertEquals("ColumnCount",1,rs.getMetaData().getColumnCount());
assertEquals("ColumnCount","i",rs.getMetaData().getColumnName(1));
assertRowCount(1,rs);
st.execute("Insert Into statement(c) Values('key4')", new int[]{2,1});
rs = st.getGeneratedKeys();
assertNotNull("RETURN_GENERATED_KEYS", rs);
assertEquals("ColumnCount",2,rs.getMetaData().getColumnCount());
assertRowCount(1,rs);
assertEquals(1,st.executeUpdate("Insert Into statement(c) Values('key5')", new int[]{2}));
rs = st.getGeneratedKeys();
assertNotNull("RETURN_GENERATED_KEYS", rs);
assertEquals("ColumnCount",1,rs.getMetaData().getColumnCount());
assertEquals("ColumnCount","i",rs.getMetaData().getColumnName(1));
assertRowCount(1,rs);
st.execute("Insert Into statement(c) Values('key6')", new String[]{"c","i"});
rs = st.getGeneratedKeys();
assertNotNull("RETURN_GENERATED_KEYS", rs);
assertEquals("ColumnCount",2,rs.getMetaData().getColumnCount());
assertRowCount(1,rs);
assertEquals(1,st.executeUpdate("Insert Into statement(c) Values('key7')", new String[]{"i"}));
rs = st.getGeneratedKeys();
assertNotNull("RETURN_GENERATED_KEYS", rs);
assertEquals("ColumnCount",1,rs.getMetaData().getColumnCount());
assertEquals("ColumnCount","i",rs.getMetaData().getColumnName(1));
assertRowCount(1,rs);Connection con = AllTests.getConnection();
ResultSet rs;
PreparedStatement pr = con.prepareStatement("Insert Into statement(c) Values('key1')", Statement.NO_GENERATED_KEYS);
pr.execute();
try{
pr.getGeneratedKeys();
fail("NO_GENERATED_KEYS");
}catch(SQLException ex){
assertSQLException("01000", 0, ex);
}
assertEquals("UpdateCount", 1, pr.getUpdateCount());
assertNull("getResultSet", pr.getResultSet());
pr.close();
pr = con.prepareStatement("Insert Into statement(c) Values('key2')", Statement.RETURN_GENERATED_KEYS);
pr.execute();
rs = pr.getGeneratedKeys();
assertNotNull("RETURN_GENERATED_KEYS", rs);
assertEquals("ColumnCount",1,rs.getMetaData().getColumnCount());
assertEquals("ColumnCount","i",rs.getMetaData().getColumnName(1));
assertRowCount(1,rs);
pr = con.prepareStatement("Insert Into statement(c) Values('key3')", Statement.RETURN_GENERATED_KEYS);
assertEquals(1,pr.executeUpdate());
rs = pr.getGeneratedKeys();
assertNotNull("RETURN_GENERATED_KEYS", rs);
assertEquals("ColumnCount",1,rs.getMetaData().getColumnCount());
assertEquals("ColumnCount","i",rs.getMetaData().getColumnName(1));
assertRowCount(1,rs);
pr = con.prepareStatement("Insert Into statement(c) Values('key4')", new int[]{2,1});
pr.execute();
rs = pr.getGeneratedKeys();
assertNotNull("RETURN_GENERATED_KEYS", rs);
assertEquals("ColumnCount",2,rs.getMetaData().getColumnCount());
assertRowCount(1,rs);
pr = con.prepareStatement("Insert Into statement(c) Values('key5')", new int[]{2});
assertEquals(1,pr.executeUpdate());
rs = pr.getGeneratedKeys();
assertNotNull("RETURN_GENERATED_KEYS", rs);
assertEquals("ColumnCount",1,rs.getMetaData().getColumnCount());
assertEquals("ColumnCount","i",rs.getMetaData().getColumnName(1));
assertRowCount(1,rs);
pr = con.prepareStatement("Insert Into statement(c) Values('key6')", new String[]{"c","i"});
pr.execute();
rs = pr.getGeneratedKeys();
assertNotNull("RETURN_GENERATED_KEYS", rs);
assertEquals("ColumnCount",2,rs.getMetaData().getColumnCount());
assertRowCount(1,rs);
pr = con.prepareStatement("Insert Into statement(c) Values('key7')", new String[]{"i"});
assertEquals(1,pr.executeUpdate());
rs = pr.getGeneratedKeys();
assertNotNull("RETURN_GENERATED_KEYS", rs);
assertEquals("ColumnCount",1,rs.getMetaData().getColumnCount());
assertEquals("ColumnCount","i",rs.getMetaData().getColumnName(1));
assertRowCount(1,rs);Connection con = AllTests.getConnection();
Statement st = con.createStatement();
st.setFetchDirection(ResultSet.FETCH_FORWARD);
assertEquals( st.getFetchDirection(), ResultSet.FETCH_FORWARD);
st.setFetchDirection(ResultSet.FETCH_REVERSE);
assertEquals( st.getFetchDirection(), ResultSet.FETCH_REVERSE);
st.setFetchSize(123);
assertEquals( st.getFetchSize(), 123);Connection con = AllTests.getConnection();
Statement st = con.createStatement();
st.clearWarnings();
assertNull(st.getWarnings());
st.setQueryTimeout(5);
assertEquals("QueryTimeout", 5, st.getQueryTimeout() );
st.setMaxFieldSize(100);
assertEquals("MaxFieldSize", 100, st.getMaxFieldSize() );Connection con = AllTests.getConnection();
Statement st = con.createStatement();
assertEquals("Update Count:", 10, st.executeUpdate("Insert Into statement(c) Values('abc1'),('abc2'),('abc3'),('abc4'),('abc5'),('abc6'),('abc7'),('abc8'),('abc9'),('abc10')"));Connection con = AllTests.getConnection();
Statement st = con.createStatement();
st.execute("Truncate table statement");
assertRowCount(0, "Select * From statement");try{
Connection con2 = AllTests.createConnection();
Statement st2 = con2.createStatement();
int count = st2.executeUpdate("UPDATE ConcurrentWrite SET value = value + 1");
assertEquals("Update Count", 1, count);
con2.close();
}catch(Throwable ex){
throwable = ex;
}ArrayList threadList = new ArrayList();
throwable = null;
Connection con = AllTests.getConnection();
Statement st = con.createStatement();
try{
st.execute("CREATE TABLE ConcurrentWrite( value int)");
st.execute("INSERT INTO ConcurrentWrite(value) Values(0)");
for(int i = 0; i < 200; i++){
Thread thread = new Thread(new Runnable(){
public void run(){
try{
Connection con2 = AllTests.createConnection();
Statement st2 = con2.createStatement();
int count = st2.executeUpdate("UPDATE ConcurrentWrite SET value = value + 1");
assertEquals("Update Count", 1, count);
con2.close();
}catch(Throwable ex){
throwable = ex;
}
}
});
threadList.add(thread);
thread.start();
}
for(int i = 0; i < threadList.size(); i++){
Thread thread = (Thread)threadList.get(i);
thread.join(5000);
}
if(throwable != null){
throw throwable;
}
assertEqualsRsValue(new Integer(200), "SELECT value FROM ConcurrentWrite");
}finally{
dropTable(con, "ConcurrentWrite");
}try{
Statement st2 = con.createStatement();
int count = st2.executeUpdate("UPDATE ConcurrentWrite SET value = value + 1");
assertEquals("Update Count", 1, count);
}catch(Throwable ex){
throwable = ex;
}ArrayList threadList = new ArrayList();
throwable = null;
final String sql = "Select * From table_OrderBy1";
final Connection con = AllTests.getConnection();
Statement st = con.createStatement();
ResultSet rs = st.executeQuery("Select * From table_OrderBy1");
int count = 0;
while(rs.next()){
count++;
}
final int rowCount = count;
for(int i = 0; i < 200; i++){
Thread thread = new Thread(new Runnable(){
public void run(){
try{
assertRowCount(rowCount, sql);
}catch(Throwable ex){
throwable = ex;
}
}
});
threadList.add(thread);
thread.start();
}
for(int i = 0; i < threadList.size(); i++){
Thread thread = (Thread)threadList.get(i);
thread.join(5000);
}
if(throwable != null){
throw throwable;
}try{
assertRowCount(rowCount, sql);
}catch(Throwable ex){
throwable = ex;
}ArrayList threadList = new ArrayList();
throwable = null;
final Connection con = AllTests.getConnection();
Statement st = con.createStatement();
try{
st.execute("CREATE TABLE ConcurrentWrite( value int)");
st.execute("INSERT INTO ConcurrentWrite(value) Values(0)");
for(int i = 0; i < 200; i++){
Thread thread = new Thread(new Runnable(){
public void run(){
try{
Statement st2 = con.createStatement();
int count = st2.executeUpdate("UPDATE ConcurrentWrite SET value = value + 1");
assertEquals("Update Count", 1, count);
}catch(Throwable ex){
throwable = ex;
}
}
});
threadList.add(thread);
thread.start();
}
for(int i = 0; i < threadList.size(); i++){
Thread thread = (Thread)threadList.get(i);
thread.join(5000);
}
if(throwable != null){
throw throwable;
}
assertEqualsRsValue(new Integer(200), "SELECT value FROM ConcurrentWrite");
}finally{
dropTable(con, "ConcurrentWrite");
}try {
stat.execute("DROP TABLE " + TABLE_NAME);
} catch (SQLException e) {
out.println("REGULAR: " + e.getMessage() + '\n');
}try {
stat.executeQuery(sql);
fail(failureMessage);
}
catch (SQLException e) {
String foundMsg = e.getMessage();
String assertMsg = MessageFormat.format(
"Unexpected error: [{0}], expected: [{1}]",
new Object[] { foundMsg, expected });
assertTrue(assertMsg, foundMsg.indexOf(expected) > -1);
out.println("REGULAR: " + e.getMessage() + '\n');
}stat.execute(
"CREATE TABLE " + TABLE_NAME +
" (id INT, myint INT)");
stat.execute(
"INSERT INTO " + TABLE_NAME + " VALUES (1, 2)");
stat.execute(
"INSERT INTO " + TABLE_NAME + " VALUES (1, 3)");final String SQL_1 =
"SELECT 10/2--mycomment\n" +
" , -- mycomment    \r\n" +
"id, SUM(myint)--my comment  \n\n" +
"FROM " + TABLE_NAME + " -- my other comment \r \r" +
"GROUP BY id --mycommentC\n" +
"--   myC    omment  E    \n" +
"ORDER BY id \r" +
"--myCommentD   \r\r\r";
successTest(SQL_1);
final String SQL_2 =
"SELECT 10/2 - - this must fail ";
failureTest(SQL_2, "Tokenized not-comment as a line-comment.");if (conn != null) {
dropTable();
stat.close();
conn.close();
}ResultSet rs_1 = stat.executeQuery(sql);
rs_1.next();
rs_1.close();try {
stat.executeQuery(sql);
fail(failureMessage);
}
catch (SQLException e) {
out.println("REGULAR: " + e.getMessage() + '\n');
}final String SQL_1 =
"SELECT 10/2, id, SUM(myint)
FROM " + TABLE_NAME + " -- my comment
GROUP BY id ORDER BY id\r" +
" -- somment\r\n";
successTest(SQL_1);
final String SQL_2 =
"SELECT 10/2 / * this must fail */";
failureTest(SQL_2, "Tokenized not-comment as a multiline-comment.");
final String SQL_3 =
"SELECT 10/2 /* this must fail ";
failureTest(SQL_3,
"Uncomplete end multiline comment not recognized.",
"Missing end comment mark");if (! init) {
conn = AllTests.createConnection("?locale=en", null);
stat = conn.createStatement();
init = true;
}
dropTable();
createTable();Connection con1 = AllTests.getConnection();
Connection con2 = AllTests.createConnection();
try{
con2.setTransactionIsolation( Connection.TRANSACTION_READ_COMMITTED );
con1.createStatement().execute("Create Table transactions (i int identity, v varchar(20))");
assertRowCount( 0, "Select * from transactions");
con1.setAutoCommit(false);
con1.createStatement().execute("Insert Into transactions(v) Values('qwert2')");
ResultSet rs2 = con2.createStatement().executeQuery("Select count(*) from transactions");
assertTrue( rs2.next() );
assertEquals( 0, rs2.getInt(1) );
}finally{
dropTable(con1, "transactions");
con1.setAutoCommit(true);
con2.close();
}Connection con1 = AllTests.getConnection();
Connection con2 = AllTests.createConnection();
try{
con1.createStatement().execute("Create Table transactions (i int identity, v varchar(20))");
assertRowCount( 0, "Select * from transactions");
con1.createStatement().execute("Insert Into transactions(v) Values('qwert2')");
assertRowCount( 1, "Select * from transactions");
con1.setTransactionIsolation( Connection.TRANSACTION_SERIALIZABLE );
con1.setAutoCommit(false);
ResultSet rs1 = con1.createStatement().executeQuery("Select count(*) from transactions");
assertTrue( rs1.next() );
assertEquals( "Count(*)", 1, rs1.getInt(1) );
ResultSet rs2 = con2.createStatement().executeQuery("Select count(*) from transactions");
assertTrue( rs2.next() );
assertEquals( "Count(*)", 1, rs2.getInt(1) );
try{
con2.createStatement().execute("Insert Into transactions(v) Values('qwert3')");
fail("TRANSACTION_SERIALIZABLE does not lock the table");
}catch(SQLException ex){
assertSQLException("01000", 0, ex);
}
}finally{
con2.close();
dropTable(con1, "transactions");
con1.setAutoCommit(true);
}Connection con1 = AllTests.getConnection();
Connection con2 = AllTests.createConnection();
try{
con1.createStatement().execute("Create Table transactions (i int identity, v varchar(20))");
con1.createStatement().execute("Insert Into transactions(v) Values('qwert1')");
con1.setAutoCommit(false);
con1.createStatement().execute("Update transactions Set v = 'qwert'");
long time = System.currentTimeMillis();
try{
con2.createStatement().executeQuery("Select count(*) from transactions");
}catch(SQLException ex){
assertSQLException("01000", 0, ex);
}
assertTrue("Wait time to small", System.currentTimeMillis()-time>=5000);
}finally{
con2.close();
con1.setAutoCommit(true);
dropTable(con1, "transactions");
}Connection con = AllTests.getConnection();
testInsertRow_Last(con, false);
testInsertRow_Last(con, true);
con.setAutoCommit(false);
testInsertRow_Last(con, false);
con.setAutoCommit(true);
con.setAutoCommit(false);
testInsertRow_Last(con, true);
con.setAutoCommit(true);Connection con = AllTests.getConnection();
try{
con.createStatement().execute("Create Table transactions (i int identity, v varchar(20))");
assertRowCount( 0, "Select * from transactions");
con.createStatement().execute("Insert Into transactions(v) Values('qwert2')");
ResultSet rs = con.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_UPDATABLE)
.executeQuery("Select * from transactions Where v = 'qwert'");
rs.moveToInsertRow();
rs.updateString("v", "qwert");
rs.insertRow();
rs.beforeFirst();
assertTrue( rs.next() );
assertEquals("qwert", rs.getString("v"));
assertFalse( rs.next() );
}finally{
try{
con.createStatement().execute("Drop Table transactions");
}catch(Throwable e){e.printStackTrace();}
}try{
con.createStatement().execute("Create Table transactions (i int identity, v varchar(20))");
assertRowCount( 0, "Select * from transactions");
con.createStatement().execute("Insert Into transactions(v) Values('qwert')");
ResultSet rs = con.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_UPDATABLE)
.executeQuery("Select * from transactions Where 1=0");
if(callLastBefore) rs.last();
rs.moveToInsertRow();
rs.updateString("v", "qwert2");
rs.insertRow();
rs.last();
assertEquals("qwert2", rs.getString("v"));
assertFalse( rs.next() );
assertTrue( rs.previous() );
assertEquals("qwert2", rs.getString("v"));
rs.beforeFirst();
assertTrue( rs.next() );
assertEquals("qwert2", rs.getString("v"));
assertFalse( rs.next() );
}finally{
try{
con.createStatement().execute("Drop Table transactions");
}catch(Throwable e){e.printStackTrace();}
}Connection con = AllTests.getConnection();
Connection con2 = AllTests.createConnection();
try{
con.setAutoCommit(false);
con.createStatement().execute("create table transactions (ID  INTEGER NOT NULL, Name VARCHAR(100), FirstName VARCHAR(100), Points INTEGER, LicenseID INTEGER, PRIMARY KEY(ID))");
con.commit();
con2.setAutoCommit(false);
PreparedStatement pr = con2.prepareStatement("insert into transactions (id,Name,FirstName,Points,LicenseID) values (?,?,?,?,?)");
pr.setInt( 		1, 0 );
pr.setString( 	2, "Pilot_1" );
pr.setString( 	3, "Herkules" );
pr.setInt( 		4, 1 );
pr.setInt( 		5, 1 );
pr.addBatch();
pr.executeBatch();
assertRowCount( 0, "Select * from transactions");
con2.commit();
assertRowCount( 1, "Select * from transactions");
}finally{
con2.close();
try{
con.createStatement().execute("Drop Table transactions");
}catch(Throwable e){e.printStackTrace();}
con.setAutoCommit(true);
}Connection con1 = AllTests.getConnection();
Connection con2 = AllTests.createConnection();
try{
con2.setTransactionIsolation( Connection.TRANSACTION_READ_UNCOMMITTED );
con1.createStatement().execute("Create Table transactions (i int identity, v varchar(20))");
assertRowCount( 0, "Select * from transactions");
con1.setAutoCommit(false);
con1.createStatement().execute("Insert Into transactions(v) Values('qwert2')");
ResultSet rs2 = con2.createStatement().executeQuery("Select count(*) from transactions");
assertTrue( rs2.next() );
assertEquals( 1, rs2.getInt(1) );
}finally{
dropTable(con1, "transactions");
con1.setAutoCommit(true);
con2.close();
}Connection con = AllTests.getConnection();
try{
con.createStatement().execute("Create Table transactions ( v varchar(20))");
assertRowCount(0, "Select * from transactions");
assertEquals(1, con.createStatement().executeUpdate("Insert Into transactions(v) Values('qwert')"));
assertEqualsRsValue("qwert", "Select * from transactions");
assertEqualsRsValue(new Integer(1), "Select count(*) from transactions");
con.setAutoCommit(false);
assertEquals(1, con.createStatement().executeUpdate("Update transactions set v='qwert1'"));
assertEqualsRsValue("qwert1", "Select * from transactions");
assertEqualsRsValue(new Integer(1), "Select count(*) from transactions");
assertEquals(1, con.createStatement().executeUpdate("Update transactions set v='qwert2'"));
assertEqualsRsValue("qwert2", "Select * from transactions");
assertEqualsRsValue(new Integer(1), "Select count(*) from transactions");
Savepoint savepoint = con.setSavepoint();
assertEquals(1, con.createStatement().executeUpdate("Update transactions set v='qwert 3'"));
assertEqualsRsValue("qwert 3", "Select * from transactions");
assertEqualsRsValue(new Integer(1), "Select count(*) from transactions");
assertEquals(1, con.createStatement().executeUpdate("Update transactions set v='qwert 4'"));
assertEqualsRsValue("qwert 4", "Select * from transactions");
assertEqualsRsValue(new Integer(1), "Select count(*) from transactions");
assertEquals(1, con.createStatement().executeUpdate("Update transactions set v='qwert 5'"));
assertEqualsRsValue("qwert 5", "Select * from transactions");
assertEqualsRsValue(new Integer(1), "Select count(*) from transactions");
con.rollback(savepoint);
con.commit();
assertEqualsRsValue("qwert2", "Select * from transactions");
assertEqualsRsValue(new Integer(1), "Select count(*) from transactions");
}finally{
dropTable(con, "transactions");
con.setAutoCommit(true);
}Connection con = AllTests.getConnection();
try{
con.setAutoCommit(false);
con.createStatement().execute("Create Table transactions (i int identity, v varchar(20))");
assertRowCount( 0, "Select * from transactions");
con.createStatement().execute("Insert Into transactions(v) Values('qwert')");
assertRowCount( 1, "Select * from transactions");
con.createStatement().execute("Insert Into transactions(v) Select v From transactions");
assertRowCount( 2, "Select * from transactions");
con.createStatement().execute("Insert Into transactions Select * From transactions");
assertRowCount( 4, "Select * from transactions");
con.commit();
assertRowCount( 4, "Select * from transactions");
}finally{
try{
con.createStatement().execute("Drop Table transactions");
}catch(Throwable e){e.printStackTrace();}
con.setAutoCommit(true);
}Connection con = AllTests.getConnection();
try{
con.setAutoCommit(false);
con.createStatement().execute("Create Table transactions ( v varchar(20))");
assertRowCount( 0, "Select * from transactions");
assertEquals( 1, con.createStatement().executeUpdate("Insert Into transactions(v) Values('qwert')") );
assertEqualsRsValue("qwert", "Select * from transactions");
assertEqualsRsValue(new Integer(1), "Select count(*) from transactions");
assertEquals( 1, con.createStatement().executeUpdate("Update transactions set v='qwert1'") );
assertEqualsRsValue("qwert1", "Select * from transactions");
assertEqualsRsValue(new Integer(1), "Select count(*) from transactions");
assertEquals( 1, con.createStatement().executeUpdate("Update transactions set v='qwert2'") );
assertEqualsRsValue("qwert2", "Select * from transactions");
assertEqualsRsValue(new Integer(1), "Select count(*) from transactions");
Savepoint savepoint = con.setSavepoint();
assertEquals( 1, con.createStatement().executeUpdate("Update transactions set v='qwert 3'") );
assertEqualsRsValue("qwert 3", "Select * from transactions");
assertEqualsRsValue(new Integer(1), "Select count(*) from transactions");
con.rollback( savepoint );
con.commit();
assertEqualsRsValue("qwert2", "Select * from transactions");
assertEqualsRsValue(new Integer(1), "Select count(*) from transactions");
}finally{
try{
con.createStatement().execute("Drop Table transactions");
}catch(Throwable e){e.printStackTrace();}
con.setAutoCommit(true);
}Connection con = AllTests.getConnection();
try{
con.createStatement().execute("Create Table transactions (i int identity, v varchar(20))");
con.setAutoCommit(false);
assertRowCount( 0, "Select * from transactions");
con.createStatement().execute("Insert Into transactions(v) Values('qwert')");
assertRowCount( 1, "Select * from transactions");
con.createStatement().execute("Insert Into transactions(v) Select v From transactions");
assertRowCount( 2, "Select * from transactions");
con.createStatement().execute("Insert Into transactions(v) (Select v From transactions)");
assertRowCount( 4, "Select * from transactions");
con.rollback();
assertRowCount( 0, "Select * from transactions");
}finally{
try{
con.createStatement().execute("Drop Table transactions");
}catch(Throwable e){e.printStackTrace();}
con.setAutoCommit(true);
}Connection con = AllTests.getConnection();
try{
con.createStatement().execute("Create Table transactions (i int identity, v varchar(20))");
assertRowCount( 0, "Select * from transactions");
con.createStatement().execute("Insert Into transactions(v) Values('qwert')");
assertRowCount( 1, "Select * from transactions");
con.setAutoCommit(false);
con.createStatement().execute("Insert Into transactions(v) Select v From transactions");
assertRowCount( 2, "Select * from transactions");
con.createStatement().execute("Insert Into transactions(v) (Select v From transactions)");
assertRowCount( 4, "Select * from transactions");
con.rollback();
assertRowCount( 1, "Select * from transactions");
}finally{
try{
con.createStatement().execute("Drop Table transactions");
}catch(Throwable e){e.printStackTrace();}
con.setAutoCommit(true);
}Connection con = AllTests.getConnection();
try{
con.setAutoCommit(false);
con.createStatement().execute("Create Table transactions (i int identity, v varchar(20))");
assertRowCount( 0, "Select * from transactions");
con.createStatement().execute("Insert Into transactions(v) Values('qwert')");
ResultSet rs = con.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_UPDATABLE)
.executeQuery("Select * from transactions Where 1=0");
rs.moveToInsertRow();
rs.updateString("v", "qwert2");
rs.insertRow();
rs.beforeFirst();
assertTrue( rs.next() );
assertEquals("qwert2", rs.getString("v"));
assertFalse( rs.next() );
}finally{
try{
con.createStatement().execute("Drop Table transactions");
}catch(Throwable e){e.printStackTrace();}
con.setAutoCommit(true);
}Connection con = AllTests.getConnection();
try{
con.createStatement().execute("Create Table transactions (i int identity, v varchar(20))");
assertRowCount( 0, "Select * from transactions");
con.createStatement().execute("Insert Into transactions(v) Values('qwert')");
assertRowCount( 1, "Select * from transactions");
con.setAutoCommit(false);
con.createStatement().execute("Insert Into transactions(v) Select v From transactions");
assertRowCount( 2, "Select * from transactions");
con.createStatement().execute("Insert Into transactions (Select * From transactions)");
assertRowCount( 4, "Select * from transactions");
con.commit();
assertRowCount( 4, "Select * from transactions");
}finally{
try{
con.createStatement().execute("Drop Table transactions");
}catch(Throwable e){e.printStackTrace();}
con.setAutoCommit(true);
}ResultSetMetaData md = rs.getMetaData();
int count = md.getColumnCount();
for(int i=1; i<=count; i++){
System.out.print(md.getColumnLabel(i));
System.out.print('\t');
}
System.out.println();
while(rs.next()){
for(int i=1; i<=count; i++){
System.out.print(rs.getObject(i));
System.out.print('\t');
}
System.out.println();
}System.out.println("SmallSQL Database command line tool\n");
Connection con = new SSDriver().connect("jdbc:smallsql", new Properties());
Statement st = con.createStatement();
if(args.length>0){
con.setCatalog(args[0]);
}
System.out.println("\tVersion: "+con.getMetaData().getDatabaseProductVersion());
System.out.println("\tCurrent database: "+con.getCatalog());
System.out.println();
System.out.println("\tUse the USE command to change the database context.");
System.out.println("\tType 2 times ENTER to execute any SQL command.");
StringBuffer command = new StringBuffer();
BufferedReader input = new BufferedReader(new InputStreamReader(System.in));
while(true){
try {
String line;
try{
line = input.readLine();
}catch(IOException ex){
ex.printStackTrace();
JOptionPane.showMessageDialog( null, "You need to start the command line of the \nSmallSQL Database with a console window:\n\n       java -jar smallsql.jar\n\n" + ex, "Fatal Error", JOptionPane.OK_OPTION);
return;
}
if(line == null){
return;
}
if(line.length() == 0 && command.length() > 0){
boolean isRS = st.execute(command.toString());
if(isRS){
printRS(st.getResultSet());
}
command.setLength(0);
}
command.append(line).append('\n');
} catch (Exception e) {
command.setLength(0);
e.printStackTrace();
}
}this.con = con;
Command cmd = parse( sqlString.toCharArray() );
SQLToken token = nextToken();
if(token != null){
throw createSyntaxError(token, Language.STXADD_ADDITIONAL_TOK);
}
return cmd;this.con = con;
Command cmd = parse( sqlString.toCharArray() );
SQLToken token = nextToken();
if(token != null){
throw createSyntaxError(token, Language.STXADD_ADDITIONAL_TOK);
}
return cmd;this.con = con;
Command cmd = parse( sqlString.toCharArray() );
SQLToken token = nextToken();
if(token != null){
throw createSyntaxError(token, Language.STXADD_ADDITIONAL_TOK);
}
return cmd;this.con = con;
Command cmd = parse( sqlString.toCharArray() );
SQLToken token = nextToken();
if(token != null){
throw createSyntaxError(token, Language.STXADD_ADDITIONAL_TOK);
}
return cmd;this.con = con;
Command cmd = parse( sqlString.toCharArray() );
SQLToken token = nextToken();
if(token != null){
throw createSyntaxError(token, Language.STXADD_ADDITIONAL_TOK);
}
return cmd;this.con = con;
Command cmd = parse( sqlString.toCharArray() );
SQLToken token = nextToken();
if(token != null){
throw createSyntaxError(token, Language.STXADD_ADDITIONAL_TOK);
}
return cmd;this.con = con;
Command cmd = parse( sqlString.toCharArray() );
SQLToken token = nextToken();
if(token != null){
throw createSyntaxError(token, Language.STXADD_ADDITIONAL_TOK);
}
return cmd;this.con = con;
Command cmd = parse( sqlString.toCharArray() );
SQLToken token = nextToken();
if(token != null){
throw createSyntaxError(token, Language.STXADD_ADDITIONAL_TOK);
}
return cmd;this.con = con;
Command cmd = parse( sqlString.toCharArray() );
SQLToken token = nextToken();
if(token != null){
throw createSyntaxError(token, Language.STXADD_ADDITIONAL_TOK);
}
return cmd;this.con = con;
Command cmd = parse( sqlString.toCharArray() );
SQLToken token = nextToken();
if(token != null){
throw createSyntaxError(token, Language.STXADD_ADDITIONAL_TOK);
}
return cmd;this.con = con;
Command cmd = parse( sqlString.toCharArray() );
SQLToken token = nextToken();
if(token != null){
throw createSyntaxError(token, Language.STXADD_ADDITIONAL_TOK);
}
return cmd;this.con = con;
Command cmd = parse( sqlString.toCharArray() );
SQLToken token = nextToken();
if(token != null){
throw createSyntaxError(token, Language.STXADD_ADDITIONAL_TOK);
}
return cmd;this.con = con;
Command cmd = parse( sqlString.toCharArray() );
SQLToken token = nextToken();
if(token != null){
throw createSyntaxError(token, Language.STXADD_ADDITIONAL_TOK);
}
return cmd;this.con = con;
Command cmd = parse( sqlString.toCharArray() );
SQLToken token = nextToken();
if(token != null){
throw createSyntaxError(token, Language.STXADD_ADDITIONAL_TOK);
}
return cmd;this.con = con;
Command cmd = parse( sqlString.toCharArray() );
SQLToken token = nextToken();
if(token != null){
throw createSyntaxError(token, Language.STXADD_ADDITIONAL_TOK);
}
return cmd;this.con = con;
Command cmd = parse( sqlString.toCharArray() );
SQLToken token = nextToken();
if(token != null){
throw createSyntaxError(token, Language.STXADD_ADDITIONAL_TOK);
}
return cmd;this.con = con;
Command cmd = parse( sqlString.toCharArray() );
SQLToken token = nextToken();
if(token != null){
throw createSyntaxError(token, Language.STXADD_ADDITIONAL_TOK);
}
return cmd;this.con = con;
Command cmd = parse( sqlString.toCharArray() );
SQLToken token = nextToken();
if(token != null){
throw createSyntaxError(token, Language.STXADD_ADDITIONAL_TOK);
}
return cmd;this.con = con;
Command cmd = parse( sqlString.toCharArray() );
SQLToken token = nextToken();
if(token != null){
throw createSyntaxError(token, Language.STXADD_ADDITIONAL_TOK);
}
return cmd;this.con = con;
Command cmd = parse( sqlString.toCharArray() );
SQLToken token = nextToken();
if(token != null){
throw createSyntaxError(token, Language.STXADD_ADDITIONAL_TOK);
}
return cmd;this.con = con;
Command cmd = parse( sqlString.toCharArray() );
SQLToken token = nextToken();
if(token != null){
throw createSyntaxError(token, Language.STXADD_ADDITIONAL_TOK);
}
return cmd;this.con = con;
Command cmd = parse( sqlString.toCharArray() );
SQLToken token = nextToken();
if(token != null){
throw createSyntaxError(token, Language.STXADD_ADDITIONAL_TOK);
}
return cmd;this.con = con;
Command cmd = parse( sqlString.toCharArray() );
SQLToken token = nextToken();
if(token != null){
throw createSyntaxError(token, Language.STXADD_ADDITIONAL_TOK);
}
return cmd;this.con = con;
Command cmd = parse( sqlString.toCharArray() );
SQLToken token = nextToken();
if(token != null){
throw createSyntaxError(token, Language.STXADD_ADDITIONAL_TOK);
}
return cmd;this.con = con;
Command cmd = parse( sqlString.toCharArray() );
SQLToken token = nextToken();
if(token != null){
throw createSyntaxError(token, Language.STXADD_ADDITIONAL_TOK);
}
return cmd;this.con = con;
Command cmd = parse( sqlString.toCharArray() );
SQLToken token = nextToken();
if(token != null){
throw createSyntaxError(token, Language.STXADD_ADDITIONAL_TOK);
}
return cmd;this.con = con;
Command cmd = parse( sqlString.toCharArray() );
SQLToken token = nextToken();
if(token != null){
throw createSyntaxError(token, Language.STXADD_ADDITIONAL_TOK);
}
return cmd;this.con = con;
Command cmd = parse( sqlString.toCharArray() );
SQLToken token = nextToken();
if(token != null){
throw createSyntaxError(token, Language.STXADD_ADDITIONAL_TOK);
}
return cmd;this.con = con;
Command cmd = parse( sqlString.toCharArray() );
SQLToken token = nextToken();
if(token != null){
throw createSyntaxError(token, Language.STXADD_ADDITIONAL_TOK);
}
return cmd;this.con = con;
Command cmd = parse( sqlString.toCharArray() );
SQLToken token = nextToken();
if(token != null){
throw createSyntaxError(token, Language.STXADD_ADDITIONAL_TOK);
}
return cmd;this.con = con;
Command cmd = parse( sqlString.toCharArray() );
SQLToken token = nextToken();
if(token != null){
throw createSyntaxError(token, Language.STXADD_ADDITIONAL_TOK);
}
return cmd;this.con = con;
Command cmd = parse( sqlString.toCharArray() );
SQLToken token = nextToken();
if(token != null){
throw createSyntaxError(token, Language.STXADD_ADDITIONAL_TOK);
}
return cmd;this.con = con;
Command cmd = parse( sqlString.toCharArray() );
SQLToken token = nextToken();
if(token != null){
throw createSyntaxError(token, Language.STXADD_ADDITIONAL_TOK);
}
return cmd;this.con = con;
Command cmd = parse( sqlString.toCharArray() );
SQLToken token = nextToken();
if(token != null){
throw createSyntaxError(token, Language.STXADD_ADDITIONAL_TOK);
}
return cmd;this.con = con;
Command cmd = parse( sqlString.toCharArray() );
SQLToken token = nextToken();
if(token != null){
throw createSyntaxError(token, Language.STXADD_ADDITIONAL_TOK);
}
return cmd;this.con = con;
Command cmd = parse( sqlString.toCharArray() );
SQLToken token = nextToken();
if(token != null){
throw createSyntaxError(token, Language.STXADD_ADDITIONAL_TOK);
}
return cmd;this.con = con;
Command cmd = parse( sqlString.toCharArray() );
SQLToken token = nextToken();
if(token != null){
throw createSyntaxError(token, Language.STXADD_ADDITIONAL_TOK);
}
return cmd;this.con = con;
Command cmd = parse( sqlString.toCharArray() );
SQLToken token = nextToken();
if(token != null){
throw createSyntaxError(token, Language.STXADD_ADDITIONAL_TOK);
}
return cmd;this.con = con;
Command cmd = parse( sqlString.toCharArray() );
SQLToken token = nextToken();
if(token != null){
throw createSyntaxError(token, Language.STXADD_ADDITIONAL_TOK);
}
return cmd;this.con = con;
Command cmd = parse( sqlString.toCharArray() );
SQLToken token = nextToken();
if(token != null){
throw createSyntaxError(token, Language.STXADD_ADDITIONAL_TOK);
}
return cmd;this.con = con;
Command cmd = parse( sqlString.toCharArray() );
SQLToken token = nextToken();
if(token != null){
throw createSyntaxError(token, Language.STXADD_ADDITIONAL_TOK);
}
return cmd;this.con = con;
Command cmd = parse( sqlString.toCharArray() );
SQLToken token = nextToken();
if(token != null){
throw createSyntaxError(token, Language.STXADD_ADDITIONAL_TOK);
}
return cmd;this.con = con;
Command cmd = parse( sqlString.toCharArray() );
SQLToken token = nextToken();
if(token != null){
throw createSyntaxError(token, Language.STXADD_ADDITIONAL_TOK);
}
return cmd;this.con = con;
Command cmd = parse( sqlString.toCharArray() );
SQLToken token = nextToken();
if(token != null){
throw createSyntaxError(token, Language.STXADD_ADDITIONAL_TOK);
}
return cmd;this.con = con;
Command cmd = parse( sqlString.toCharArray() );
SQLToken token = nextToken();
if(token != null){
throw createSyntaxError(token, Language.STXADD_ADDITIONAL_TOK);
}
return cmd;this.con = con;
Command cmd = parse( sqlString.toCharArray() );
SQLToken token = nextToken();
if(token != null){
throw createSyntaxError(token, Language.STXADD_ADDITIONAL_TOK);
}
return cmd;this.con = con;
Command cmd = parse( sqlString.toCharArray() );
SQLToken token = nextToken();
if(token != null){
throw createSyntaxError(token, Language.STXADD_ADDITIONAL_TOK);
}
return cmd;this.con = con;
Command cmd = parse( sqlString.toCharArray() );
SQLToken token = nextToken();
if(token != null){
throw createSyntaxError(token, Language.STXADD_ADDITIONAL_TOK);
}
return cmd;this.con = con;
Command cmd = parse( sqlString.toCharArray() );
SQLToken token = nextToken();
if(token != null){
throw createSyntaxError(token, Language.STXADD_ADDITIONAL_TOK);
}
return cmd;this.con = con;
Command cmd = parse( sqlString.toCharArray() );
SQLToken token = nextToken();
if(token != null){
throw createSyntaxError(token, Language.STXADD_ADDITIONAL_TOK);
}
return cmd;this.con = con;
Command cmd = parse( sqlString.toCharArray() );
SQLToken token = nextToken();
if(token != null){
throw createSyntaxError(token, Language.STXADD_ADDITIONAL_TOK);
}
return cmd;this.con = con;
Command cmd = parse( sqlString.toCharArray() );
SQLToken token = nextToken();
if(token != null){
throw createSyntaxError(token, Language.STXADD_ADDITIONAL_TOK);
}
return cmd;this.con = con;
Command cmd = parse( sqlString.toCharArray() );
SQLToken token = nextToken();
if(token != null){
throw createSyntaxError(token, Language.STXADD_ADDITIONAL_TOK);
}
return cmd;this.con = con;
Command cmd = parse( sqlString.toCharArray() );
SQLToken token = nextToken();
if(token != null){
throw createSyntaxError(token, Language.STXADD_ADDITIONAL_TOK);
}
return cmd;this.con = con;
Command cmd = parse( sqlString.toCharArray() );
SQLToken token = nextToken();
if(token != null){
throw createSyntaxError(token, Language.STXADD_ADDITIONAL_TOK);
}
return cmd;this.con = con;
Command cmd = parse( sqlString.toCharArray() );
SQLToken token = nextToken();
if(token != null){
throw createSyntaxError(token, Language.STXADD_ADDITIONAL_TOK);
}
return cmd;this.con = con;
Command cmd = parse( sqlString.toCharArray() );
SQLToken token = nextToken();
if(token != null){
throw createSyntaxError(token, Language.STXADD_ADDITIONAL_TOK);
}
return cmd;this.con = con;
Command cmd = parse( sqlString.toCharArray() );
SQLToken token = nextToken();
if(token != null){
throw createSyntaxError(token, Language.STXADD_ADDITIONAL_TOK);
}
return cmd;this.con = con;
Command cmd = parse( sqlString.toCharArray() );
SQLToken token = nextToken();
if(token != null){
throw createSyntaxError(token, Language.STXADD_ADDITIONAL_TOK);
}
return cmd;this.con = con;
Command cmd = parse( sqlString.toCharArray() );
SQLToken token = nextToken();
if(token != null){
throw createSyntaxError(token, Language.STXADD_ADDITIONAL_TOK);
}
return cmd;this.con = con;
Command cmd = parse( sqlString.toCharArray() );
SQLToken token = nextToken();
if(token != null){
throw createSyntaxError(token, Language.STXADD_ADDITIONAL_TOK);
}
return cmd;this.con = con;
Command cmd = parse( sqlString.toCharArray() );
SQLToken token = nextToken();
if(token != null){
throw createSyntaxError(token, Language.STXADD_ADDITIONAL_TOK);
}
return cmd;this.con = con;
Command cmd = parse( sqlString.toCharArray() );
SQLToken token = nextToken();
if(token != null){
throw createSyntaxError(token, Language.STXADD_ADDITIONAL_TOK);
}
return cmd;this.con = con;
Command cmd = parse( sqlString.toCharArray() );
SQLToken token = nextToken();
if(token != null){
throw createSyntaxError(token, Language.STXADD_ADDITIONAL_TOK);
}
return cmd;this.con = con;
Command cmd = parse( sqlString.toCharArray() );
SQLToken token = nextToken();
if(token != null){
throw createSyntaxError(token, Language.STXADD_ADDITIONAL_TOK);
}
return cmd;this.con = con;
Command cmd = parse( sqlString.toCharArray() );
SQLToken token = nextToken();
if(token != null){
throw createSyntaxError(token, Language.STXADD_ADDITIONAL_TOK);
}
return cmd;this.con = con;
Command cmd = parse( sqlString.toCharArray() );
SQLToken token = nextToken();
if(token != null){
throw createSyntaxError(token, Language.STXADD_ADDITIONAL_TOK);
}
return cmd;this.con = con;
Command cmd = parse( sqlString.toCharArray() );
SQLToken token = nextToken();
if(token != null){
throw createSyntaxError(token, Language.STXADD_ADDITIONAL_TOK);
}
return cmd;this.con = con;
Command cmd = parse( sqlString.toCharArray() );
SQLToken token = nextToken();
if(token != null){
throw createSyntaxError(token, Language.STXADD_ADDITIONAL_TOK);
}
return cmd;this.con = con;
Command cmd = parse( sqlString.toCharArray() );
SQLToken token = nextToken();
if(token != null){
throw createSyntaxError(token, Language.STXADD_ADDITIONAL_TOK);
}
return cmd;this.con = con;
Command cmd = parse( sqlString.toCharArray() );
SQLToken token = nextToken();
if(token != null){
throw createSyntaxError(token, Language.STXADD_ADDITIONAL_TOK);
}
return cmd;this.con = con;
Command cmd = parse( sqlString.toCharArray() );
SQLToken token = nextToken();
if(token != null){
throw createSyntaxError(token, Language.STXADD_ADDITIONAL_TOK);
}
return cmd;this.con = con;
Command cmd = parse( sqlString.toCharArray() );
SQLToken token = nextToken();
if(token != null){
throw createSyntaxError(token, Language.STXADD_ADDITIONAL_TOK);
}
return cmd;this.con = con;
Command cmd = parse( sqlString.toCharArray() );
SQLToken token = nextToken();
if(token != null){
throw createSyntaxError(token, Language.STXADD_ADDITIONAL_TOK);
}
return cmd;this.con = con;
Command cmd = parse( sqlString.toCharArray() );
SQLToken token = nextToken();
if(token != null){
throw createSyntaxError(token, Language.STXADD_ADDITIONAL_TOK);
}
return cmd;this.con = con;
Command cmd = parse( sqlString.toCharArray() );
SQLToken token = nextToken();
if(token != null){
throw createSyntaxError(token, Language.STXADD_ADDITIONAL_TOK);
}
return cmd;this.con = con;
Command cmd = parse( sqlString.toCharArray() );
SQLToken token = nextToken();
if(token != null){
throw createSyntaxError(token, Language.STXADD_ADDITIONAL_TOK);
}
return cmd;this.con = con;
Command cmd = parse( sqlString.toCharArray() );
SQLToken token = nextToken();
if(token != null){
throw createSyntaxError(token, Language.STXADD_ADDITIONAL_TOK);
}
return cmd;this.con = con;
Command cmd = parse( sqlString.toCharArray() );
SQLToken token = nextToken();
if(token != null){
throw createSyntaxError(token, Language.STXADD_ADDITIONAL_TOK);
}
return cmd;this.con = con;
Command cmd = parse( sqlString.toCharArray() );
SQLToken token = nextToken();
if(token != null){
throw createSyntaxError(token, Language.STXADD_ADDITIONAL_TOK);
}
return cmd;this.con = con;
Command cmd = parse( sqlString.toCharArray() );
SQLToken token = nextToken();
if(token != null){
throw createSyntaxError(token, Language.STXADD_ADDITIONAL_TOK);
}
return cmd;this.con = con;
Command cmd = parse( sqlString.toCharArray() );
SQLToken token = nextToken();
if(token != null){
throw createSyntaxError(token, Language.STXADD_ADDITIONAL_TOK);
}
return cmd;this.con = con;
Command cmd = parse( sqlString.toCharArray() );
SQLToken token = nextToken();
if(token != null){
throw createSyntaxError(token, Language.STXADD_ADDITIONAL_TOK);
}
return cmd;this.con = con;
Command cmd = parse( sqlString.toCharArray() );
SQLToken token = nextToken();
if(token != null){
throw createSyntaxError(token, Language.STXADD_ADDITIONAL_TOK);
}
return cmd;this.con = con;
Command cmd = parse( sqlString.toCharArray() );
SQLToken token = nextToken();
if(token != null){
throw createSyntaxError(token, Language.STXADD_ADDITIONAL_TOK);
}
return cmd;this.con = con;
Command cmd = parse( sqlString.toCharArray() );
SQLToken token = nextToken();
if(token != null){
throw createSyntaxError(token, Language.STXADD_ADDITIONAL_TOK);
}
return cmd;this.con = con;
Command cmd = parse( sqlString.toCharArray() );
SQLToken token = nextToken();
if(token != null){
throw createSyntaxError(token, Language.STXADD_ADDITIONAL_TOK);
}
return cmd;this.con = con;
Command cmd = parse( sqlString.toCharArray() );
SQLToken token = nextToken();
if(token != null){
throw createSyntaxError(token, Language.STXADD_ADDITIONAL_TOK);
}
return cmd;this.con = con;
Command cmd = parse( sqlString.toCharArray() );
SQLToken token = nextToken();
if(token != null){
throw createSyntaxError(token, Language.STXADD_ADDITIONAL_TOK);
}
return cmd;this.con = con;
Command cmd = parse( sqlString.toCharArray() );
SQLToken token = nextToken();
if(token != null){
throw createSyntaxError(token, Language.STXADD_ADDITIONAL_TOK);
}
return cmd;this.con = con;
Command cmd = parse( sqlString.toCharArray() );
SQLToken token = nextToken();
if(token != null){
throw createSyntaxError(token, Language.STXADD_ADDITIONAL_TOK);
}
return cmd;this.con = con;
Command cmd = parse( sqlString.toCharArray() );
SQLToken token = nextToken();
if(token != null){
throw createSyntaxError(token, Language.STXADD_ADDITIONAL_TOK);
}
return cmd;this.con = con;
Command cmd = parse( sqlString.toCharArray() );
SQLToken token = nextToken();
if(token != null){
throw createSyntaxError(token, Language.STXADD_ADDITIONAL_TOK);
}
return cmd;this.con = con;
Command cmd = parse( sqlString.toCharArray() );
SQLToken token = nextToken();
if(token != null){
throw createSyntaxError(token, Language.STXADD_ADDITIONAL_TOK);
}
return cmd;this.con = con;
Command cmd = parse( sqlString.toCharArray() );
SQLToken token = nextToken();
if(token != null){
throw createSyntaxError(token, Language.STXADD_ADDITIONAL_TOK);
}
return cmd;this.con = con;
Command cmd = parse( sqlString.toCharArray() );
SQLToken token = nextToken();
if(token != null){
throw createSyntaxError(token, Language.STXADD_ADDITIONAL_TOK);
}
return cmd;this.con = con;
Command cmd = parse( sqlString.toCharArray() );
SQLToken token = nextToken();
if(token != null){
throw createSyntaxError(token, Language.STXADD_ADDITIONAL_TOK);
}
return cmd;this.con = con;
Command cmd = parse( sqlString.toCharArray() );
SQLToken token = nextToken();
if(token != null){
throw createSyntaxError(token, Language.STXADD_ADDITIONAL_TOK);
}
return cmd;this.con = con;
Command cmd = parse( sqlString.toCharArray() );
SQLToken token = nextToken();
if(token != null){
throw createSyntaxError(token, Language.STXADD_ADDITIONAL_TOK);
}
return cmd;this.con = con;
Command cmd = parse( sqlString.toCharArray() );
SQLToken token = nextToken();
if(token != null){
throw createSyntaxError(token, Language.STXADD_ADDITIONAL_TOK);
}
return cmd;this.con = con;
Command cmd = parse( sqlString.toCharArray() );
SQLToken token = nextToken();
if(token != null){
throw createSyntaxError(token, Language.STXADD_ADDITIONAL_TOK);
}
return cmd;this.con = con;
Command cmd = parse( sqlString.toCharArray() );
SQLToken token = nextToken();
if(token != null){
throw createSyntaxError(token, Language.STXADD_ADDITIONAL_TOK);
}
return cmd;this.con = con;
Command cmd = parse( sqlString.toCharArray() );
SQLToken token = nextToken();
if(token != null){
throw createSyntaxError(token, Language.STXADD_ADDITIONAL_TOK);
}
return cmd;this.con = con;
Command cmd = parse( sqlString.toCharArray() );
SQLToken token = nextToken();
if(token != null){
throw createSyntaxError(token, Language.STXADD_ADDITIONAL_TOK);
}
return cmd;this.con = con;
Command cmd = parse( sqlString.toCharArray() );
SQLToken token = nextToken();
if(token != null){
throw createSyntaxError(token, Language.STXADD_ADDITIONAL_TOK);
}
return cmd;this.con = con;
Command cmd = parse( sqlString.toCharArray() );
SQLToken token = nextToken();
if(token != null){
throw createSyntaxError(token, Language.STXADD_ADDITIONAL_TOK);
}
return cmd;this.con = con;
Command cmd = parse( sqlString.toCharArray() );
SQLToken token = nextToken();
if(token != null){
throw createSyntaxError(token, Language.STXADD_ADDITIONAL_TOK);
}
return cmd;this.con = con;
Command cmd = parse( sqlString.toCharArray() );
SQLToken token = nextToken();
if(token != null){
throw createSyntaxError(token, Language.STXADD_ADDITIONAL_TOK);
}
return cmd;this.con = con;
Command cmd = parse( sqlString.toCharArray() );
SQLToken token = nextToken();
if(token != null){
throw createSyntaxError(token, Language.STXADD_ADDITIONAL_TOK);
}
return cmd;this.con = con;
Command cmd = parse( sqlString.toCharArray() );
SQLToken token = nextToken();
if(token != null){
throw createSyntaxError(token, Language.STXADD_ADDITIONAL_TOK);
}
return cmd;this.con = con;
Command cmd = parse( sqlString.toCharArray() );
SQLToken token = nextToken();
if(token != null){
throw createSyntaxError(token, Language.STXADD_ADDITIONAL_TOK);
}
return cmd;this.con = con;
Command cmd = parse( sqlString.toCharArray() );
SQLToken token = nextToken();
if(token != null){
throw createSyntaxError(token, Language.STXADD_ADDITIONAL_TOK);
}
return cmd;this.con = con;
Command cmd = parse( sqlString.toCharArray() );
SQLToken token = nextToken();
if(token != null){
throw createSyntaxError(token, Language.STXADD_ADDITIONAL_TOK);
}
return cmd;this.con = con;
Command cmd = parse( sqlString.toCharArray() );
SQLToken token = nextToken();
if(token != null){
throw createSyntaxError(token, Language.STXADD_ADDITIONAL_TOK);
}
return cmd;this.con = con;
Command cmd = parse( sqlString.toCharArray() );
SQLToken token = nextToken();
if(token != null){
throw createSyntaxError(token, Language.STXADD_ADDITIONAL_TOK);
}
return cmd;this.con = con;
Command cmd = parse( sqlString.toCharArray() );
SQLToken token = nextToken();
if(token != null){
throw createSyntaxError(token, Language.STXADD_ADDITIONAL_TOK);
}
return cmd;this.con = con;
Command cmd = parse( sqlString.toCharArray() );
SQLToken token = nextToken();
if(token != null){
throw createSyntaxError(token, Language.STXADD_ADDITIONAL_TOK);
}
return cmd;this.con = con;
Command cmd = parse( sqlString.toCharArray() );
SQLToken token = nextToken();
if(token != null){
throw createSyntaxError(token, Language.STXADD_ADDITIONAL_TOK);
}
return cmd;this.con = con;
Command cmd = parse( sqlString.toCharArray() );
SQLToken token = nextToken();
if(token != null){
throw createSyntaxError(token, Language.STXADD_ADDITIONAL_TOK);
}
return cmd;this.con = con;
Command cmd = parse( sqlString.toCharArray() );
SQLToken token = nextToken();
if(token != null){
throw createSyntaxError(token, Language.STXADD_ADDITIONAL_TOK);
}
return cmd;this.con = con;
Command cmd = parse( sqlString.toCharArray() );
SQLToken token = nextToken();
if(token != null){
throw createSyntaxError(token, Language.STXADD_ADDITIONAL_TOK);
}
return cmd;this.con = con;
Command cmd = parse( sqlString.toCharArray() );
SQLToken token = nextToken();
if(token != null){
throw createSyntaxError(token, Language.STXADD_ADDITIONAL_TOK);
}
return cmd;this.con = con;
Command cmd = parse( sqlString.toCharArray() );
SQLToken token = nextToken();
if(token != null){
throw createSyntaxError(token, Language.STXADD_ADDITIONAL_TOK);
}
return cmd;this.con = con;
Command cmd = parse( sqlString.toCharArray() );
SQLToken token = nextToken();
if(token != null){
throw createSyntaxError(token, Language.STXADD_ADDITIONAL_TOK);
}
return cmd;this.con = con;
Command cmd = parse( sqlString.toCharArray() );
SQLToken token = nextToken();
if(token != null){
throw createSyntaxError(token, Language.STXADD_ADDITIONAL_TOK);
}
return cmd;this.con = con;
Command cmd = parse( sqlString.toCharArray() );
SQLToken token = nextToken();
if(token != null){
throw createSyntaxError(token, Language.STXADD_ADDITIONAL_TOK);
}
return cmd;this.con = con;
Command cmd = parse( sqlString.toCharArray() );
SQLToken token = nextToken();
if(token != null){
throw createSyntaxError(token, Language.STXADD_ADDITIONAL_TOK);
}
return cmd;this.con = con;
Command cmd = parse( sqlString.toCharArray() );
SQLToken token = nextToken();
if(token != null){
throw createSyntaxError(token, Language.STXADD_ADDITIONAL_TOK);
}
return cmd;this.con = con;
Command cmd = parse( sqlString.toCharArray() );
SQLToken token = nextToken();
if(token != null){
throw createSyntaxError(token, Language.STXADD_ADDITIONAL_TOK);
}
return cmd;this.con = con;
Command cmd = parse( sqlString.toCharArray() );
SQLToken token = nextToken();
if(token != null){
throw createSyntaxError(token, Language.STXADD_ADDITIONAL_TOK);
}
return cmd;this.con = con;
Command cmd = parse( sqlString.toCharArray() );
SQLToken token = nextToken();
if(token != null){
throw createSyntaxError(token, Language.STXADD_ADDITIONAL_TOK);
}
return cmd;this.con = con;
Command cmd = parse( sqlString.toCharArray() );
SQLToken token = nextToken();
if(token != null){
throw createSyntaxError(token, Language.STXADD_ADDITIONAL_TOK);
}
return cmd;this.con = con;
Command cmd = parse( sqlString.toCharArray() );
SQLToken token = nextToken();
if(token != null){
throw createSyntaxError(token, Language.STXADD_ADDITIONAL_TOK);
}
return cmd;this.con = con;
Command cmd = parse( sqlString.toCharArray() );
SQLToken token = nextToken();
if(token != null){
throw createSyntaxError(token, Language.STXADD_ADDITIONAL_TOK);
}
return cmd;this.con = con;
Command cmd = parse( sqlString.toCharArray() );
SQLToken token = nextToken();
if(token != null){
throw createSyntaxError(token, Language.STXADD_ADDITIONAL_TOK);
}
return cmd;this.con = con;
Command cmd = parse( sqlString.toCharArray() );
SQLToken token = nextToken();
if(token != null){
throw createSyntaxError(token, Language.STXADD_ADDITIONAL_TOK);
}
return cmd;this.con = con;
Command cmd = parse( sqlString.toCharArray() );
SQLToken token = nextToken();
if(token != null){
throw createSyntaxError(token, Language.STXADD_ADDITIONAL_TOK);
}
return cmd;this.con = con;
Command cmd = parse( sqlString.toCharArray() );
SQLToken token = nextToken();
if(token != null){
throw createSyntaxError(token, Language.STXADD_ADDITIONAL_TOK);
}
return cmd;this.con = con;
Command cmd = parse( sqlString.toCharArray() );
SQLToken token = nextToken();
if(token != null){
throw createSyntaxError(token, Language.STXADD_ADDITIONAL_TOK);
}
return cmd;this.con = con;
Command cmd = parse( sqlString.toCharArray() );
SQLToken token = nextToken();
if(token != null){
throw createSyntaxError(token, Language.STXADD_ADDITIONAL_TOK);
}
return cmd;this.con = con;
Command cmd = parse( sqlString.toCharArray() );
SQLToken token = nextToken();
if(token != null){
throw createSyntaxError(token, Language.STXADD_ADDITIONAL_TOK);
}
return cmd;this.con = con;
Command cmd = parse( sqlString.toCharArray() );
SQLToken token = nextToken();
if(token != null){
throw createSyntaxError(token, Language.STXADD_ADDITIONAL_TOK);
}
return cmd;this.con = con;
Command cmd = parse( sqlString.toCharArray() );
SQLToken token = nextToken();
if(token != null){
throw createSyntaxError(token, Language.STXADD_ADDITIONAL_TOK);
}
return cmd;this.con = con;
Command cmd = parse( sqlString.toCharArray() );
SQLToken token = nextToken();
if(token != null){
throw createSyntaxError(token, Language.STXADD_ADDITIONAL_TOK);
}
return cmd;this.con = con;
Command cmd = parse( sqlString.toCharArray() );
SQLToken token = nextToken();
if(token != null){
throw createSyntaxError(token, Language.STXADD_ADDITIONAL_TOK);
}
return cmd;this.con = con;
Command cmd = parse( sqlString.toCharArray() );
SQLToken token = nextToken();
if(token != null){
throw createSyntaxError(token, Language.STXADD_ADDITIONAL_TOK);
}
return cmd;this.con = con;
Command cmd = parse( sqlString.toCharArray() );
SQLToken token = nextToken();
if(token != null){
throw createSyntaxError(token, Language.STXADD_ADDITIONAL_TOK);
}
return cmd;this.con = con;
Command cmd = parse( sqlString.toCharArray() );
SQLToken token = nextToken();
if(token != null){
throw createSyntaxError(token, Language.STXADD_ADDITIONAL_TOK);
}
return cmd;this.con = con;
Command cmd = parse( sqlString.toCharArray() );
SQLToken token = nextToken();
if(token != null){
throw createSyntaxError(token, Language.STXADD_ADDITIONAL_TOK);
}
return cmd;this.con = con;
Command cmd = parse( sqlString.toCharArray() );
SQLToken token = nextToken();
if(token != null){
throw createSyntaxError(token, Language.STXADD_ADDITIONAL_TOK);
}
return cmd;this.con = con;
Command cmd = parse( sqlString.toCharArray() );
SQLToken token = nextToken();
if(token != null){
throw createSyntaxError(token, Language.STXADD_ADDITIONAL_TOK);
}
return cmd;this.con = con;
Command cmd = parse( sqlString.toCharArray() );
SQLToken token = nextToken();
if(token != null){
throw createSyntaxError(token, Language.STXADD_ADDITIONAL_TOK);
}
return cmd;this.con = con;
Command cmd = parse( sqlString.toCharArray() );
SQLToken token = nextToken();
if(token != null){
throw createSyntaxError(token, Language.STXADD_ADDITIONAL_TOK);
}
return cmd;this.con = con;
Command cmd = parse( sqlString.toCharArray() );
SQLToken token = nextToken();
if(token != null){
throw createSyntaxError(token, Language.STXADD_ADDITIONAL_TOK);
}
return cmd;this.con = con;
Command cmd = parse( sqlString.toCharArray() );
SQLToken token = nextToken();
if(token != null){
throw createSyntaxError(token, Language.STXADD_ADDITIONAL_TOK);
}
return cmd;this.con = con;
Command cmd = parse( sqlString.toCharArray() );
SQLToken token = nextToken();
if(token != null){
throw createSyntaxError(token, Language.STXADD_ADDITIONAL_TOK);
}
return cmd;this.con = con;
Command cmd = parse( sqlString.toCharArray() );
SQLToken token = nextToken();
if(token != null){
throw createSyntaxError(token, Language.STXADD_ADDITIONAL_TOK);
}
return cmd;this.con = con;
Command cmd = parse( sqlString.toCharArray() );
SQLToken token = nextToken();
if(token != null){
throw createSyntaxError(token, Language.STXADD_ADDITIONAL_TOK);
}
return cmd;this.con = con;
Command cmd = parse( sqlString.toCharArray() );
SQLToken token = nextToken();
if(token != null){
throw createSyntaxError(token, Language.STXADD_ADDITIONAL_TOK);
}
return cmd;this.con = con;
Command cmd = parse( sqlString.toCharArray() );
SQLToken token = nextToken();
if(token != null){
throw createSyntaxError(token, Language.STXADD_ADDITIONAL_TOK);
}
return cmd;this.con = con;
Command cmd = parse( sqlString.toCharArray() );
SQLToken token = nextToken();
if(token != null){
throw createSyntaxError(token, Language.STXADD_ADDITIONAL_TOK);
}
return cmd;this.con = con;
Command cmd = parse( sqlString.toCharArray() );
SQLToken token = nextToken();
if(token != null){
throw createSyntaxError(token, Language.STXADD_ADDITIONAL_TOK);
}
return cmd;this.con = con;
Command cmd = parse( sqlString.toCharArray() );
SQLToken token = nextToken();
if(token != null){
throw createSyntaxError(token, Language.STXADD_ADDITIONAL_TOK);
}
return cmd;this.con = con;
Command cmd = parse( sqlString.toCharArray() );
SQLToken token = nextToken();
if(token != null){
throw createSyntaxError(token, Language.STXADD_ADDITIONAL_TOK);
}
return cmd;this.con = con;
Command cmd = parse( sqlString.toCharArray() );
SQLToken token = nextToken();
if(token != null){
throw createSyntaxError(token, Language.STXADD_ADDITIONAL_TOK);
}
return cmd;this.con = con;
Command cmd = parse( sqlString.toCharArray() );
SQLToken token = nextToken();
if(token != null){
throw createSyntaxError(token, Language.STXADD_ADDITIONAL_TOK);
}
return cmd;this.con = con;
Command cmd = parse( sqlString.toCharArray() );
SQLToken token = nextToken();
if(token != null){
throw createSyntaxError(token, Language.STXADD_ADDITIONAL_TOK);
}
return cmd;this.con = con;
Command cmd = parse( sqlString.toCharArray() );
SQLToken token = nextToken();
if(token != null){
throw createSyntaxError(token, Language.STXADD_ADDITIONAL_TOK);
}
return cmd;this.con = con;
Command cmd = parse( sqlString.toCharArray() );
SQLToken token = nextToken();
if(token != null){
throw createSyntaxError(token, Language.STXADD_ADDITIONAL_TOK);
}
return cmd;this.con = con;
Command cmd = parse( sqlString.toCharArray() );
SQLToken token = nextToken();
if(token != null){
throw createSyntaxError(token, Language.STXADD_ADDITIONAL_TOK);
}
return cmd;this.con = con;
Command cmd = parse( sqlString.toCharArray() );
SQLToken token = nextToken();
if(token != null){
throw createSyntaxError(token, Language.STXADD_ADDITIONAL_TOK);
}
return cmd;this.con = con;
Command cmd = parse( sqlString.toCharArray() );
SQLToken token = nextToken();
if(token != null){
throw createSyntaxError(token, Language.STXADD_ADDITIONAL_TOK);
}
return cmd;this.con = con;
Command cmd = parse( sqlString.toCharArray() );
SQLToken token = nextToken();
if(token != null){
throw createSyntaxError(token, Language.STXADD_ADDITIONAL_TOK);
}
return cmd;this.con = con;
Command cmd = parse( sqlString.toCharArray() );
SQLToken token = nextToken();
if(token != null){
throw createSyntaxError(token, Language.STXADD_ADDITIONAL_TOK);
}
return cmd;this.con = con;
Command cmd = parse( sqlString.toCharArray() );
SQLToken token = nextToken();
if(token != null){
throw createSyntaxError(token, Language.STXADD_ADDITIONAL_TOK);
}
return cmd;this.con = con;
Command cmd = parse( sqlString.toCharArray() );
SQLToken token = nextToken();
if(token != null){
throw createSyntaxError(token, Language.STXADD_ADDITIONAL_TOK);
}
return cmd;this.con = con;
Command cmd = parse( sqlString.toCharArray() );
SQLToken token = nextToken();
if(token != null){
throw createSyntaxError(token, Language.STXADD_ADDITIONAL_TOK);
}
return cmd;this.con = con;
Command cmd = parse( sqlString.toCharArray() );
SQLToken token = nextToken();
if(token != null){
throw createSyntaxError(token, Language.STXADD_ADDITIONAL_TOK);
}
return cmd;this.con = con;
Command cmd = parse( sqlString.toCharArray() );
SQLToken token = nextToken();
if(token != null){
throw createSyntaxError(token, Language.STXADD_ADDITIONAL_TOK);
}
return cmd;this.con = con;
Command cmd = parse( sqlString.toCharArray() );
SQLToken token = nextToken();
if(token != null){
throw createSyntaxError(token, Language.STXADD_ADDITIONAL_TOK);
}
return cmd;this.con = con;
Command cmd = parse( sqlString.toCharArray() );
SQLToken token = nextToken();
if(token != null){
throw createSyntaxError(token, Language.STXADD_ADDITIONAL_TOK);
}
return cmd;this.con = con;
Command cmd = parse( sqlString.toCharArray() );
SQLToken token = nextToken();
if(token != null){
throw createSyntaxError(token, Language.STXADD_ADDITIONAL_TOK);
}
return cmd;this.con = con;
Command cmd = parse( sqlString.toCharArray() );
SQLToken token = nextToken();
if(token != null){
throw createSyntaxError(token, Language.STXADD_ADDITIONAL_TOK);
}
return cmd;this.con = con;
Command cmd = parse( sqlString.toCharArray() );
SQLToken token = nextToken();
if(token != null){
throw createSyntaxError(token, Language.STXADD_ADDITIONAL_TOK);
}
return cmd;this.con = con;
Command cmd = parse( sqlString.toCharArray() );
SQLToken token = nextToken();
if(token != null){
throw createSyntaxError(token, Language.STXADD_ADDITIONAL_TOK);
}
return cmd;this.con = con;
Command cmd = parse( sqlString.toCharArray() );
SQLToken token = nextToken();
if(token != null){
throw createSyntaxError(token, Language.STXADD_ADDITIONAL_TOK);
}
return cmd;this.con = con;
Command cmd = parse( sqlString.toCharArray() );
SQLToken token = nextToken();
if(token != null){
throw createSyntaxError(token, Language.STXADD_ADDITIONAL_TOK);
}
return cmd;this.con = con;
Command cmd = parse( sqlString.toCharArray() );
SQLToken token = nextToken();
if(token != null){
throw createSyntaxError(token, Language.STXADD_ADDITIONAL_TOK);
}
return cmd;this.con = con;
Command cmd = parse( sqlString.toCharArray() );
SQLToken token = nextToken();
if(token != null){
throw createSyntaxError(token, Language.STXADD_ADDITIONAL_TOK);
}
return cmd;this.con = con;
Command cmd = parse( sqlString.toCharArray() );
SQLToken token = nextToken();
if(token != null){
throw createSyntaxError(token, Language.STXADD_ADDITIONAL_TOK);
}
return cmd;this.con = con;
Command cmd = parse( sqlString.toCharArray() );
SQLToken token = nextToken();
if(token != null){
throw createSyntaxError(token, Language.STXADD_ADDITIONAL_TOK);
}
return cmd;this.con = con;
Command cmd = parse( sqlString.toCharArray() );
SQLToken token = nextToken();
if(token != null){
throw createSyntaxError(token, Language.STXADD_ADDITIONAL_TOK);
}
return cmd;this.con = con;
Command cmd = parse( sqlString.toCharArray() );
SQLToken token = nextToken();
if(token != null){
throw createSyntaxError(token, Language.STXADD_ADDITIONAL_TOK);
}
return cmd;this.con = con;
Command cmd = parse( sqlString.toCharArray() );
SQLToken token = nextToken();
if(token != null){
throw createSyntaxError(token, Language.STXADD_ADDITIONAL_TOK);
}
return cmd;this.con = con;
Command cmd = parse( sqlString.toCharArray() );
SQLToken token = nextToken();
if(token != null){
throw createSyntaxError(token, Language.STXADD_ADDITIONAL_TOK);
}
return cmd;this.con = con;
Command cmd = parse( sqlString.toCharArray() );
SQLToken token = nextToken();
if(token != null){
throw createSyntaxError(token, Language.STXADD_ADDITIONAL_TOK);
}
return cmd;this.con = con;
Command cmd = parse( sqlString.toCharArray() );
SQLToken token = nextToken();
if(token != null){
throw createSyntaxError(token, Language.STXADD_ADDITIONAL_TOK);
}
return cmd;this.con = con;
Command cmd = parse( sqlString.toCharArray() );
SQLToken token = nextToken();
if(token != null){
throw createSyntaxError(token, Language.STXADD_ADDITIONAL_TOK);
}
return cmd;this.con = con;
Command cmd = parse( sqlString.toCharArray() );
SQLToken token = nextToken();
if(token != null){
throw createSyntaxError(token, Language.STXADD_ADDITIONAL_TOK);
}
return cmd;this.con = con;
Command cmd = parse( sqlString.toCharArray() );
SQLToken token = nextToken();
if(token != null){
throw createSyntaxError(token, Language.STXADD_ADDITIONAL_TOK);
}
return cmd;